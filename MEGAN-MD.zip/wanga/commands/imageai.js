// MEGAN-MD Image AI Commands - Clean version with buttons

const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs-extra');
const path = require('path');
const config = require('../../megan/config');
const uploader = require('../../megan/lib/upload');

const commands = [];

// Temp directory
const TEMP_DIR = path.join(__dirname, '../../temp');
fs.ensureDirSync(TEMP_DIR);

const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbCWWXi9hXF2SXUHgZ1b';
const TIMEOUT = 15000;
const CREATOR = "\n\n> created by wanga";

// ==================== HELPER FUNCTIONS ====================

async function safeApiCall(apiCall, fallbackData = null) {
    try {
        return await Promise.race([
            apiCall(),
            new Promise((_, reject) => 
                setTimeout(() => reject(new Error('Request timeout')), TIMEOUT)
            )
        ]);
    } catch (error) {
        console.error('API Error:', error.message);
        if (fallbackData) return fallbackData;
        throw error;
    }
}

async function downloadImage(url, filename) {
    const filePath = path.join(TEMP_DIR, filename);
    
    const response = await safeApiCall(() => axios({
        method: 'GET',
        url: url,
        responseType: 'arraybuffer',
        headers: { 'User-Agent': 'Mozilla/5.0' }
    }));
    
    await fs.writeFile(filePath, response.data);
    return filePath;
}

async function getQuotedImage(msg, sock) {
    try {
        const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!quoted) return null;

        if (quoted.imageMessage) {
            const buffer = await require('gifted-baileys').downloadMediaMessage(
                { key: { id: msg.message.extendedTextMessage.contextInfo.stanzaId }, message: quoted },
                'buffer',
                {},
                { logger: console }
            );
            
            const filename = `image_${Date.now()}.jpg`;
            const filePath = path.join(TEMP_DIR, filename);
            await fs.writeFile(filePath, buffer);
            return filePath;
        }
        return null;
    } catch (error) {
        console.error('Error extracting quoted image:', error);
        return null;
    }
}

async function sendImage(sock, from, imagePath, caption, quotedMsg, buttons = null) {
    try {
        const buffer = await fs.readFile(imagePath);
        
        if (buttons) {
            await buttons.send(from, {
                title: '🖼️ 𝐈𝐌𝐀𝐆𝐄 𝐑𝐄𝐀𝐃𝐘',
                text: caption + CREATOR,
                footer: '> created by wanga',
                buttons: [
                    {
                        name: 'cta_url',
                        buttonParamsJson: JSON.stringify({
                            display_text: '📢 Join Channel',
                            url: CHANNEL_LINK
                        })
                    }
                ]
            }, quotedMsg);
        }
        
        await sock.sendMessage(from, {
            image: buffer,
            caption: caption + CREATOR
        }, { quoted: quotedMsg });
        
        await fs.unlink(imagePath).catch(() => {});
        return true;
    } catch (error) {
        if (await fs.pathExists(imagePath)) {
            await fs.unlink(imagePath).catch(() => {});
        }
        throw error;
    }
}

async function sendError(sock, from, quotedMsg, customMessage = null) {
    const errorText = customMessage || `❌ *Oops!* Something went wrong.\n\nPlease try again later.\n\n> created by wanga`;
    await sock.sendMessage(from, { text: errorText }, { quoted: quotedMsg });
}

// ==================== IMAGE SEARCH ====================

commands.push({
    name: 'image',
    description: 'Search for high-quality images',
    aliases: ['img', 'picsum'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return reply(`🖼️ *𝐈𝐌𝐀𝐆𝐄 𝐒𝐄𝐀𝐑𝐂𝐇*\n\n*Usage:* ${config.PREFIX}image <search term>\n\n*Example:* ${config.PREFIX}image beautiful sunset\n\n> created by wanga`);
        }

        const query = args.join(' ');
        let tempFiles = [];

        await react('🔍');

        try {
            // Try Picsum API first (reliable)
            const response = await safeApiCall(() => axios.get(
                `https://picsum.photos/800/600?random=${Date.now()}`,
                { responseType: 'arraybuffer', timeout: TIMEOUT }
            ));
            
            const filename = `search_${Date.now()}.jpg`;
            const imagePath = path.join(TEMP_DIR, filename);
            await fs.writeFile(imagePath, response.data);
            tempFiles.push(imagePath);

            await sendImage(sock, from, imagePath,
                `🖼️ *𝐑𝐚𝐧𝐝𝐨𝐦 𝐈𝐦𝐚𝐠𝐞*\n\n*Search:* "${query}"\n📸 Source: Picsum`, 
                msg, buttons
            );

            // Also try Unsplash if available
            try {
                const unsplashResponse = await safeApiCall(() => axios.get(
                    `https://api.siputzx.my.id/api/tools/unsplash?query=${encodeURIComponent(query)}`,
                    { timeout: TIMEOUT }
                ));
                
                if (unsplashResponse.data?.data?.urls?.regular) {
                    const unsplashFilename = `unsplash_${Date.now()}.jpg`;
                    const unsplashPath = await downloadImage(unsplashResponse.data.data.urls.regular, unsplashFilename);
                    tempFiles.push(unsplashPath);
                    
                    await new Promise(resolve => setTimeout(resolve, 1500));
                    
                    await sendImage(sock, from, unsplashPath,
                        `🖼️ *𝐔𝐧𝐬𝐩𝐥𝐚𝐬𝐡 𝐈𝐦𝐚𝐠𝐞*\n\n*Search:* "${query}"\n📸 Photo by: ${unsplashResponse.data.data.user?.name || 'Unknown'}`, 
                        null, buttons
                    );
                }
            } catch (e) {
                console.log('Unsplash fallback failed:', e.message);
            }

            await react('✅');

        } catch (error) {
            bot.logger.error('Image search error:', error);
            await react('❌');
            
            let errorMsg = `❌ *No images found* for "${query}".\nTry different keywords.\n\n> created by wanga`;
            if (error.message.includes('timeout')) {
                errorMsg = `❌ *Request timed out*.\nPlease try again with a simpler search.\n\n> created by wanga`;
            }
            
            await sendError(sock, from, msg, errorMsg);

            for (const file of tempFiles) {
                if (await fs.pathExists(file)) await fs.unlink(file).catch(() => {});
            }
        }
    }
});

// ==================== IMAGE GENERATION ====================

commands.push({
    name: 'imagine',
    description: 'Generate AI images',
    aliases: ['gen', 'dream', 'imagineai'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return reply(`🎨 *𝐈𝐌𝐀𝐆𝐈𝐍𝐄 𝐀𝐈*\n\n*Usage:* ${config.PREFIX}imagine <prompt>\n\n*Example:* ${config.PREFIX}imagine a beautiful sunset over mountains\n\n> created by wanga`);
        }

        const prompt = args.join(' ');
        let tempFile = null;

        await react('🎨');

        try {
            await sock.sendMessage(from, {
                text: `🎨 *Generating your image...*\n\n*Prompt:* "${prompt}"\n\n⏱️ This may take a moment.\n\n> created by wanga`
            }, { quoted: msg });

            // Try Pollinations AI (free, reliable)
            const imageUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1024&height=1024&nologo=true`;
            
            const filename = `imagine_${Date.now()}.jpg`;
            tempFile = await downloadImage(imageUrl, filename);

            await sendImage(sock, from, tempFile, 
                `🎨 *𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐞𝐝 𝐈𝐦𝐚𝐠𝐞*\n\n*Prompt:* ${prompt}`, 
                msg, buttons
            );
            await react('✅');

        } catch (error) {
            bot.logger.error('Imagine error:', error);
            await react('❌');

            // Try fallback with DuckAI
            try {
                const formData = new FormData();
                formData.append('prompt', prompt);

                const response = await safeApiCall(() => axios({
                    method: 'POST',
                    url: 'https://api.siputzx.my.id/api/ai/duckaiimage',
                    data: formData,
                    headers: { ...formData.getHeaders() },
                    responseType: 'arraybuffer'
                }));

                const fallbackFilename = `imagine_fallback_${Date.now()}.png`;
                tempFile = path.join(TEMP_DIR, fallbackFilename);
                await fs.writeFile(tempFile, response.data);

                await sendImage(sock, from, tempFile, 
                    `🎨 *𝐆𝐞𝐧𝐞𝐫𝐚𝐭𝐞𝐝 𝐈𝐦𝐚𝐠𝐞 (Fallback)*\n\n*Prompt:* ${prompt}`, 
                    msg, buttons
                );
                await react('✅');
                
            } catch (fallbackError) {
                await sendError(sock, from, msg, 
                    `❌ *Generation failed*\n\nTry a different prompt.\n\n> created by wanga`
                );
            }

            if (tempFile && await fs.pathExists(tempFile)) {
                await fs.unlink(tempFile).catch(() => {});
            }
        }
    }
});

// ==================== LOGO CREATOR ====================

commands.push({
    name: 'create',
    description: 'Create logo/text images',
    aliases: ['logo', 'textlogo'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return reply(`🔥 *𝐂𝐑𝐄𝐀𝐓𝐄 𝐋𝐎𝐆𝐎*\n\n*Usage:* ${config.PREFIX}create <text>\n\n*Example:* ${config.PREFIX}create Megan AI\n\n> created by wanga`);
        }

        const text = args.join(' ');
        let tempFile = null;

        await react('🔥');

        try {
            await sock.sendMessage(from, {
                text: `🔥 *Creating your logo...*\n\n*Text:* "${text}"\n\n> created by wanga`
            }, { quoted: msg });

            // Use Pollinations for text-to-image
            const imageUrl = `https://image.pollinations.ai/prompt/logo%20design%20${encodeURIComponent(text)}?width=800&height=400&nologo=true`;
            
            const filename = `logo_${Date.now()}.jpg`;
            tempFile = await downloadImage(imageUrl, filename);

            await sendImage(sock, from, tempFile, 
                `🔥 *𝐋𝐨𝐠𝐨 𝐂𝐫𝐞𝐚𝐭𝐞𝐝*\n\n*Text:* ${text}`, 
                msg, buttons
            );
            await react('✅');

        } catch (error) {
            bot.logger.error('Create error:', error);
            await react('❌');
            await sendError(sock, from, msg, 
                `❌ *Couldn't create logo* for "${text}".\nTry different text.\n\n> created by wanga`
            );

            if (tempFile && await fs.pathExists(tempFile)) {
                await fs.unlink(tempFile).catch(() => {});
            }
        }
    }
});

// ==================== BEAUTIFUL EFFECT ====================

commands.push({
    name: 'beautiful',
    description: 'Add "beautiful" caption to an image',
    aliases: ['bful'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const imagePath = await getQuotedImage(msg, sock);
        
        if (!imagePath) {
            await react('❌');
            return reply(`✨ *𝐁𝐄𝐀𝐔𝐓𝐈𝐅𝐔𝐋 𝐄𝐅𝐅𝐄𝐂𝐓*\n\nPlease reply to an image with ${config.PREFIX}beautiful\n\n> created by wanga`);
        }

        let outputFile = null;

        await react('✨');

        try {
            const buffer = await fs.readFile(imagePath);
            const { url } = await uploader.uploadAuto(buffer, `beautiful_${Date.now()}.jpg`);

            const response = await safeApiCall(() => axios.get(
                'https://api.siputzx.my.id/api/canvas/beautiful',
                { params: { image: url }, responseType: 'arraybuffer', timeout: TIMEOUT }
            ));

            const filename = `beautiful_${Date.now()}.jpg`;
            outputFile = path.join(TEMP_DIR, filename);
            await fs.writeFile(outputFile, response.data);

            await sendImage(sock, from, outputFile, 
                `✨ *𝐁𝐞𝐚𝐮𝐭𝐢𝐟𝐮𝐥 𝐄𝐟𝐟𝐞𝐜𝐭 𝐀𝐩𝐩𝐥𝐢𝐞𝐝*`, 
                msg, buttons
            );
            await react('✅');

        } catch (error) {
            bot.logger.error('Beautiful effect error:', error);
            await react('❌');
            await sendError(sock, from, msg);
        } finally {
            if (await fs.pathExists(imagePath)) await fs.unlink(imagePath).catch(() => {});
            if (outputFile && await fs.pathExists(outputFile)) await fs.unlink(outputFile).catch(() => {});
        }
    }
});

// ==================== REMOVE BACKGROUND ====================

commands.push({
    name: 'removebg',
    description: 'Remove image background',
    aliases: ['nobg', 'rmbg'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const imagePath = await getQuotedImage(msg, sock);
        
        if (!imagePath) {
            await react('❌');
            return reply(`✨ *𝐑𝐄𝐌𝐎𝐕𝐄 𝐁𝐀𝐂𝐊𝐆𝐑𝐎𝐔𝐍𝐃*\n\nPlease reply to an image with ${config.PREFIX}removebg\n\n> created by wanga`);
        }

        let outputFile = null;

        await react('✨');

        try {
            const buffer = await fs.readFile(imagePath);
            const { url } = await uploader.uploadAuto(buffer, `removebg_${Date.now()}.jpg`);

            const response = await safeApiCall(() => axios.get(
                'https://api.siputzx.my.id/api/ai/removebg',
                { params: { image: url }, responseType: 'arraybuffer', timeout: TIMEOUT }
            ));

            const filename = `nobg_${Date.now()}.png`;
            outputFile = path.join(TEMP_DIR, filename);
            await fs.writeFile(outputFile, response.data);

            await sendImage(sock, from, outputFile, 
                `✨ *𝐁𝐚𝐜𝐤𝐠𝐫𝐨𝐮𝐧𝐝 𝐑𝐞𝐦𝐨𝐯𝐞𝐝*`, 
                msg, buttons
            );
            await react('✅');

        } catch (error) {
            bot.logger.error('RemoveBG error:', error);
            await react('❌');
            await sendError(sock, from, msg);
        } finally {
            if (await fs.pathExists(imagePath)) await fs.unlink(imagePath).catch(() => {});
            if (outputFile && await fs.pathExists(outputFile)) await fs.unlink(outputFile).catch(() => {});
        }
    }
});

// ==================== IMAGE MENU ====================

commands.push({
    name: 'imagemen',
    description: 'Show all image commands',
    aliases: ['imgmenu', 'imagemenu'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const menu = `🎨 *𝐈𝐌𝐀𝐆𝐄 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒*\n\n` +
            
            `*✅ 𝐀𝐕𝐀𝐈𝐋𝐀𝐁𝐋𝐄 𝐍𝐎𝐖*\n` +
            `• ${config.PREFIX}image <search> - Search images\n` +
            `• ${config.PREFIX}imagine <prompt> - Generate AI images\n` +
            `• ${config.PREFIX}create <text> - Create logo\n` +
            `• ${config.PREFIX}beautiful - Add caption to image\n` +
            `• ${config.PREFIX}removebg - Remove background\n\n` +
            
            `*📝 𝐄𝐗𝐀𝐌𝐏𝐋𝐄𝐒*\n` +
            `• ${config.PREFIX}image sunset\n` +
            `• ${config.PREFIX}imagine cyberpunk city\n` +
            `• ${config.PREFIX}create MEGAN\n` +
            `• Reply to image: ${config.PREFIX}beautiful\n\n` +
            
            `> created by wanga`;

        const buttonOptions = {
            title: '🎨 𝐈𝐌𝐀𝐆𝐄 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒',
            text: menu,
            footer: '> created by wanga',
            buttons: [
                {
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📢 Join Channel',
                        url: CHANNEL_LINK
                    })
                }
            ]
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        } else {
            await sock.sendMessage(from, { text: menu }, { quoted: msg });
        }
        await react('✅');
    }
});

module.exports = { commands };
