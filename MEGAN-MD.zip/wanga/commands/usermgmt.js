// MEGAN-MD User Management Commands - Clean version

const config = require('../../megan/config');

const commands = [];

// Helper to extract phone from various formats
const extractPhone = (input) => {
    if (!input) return null;
    let phone = input.replace('@s.whatsapp.net', '');
    phone = phone.replace(/\D/g, '');
    return phone || null;
};

// ============================================
// BLACKLIST USER - OWNER ONLY
// ============================================
commands.push({
    name: 'blacklist',
    description: 'Blacklist a user (add/remove) - Owner Only',
    aliases: ['bl'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner }) {
        
        if (!isOwner) {
            await react('❌');
            return reply(`❌ *Owner Only Command*\n\nThis command can only be used by the bot owner.\n\n> created by wanga`);
        }

        const action = args[0]?.toLowerCase();
        let target = null;

        if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length) {
            target = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
        } else if (args[1]) {
            const phone = extractPhone(args[1]);
            if (phone && phone.length >= 10) {
                target = `${phone}@s.whatsapp.net`;
            }
        }

        if (!action || !['add', 'remove'].includes(action) || !target) {
            return reply(`🚫 *BLACKLIST*\n\n*Usage:*\n${config.PREFIX}blacklist add <@user/phone>\n${config.PREFIX}blacklist remove <@user/phone>\n\nBlacklisted users cannot use the bot.\n\n> created by wanga`);
        }

        const userShort = target.split('@')[0];
        const blacklist = await bot.db.getSetting('blacklist', []);

        if (action === 'add') {
            if (!blacklist.includes(target)) {
                blacklist.push(target);
                await bot.db.setSetting('blacklist', blacklist);
                await react('✅');
                return reply(`✅ *BLACKLIST ADDED*\n\n@${userShort} has been added to the blacklist.\n\n> created by wanga`);
            } else {
                await react('⚠️');
                return reply(`⚠️ *ALREADY BLACKLISTED*\n\n@${userShort} is already in the blacklist.\n\n> created by wanga`);
            }
        } else {
            const index = blacklist.indexOf(target);
            if (index > -1) {
                blacklist.splice(index, 1);
                await bot.db.setSetting('blacklist', blacklist);
                await react('✅');
                return reply(`✅ *BLACKLIST REMOVED*\n\n@${userShort} has been removed from the blacklist.\n\n> created by wanga`);
            } else {
                await react('⚠️');
                return reply(`⚠️ *NOT IN BLACKLIST*\n\n@${userShort} is not in the blacklist.\n\n> created by wanga`);
            }
        }
    }
});

// ============================================
// WHITELIST USER - OWNER ONLY
// ============================================
commands.push({
    name: 'whitelist',
    description: 'Whitelist a user (add/remove) - Owner Only',
    aliases: ['wl'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner }) {
        
        if (!isOwner) {
            await react('❌');
            return reply(`❌ *Owner Only Command*\n\nThis command can only be used by the bot owner.\n\n> created by wanga`);
        }

        const action = args[0]?.toLowerCase();
        let target = null;

        if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length) {
            target = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
        } else if (args[1]) {
            const phone = extractPhone(args[1]);
            if (phone && phone.length >= 10) {
                target = `${phone}@s.whatsapp.net`;
            }
        }

        if (!action || !['add', 'remove'].includes(action) || !target) {
            return reply(`✅ *WHITELIST*\n\n*Usage:*\n${config.PREFIX}whitelist add <@user/phone>\n${config.PREFIX}whitelist remove <@user/phone>\n\nWhitelisted users bypass blacklist.\n\n> created by wanga`);
        }

        const userShort = target.split('@')[0];
        const whitelist = await bot.db.getSetting('whitelist', []);

        if (action === 'add') {
            if (!whitelist.includes(target)) {
                whitelist.push(target);
                await bot.db.setSetting('whitelist', whitelist);
                await react('✅');
                return reply(`✅ *WHITELIST ADDED*\n\n@${userShort} has been added to the whitelist.\n\n> created by wanga`);
            } else {
                await react('⚠️');
                return reply(`⚠️ *ALREADY WHITELISTED*\n\n@${userShort} is already in the whitelist.\n\n> created by wanga`);
            }
        } else {
            const index = whitelist.indexOf(target);
            if (index > -1) {
                whitelist.splice(index, 1);
                await bot.db.setSetting('whitelist', whitelist);
                await react('✅');
                return reply(`✅ *WHITELIST REMOVED*\n\n@${userShort} has been removed from the whitelist.\n\n> created by wanga`);
            } else {
                await react('⚠️');
                return reply(`⚠️ *NOT IN WHITELIST*\n\n@${userShort} is not in the whitelist.\n\n> created by wanga`);
            }
        }
    }
});

// ============================================
// LIST BLACKLIST - Public
// ============================================
commands.push({
    name: 'listblacklist',
    description: 'Show all blacklisted users',
    aliases: ['blacklistlist', 'bllist'],
    async execute({ msg, from, sender, args, bot, sock, react, reply }) {
        
        await react('📋');
        const blacklist = await bot.db.getSetting('blacklist', []);
        
        if (blacklist.length === 0) {
            return reply(`📋 *BLACKLIST*\n\nThe blacklist is currently empty.\n\n> created by wanga`);
        }

        let listText = `🚫 *BLACKLISTED USERS*\n\nTotal: ${blacklist.length}\n\n`;
        blacklist.forEach((jid, index) => {
            listText += `${index + 1}. @${jid.split('@')[0]}\n`;
        });
        listText += `\n> created by wanga`;

        await sock.sendMessage(from, { text: listText, mentions: blacklist }, { quoted: msg });
        await react('✅');
    }
});

// ============================================
// LIST WHITELIST - Public
// ============================================
commands.push({
    name: 'listwhitelist',
    description: 'Show all whitelisted users',
    aliases: ['whitelistlist', 'wllist'],
    async execute({ msg, from, sender, args, bot, sock, react, reply }) {
        
        await react('📋');
        const whitelist = await bot.db.getSetting('whitelist', []);
        
        if (whitelist.length === 0) {
            return reply(`📋 *WHITELIST*\n\nThe whitelist is currently empty.\n\n> created by wanga`);
        }

        let listText = `✅ *WHITELISTED USERS*\n\nTotal: ${whitelist.length}\n\n`;
        whitelist.forEach((jid, index) => {
            listText += `${index + 1}. @${jid.split('@')[0]}\n`;
        });
        listText += `\n> created by wanga`;

        await sock.sendMessage(from, { text: listText, mentions: whitelist }, { quoted: msg });
        await react('✅');
    }
});

// ============================================
// MUTE USER - OWNER ONLY
// ============================================
commands.push({
    name: 'muteuser',
    description: 'Mute a user for specified minutes - Owner Only',
    aliases: ['mute'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner }) {
        
        if (!isOwner) {
            await react('❌');
            return reply(`❌ *Owner Only Command*\n\nThis command can only be used by the bot owner.\n\n> created by wanga`);
        }

        let target = null;
        let duration = 60;

        if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length) {
            target = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
        }

        if (!target || args.length < 1) {
            return reply(`🔇 *MUTE USER*\n\n*Usage:*\n${config.PREFIX}muteuser <@user> [minutes]\n\n*Example:*\n${config.PREFIX}muteuser @user 30\n\nMutes user for specified minutes (default: 60).\n\n> created by wanga`);
        }

        if (args.length > 1) {
            duration = parseInt(args[1]);
            if (isNaN(duration) || duration < 1) duration = 60;
        }

        const userShort = target.split('@')[0];
        const mutedUntil = Date.now() + (duration * 60 * 1000);

        const muted = await bot.db.getSetting('muted', {});
        muted[target] = mutedUntil;
        await bot.db.setSetting('muted', muted);
        await react('🔇');
        
        return reply(`🔇 *USER MUTED*\n\n@${userShort} has been muted for ${duration} minute(s).\n\n> created by wanga`);
    }
});

// ============================================
// UNMUTE USER - OWNER ONLY
// ============================================
commands.push({
    name: 'unmuteuser',
    description: 'Unmute a user - Owner Only',
    aliases: ['unmute'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner }) {
        
        if (!isOwner) {
            await react('❌');
            return reply(`❌ *Owner Only Command*\n\nThis command can only be used by the bot owner.\n\n> created by wanga`);
        }

        let target = null;

        if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length) {
            target = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
        } else if (args[0]) {
            const phone = extractPhone(args[0]);
            if (phone && phone.length >= 10) {
                target = `${phone}@s.whatsapp.net`;
            }
        }

        if (!target) {
            return reply(`🔊 *UNMUTE USER*\n\n*Usage:*\n${config.PREFIX}unmuteuser <@user/phone>\n\n> created by wanga`);
        }

        const userShort = target.split('@')[0];
        const muted = await bot.db.getSetting('muted', {});

        if (muted[target]) {
            delete muted[target];
            await bot.db.setSetting('muted', muted);
            await react('🔊');
            return reply(`🔊 *USER UNMUTED*\n\n@${userShort} has been unmuted.\n\n> created by wanga`);
        } else {
            await react('⚠️');
            return reply(`⚠️ *NOT MUTED*\n\n@${userShort} is not currently muted.\n\n> created by wanga`);
        }
    }
});

// ============================================
// LIST MUTED USERS - Public
// ============================================
commands.push({
    name: 'listmuted',
    description: 'Show all muted users',
    aliases: ['mutedlist'],
    async execute({ msg, from, sender, args, bot, sock, react, reply }) {
        
        await react('📋');
        const muted = await bot.db.getSetting('muted', {});
        const now = Date.now();
        const mutedList = [];
        
        for (const [jid, until] of Object.entries(muted)) {
            if (until > now) {
                const remaining = Math.round((until - now) / 60000);
                mutedList.push({ jid, remaining });
            }
        }

        if (mutedList.length === 0) {
            return reply(`📋 *MUTED USERS*\n\nNo users are currently muted.\n\n> created by wanga`);
        }

        let listText = `🔇 *MUTED USERS*\n\nTotal: ${mutedList.length}\n\n`;
        mutedList.forEach((item, index) => {
            listText += `${index + 1}. @${item.jid.split('@')[0]} - ${item.remaining} min remaining\n`;
        });
        listText += `\n> created by wanga`;

        await sock.sendMessage(from, { text: listText, mentions: mutedList.map(m => m.jid) }, { quoted: msg });
        await react('✅');
    }
});

// ============================================
// WARN USER - OWNER ONLY
// ============================================
commands.push({
    name: 'warnuser',
    description: 'Warn a user (auto-kick after 3 warnings) - Owner Only',
    aliases: ['warn'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner }) {
        
        if (!isOwner) {
            await react('❌');
            return reply(`❌ *Owner Only Command*\n\nThis command can only be used by the bot owner.\n\n> created by wanga`);
        }

        let target = null;
        let reason = 'No reason provided';

        if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length) {
            target = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
            if (args.length > 1) {
                reason = args.slice(1).join(' ');
            }
        }

        if (!target) {
            return reply(`⚠️ *WARN USER*\n\n*Usage:*\n${config.PREFIX}warnuser <@user> [reason]\n\n*Example:*\n${config.PREFIX}warnuser @user Spamming\n\nAuto-kicks after 3 warnings.\n\n> created by wanga`);
        }

        const userShort = target.split('@')[0];
        const warns = await bot.db.getSetting('warns', {});

        if (!warns[target]) {
            warns[target] = { count: 1, reasons: [reason] };
        } else {
            warns[target].count += 1;
            warns[target].reasons.push(reason);
        }

        await bot.db.setSetting('warns', warns);
        await react('⚠️');
        
        await reply(`⚠️ *USER WARNED*\n\n@${userShort} has been warned (${warns[target].count}/3)\n*Reason:* ${reason}\n\n> created by wanga`);

        if (warns[target].count >= 3 && from.endsWith('@g.us')) {
            try {
                await sock.groupParticipantsUpdate(from, [target], 'remove');
                await reply(`👋 *USER KICKED*\n\n@${userShort} has been kicked after reaching 3 warnings.\n\n> created by wanga`);
                delete warns[target];
                await bot.db.setSetting('warns', warns);
            } catch (error) {
                console.error('Auto-kick error:', error);
            }
        }
    }
});

// ============================================
// RESET WARNS - OWNER ONLY
// ============================================
commands.push({
    name: 'resetwarns',
    description: 'Reset warnings for a user - Owner Only',
    aliases: ['rw'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner }) {
        
        if (!isOwner) {
            await react('❌');
            return reply(`❌ *Owner Only Command*\n\nThis command can only be used by the bot owner.\n\n> created by wanga`);
        }

        let target = null;

        if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length) {
            target = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
        } else if (args[0]) {
            const phone = extractPhone(args[0]);
            if (phone && phone.length >= 10) {
                target = `${phone}@s.whatsapp.net`;
            }
        }

        if (!target) {
            return reply(`🔄 *RESET WARNINGS*\n\n*Usage:*\n${config.PREFIX}resetwarns <@user/phone>\n\n> created by wanga`);
        }

        const userShort = target.split('@')[0];
        const warns = await bot.db.getSetting('warns', {});

        if (warns[target]) {
            delete warns[target];
            await bot.db.setSetting('warns', warns);
            await react('✅');
            return reply(`✅ *WARNINGS RESET*\n\nWarnings for @${userShort} have been reset.\n\n> created by wanga`);
        } else {
            await react('⚠️');
            return reply(`⚠️ *NO WARNINGS*\n\n@${userShort} has no warnings.\n\n> created by wanga`);
        }
    }
});

// ============================================
// USER INFO - Public
// ============================================
commands.push({
    name: 'userinfo',
    description: 'Get detailed user information',
    aliases: ['ui'],
    async execute({ msg, from, sender, args, bot, sock, react, reply }) {
        
        let target = sender;

        if (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length) {
            target = msg.message.extendedTextMessage.contextInfo.mentionedJid[0];
        } else if (args[0]) {
            const phone = extractPhone(args[0]);
            if (phone && phone.length >= 10) {
                target = `${phone}@s.whatsapp.net`;
            }
        }

        await react('ℹ️');

        try {
            const userShort = target.split('@')[0];

            let about = 'Not available';
            let aboutTime = 'Unknown';
            try {
                const status = await sock.fetchStatus(target);
                about = status.status || 'Not set';
                aboutTime = new Date(status.setAt).toLocaleString();
            } catch (e) {}

            let ppUrl = 'No profile picture';
            try {
                ppUrl = await sock.profilePictureUrl(target, 'image');
            } catch (e) {}

            const warns = await bot.db.getSetting('warns', {});
            const userWarns = warns[target]?.count || 0;
            const warnReasons = warns[target]?.reasons || [];

            const muted = await bot.db.getSetting('muted', {});
            const isMuted = muted[target] ? new Date(muted[target]) > new Date() : false;
            const muteRemaining = isMuted ? Math.round((muted[target] - Date.now()) / 60000) : 0;

            const blacklist = await bot.db.getSetting('blacklist', []);
            const whitelist = await bot.db.getSetting('whitelist', []);
            const isBlacklisted = blacklist.includes(target);
            const isWhitelisted = whitelist.includes(target);

            let infoText = `👤 *USER INFORMATION*\n\n` +
                `📱 *Phone:* ${userShort}\n` +
                `🆔 *JID:* ${target}\n` +
                `📝 *About:* ${about}\n` +
                `🕒 *About set:* ${aboutTime}\n\n` +
                `*STATUS*\n` +
                `━━━━━━━━━━━━━━━━━━━\n` +
                `⚠️ *Warnings:* ${userWarns}/3\n`;

            if (userWarns > 0) {
                infoText += `📋 *Reasons:* ${warnReasons.join(', ')}\n`;
            }

            infoText += `🔇 *Muted:* ${isMuted ? `Yes (${muteRemaining} min left)` : 'No'}\n` +
                `🚫 *Blacklisted:* ${isBlacklisted ? 'Yes' : 'No'}\n` +
                `✅ *Whitelisted:* ${isWhitelisted ? 'Yes' : 'No'}\n\n` +
                `> created by wanga`;

            await sock.sendMessage(from, { text: infoText, mentions: [target] }, { quoted: msg });
            await react('✅');

        } catch (error) {
            console.error('User info error:', error);
            await react('❌');
            await reply(`❌ *ERROR*\n\nFailed to get user info: ${error.message}\n\n> created by wanga`);
        }
    }
});

// ============================================
// USERMGMT HELP - Public
// ============================================
commands.push({
    name: 'usermgmt',
    description: 'Show all user management commands',
    aliases: ['userhelp', 'um'],
    async execute({ msg, from, sender, args, bot, sock, react, reply }) {
        
        const helpText = `👥 *USER MANAGEMENT COMMANDS*\n\n` +
            
            `*👑 OWNER ONLY*\n` +
            `━━━━━━━━━━━━━━━━━━━\n` +
            `• ${config.PREFIX}blacklist add <@user>\n` +
            `• ${config.PREFIX}blacklist remove <@user>\n` +
            `• ${config.PREFIX}whitelist add <@user>\n` +
            `• ${config.PREFIX}whitelist remove <@user>\n` +
            `• ${config.PREFIX}muteuser <@user> [min]\n` +
            `• ${config.PREFIX}unmuteuser <@user>\n` +
            `• ${config.PREFIX}warnuser <@user> [reason]\n` +
            `• ${config.PREFIX}resetwarns <@user>\n\n` +
            
            `*👤 PUBLIC*\n` +
            `━━━━━━━━━━━━━━━━━━━\n` +
            `• ${config.PREFIX}listblacklist\n` +
            `• ${config.PREFIX}listwhitelist\n` +
            `• ${config.PREFIX}listmuted\n` +
            `• ${config.PREFIX}userinfo <@user>\n\n` +
            
            `> created by wanga`;

        await sock.sendMessage(from, { text: helpText }, { quoted: msg });
        await react('✅');
    }
});

module.exports = { commands };
