// Ping Command - Works for owner too!

const commands = [];

commands.push({
    name: 'ping',
    description: 'Check bot response time',
    aliases: ['p'],
    async execute({ msg, from, sender, bot, sock, react, reply, isOwner }) {
        // Debug: Log who is using the command
        console.log(`📢 Ping command from: ${sender} (Owner: ${isOwner})`);
        
        const start = Date.now();
        const sentMsg = await sock.sendMessage(from, { text: '🏓 Pong!' }, { quoted: msg });
        const end = Date.now();
        const ping = end - start;
        
        await sock.sendMessage(from, {
            text: `*🏓 PONG!*\n\n📡 *Response:* ${ping}ms\n\n> created by wanga`,
            edit: sentMsg.key
        });
        
        if (react) await react('✅');
    }
});

module.exports = { commands };
