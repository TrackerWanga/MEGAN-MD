// Menu Command

const config = require('../../megan/config');

const commands = [];

commands.push({
    name: 'menu',
    description: 'Show all commands',
    aliases: ['help', 'cmds'],
    async execute({ msg, from, sender, bot, sock, react, reply }) {
        const now = new Date();
        const timeStr = now.toLocaleTimeString();
        const dateStr = now.toLocaleDateString();
        
        const uptime = process.uptime();
        const days = Math.floor(uptime / 86400);
        const hours = Math.floor((uptime % 86400) / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        
        let menu = `╭━━━━━━━━━━━━━━━━━━━╮\n`;
        menu += `┃   𝐌𝐄𝐆𝐀𝐍 𝐌𝐃   ┃\n`;
        menu += `╰━━━━━━━━━━━━━━━━━━━╯\n\n`;
        
        menu += `✧･ﾟ: ✧･ﾟ:  𝐒𝐘𝐒𝐓𝐄𝐌  :･ﾟ✧:･ﾟ✧\n`;
        menu += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        menu += `➤ 𝑽𝒆𝒓𝒔𝒊𝒐𝒏  : 3.0.0\n`;
        menu += `➤ 𝑶𝒘𝒏𝒆𝒓   : ${config.OWNER_NAME}\n`;
        menu += `➤ 𝑷𝒓𝒆𝒇𝒊𝒙  : ${config.PREFIX}\n`;
        menu += `➤ 𝑪𝒐𝒎𝒎𝒂𝒏𝒅𝒔: ${bot.commands.size}\n`;
        menu += `➤ 𝑼𝒑𝒕𝒊𝒎𝒆  : ${days}d ${hours}h ${minutes}m\n`;
        menu += `➤ 𝑻𝒊𝒎𝒆    : ${timeStr}\n`;
        menu += `➤ 𝑫𝒂𝒕𝒆    : ${dateStr}\n`;
        menu += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;
        
        menu += `╔══════════ ❖ ══════════╗\n`;
        menu += `        𝗠𝗢𝗦𝗧 𝗨𝗦𝗘𝗗        \n`;
        menu += `╚══════════ ❖ ══════════╝\n`;
        menu += `➥ ᴘɪɴɢ\n`;
        menu += `➥ ᴍᴇɴᴜ\n`;
        menu += `➥ ɪɴғᴏ\n\n`;
        
        menu += `✤✥✤✥✤✥✤✥✤✥✤✥✤✥✤✥✤✥✤✥\n`;
        menu += `   ᴘᴏᴡᴇʀᴇᴅ ʙʏ 𝐌𝐄𝐆𝐀𝐍-𝐌𝐃   \n`;
        menu += `✤✥✤✥✤✥✤✥✤✥✤✥✤✥✤✥✤✥✤✥\n`;
        menu += `✨ created by wanga ✨`;
        
        await sock.sendMessage(from, { text: menu }, { quoted: msg });
        await react('✅');
    }
});

module.exports = { commands };
