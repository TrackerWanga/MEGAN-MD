// MEGAN-MD Features Commands - Clean version with buttons

const config = require('../../megan/config');

const commands = [];

const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbCWWXi9hXF2SXUHgZ1b';

async function sendWithButtons(sock, from, text, quotedMsg, buttons) {
    const buttonOptions = {
        title: '𝐌𝐄𝐆𝐀𝐍-𝐌𝐃',
        text: text,
        footer: '> created by wanga',
        buttons: buttons || [
            {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                    display_text: '📢 Join Channel',
                    url: CHANNEL_LINK
                })
            }
        ]
    };
    
    if (buttons) {
        await buttons.send(from, buttonOptions, quotedMsg);
    } else {
        await sock.sendMessage(from, { text: text }, { quoted: quotedMsg });
    }
}

// ============================================
// AUTO-REACT - Owner Only
// ============================================
commands.push({
    name: 'autoreact',
    description: 'Toggle auto-react (on/off) - Owner Only',
    aliases: ['autoreact'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner, buttons }) {
        if (!isOwner) {
            await react('❌');
            return reply('❌ Only the owner can use this command!');
        }

        if (args.length === 0) {
            const current = await bot.db.getSetting('autoreact', 'off');
            const status = current === 'on' ? 'ON' : 'OFF';
            
            const text = `🎭 *𝐀𝐮𝐭𝐨-𝐑𝐞𝐚𝐜𝐭*\n\nCurrent: ${status}\n\n*Usage:* ${config.PREFIX}autoreact on/off\n\n> created by wanga`;
            
            return await sendWithButtons(sock, from, text, msg, buttons);
        }

        const setting = args[0].toLowerCase();
        if (setting !== 'on' && setting !== 'off') {
            return reply('❌ Please specify on or off');
        }

        await bot.db.setSetting('autoreact', setting);
        await react(setting === 'on' ? '✅' : '❌');
        
        const responseText = `✅ *Auto-react ${setting === 'on' ? 'enabled' : 'disabled'}*\n\n> created by wanga`;
        
        await sendWithButtons(sock, from, responseText, msg, buttons);
    }
});

// ============================================
// AUTO-READ - Owner Only
// ============================================
commands.push({
    name: 'autoread',
    description: 'Toggle auto-read (on/off) - Owner Only',
    aliases: ['autoread'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner, buttons }) {
        if (!isOwner) {
            await react('❌');
            return reply('❌ Only the owner can use this command!');
        }

        if (args.length === 0) {
            const current = await bot.db.getSetting('autoread', 'off');
            const status = current === 'on' ? 'ON' : 'OFF';
            
            const text = `👁️ *𝐀𝐮𝐭𝐨-𝐑𝐞𝐚𝐝*\n\nCurrent: ${status}\n\n*Usage:* ${config.PREFIX}autoread on/off\n\n> created by wanga`;
            
            return await sendWithButtons(sock, from, text, msg, buttons);
        }

        const setting = args[0].toLowerCase();
        if (setting !== 'on' && setting !== 'off') {
            return reply('❌ Please specify on or off');
        }

        await bot.db.setSetting('autoread', setting);
        await react(setting === 'on' ? '✅' : '❌');
        
        const responseText = `✅ *Auto-read ${setting === 'on' ? 'enabled' : 'disabled'}*\n\n> created by wanga`;
        
        await sendWithButtons(sock, from, responseText, msg, buttons);
    }
});

// ============================================
// AUTO-BIO - Owner Only
// ============================================
commands.push({
    name: 'autobio',
    description: 'Toggle auto-bio (on/off) - Owner Only',
    aliases: ['autobio'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner, buttons }) {
        if (!isOwner) {
            await react('❌');
            return reply('❌ Only the owner can use this command!');
        }

        if (args.length === 0) {
            const current = await bot.db.getSetting('auto_bio', 'off');
            const status = current === 'on' ? 'ON' : 'OFF';
            
            const text = `📝 *𝐀𝐮𝐭𝐨-𝐁𝐢𝐨*\n\nCurrent: ${status}\n\n*Usage:* ${config.PREFIX}autobio on/off\n\n> created by wanga`;
            
            return await sendWithButtons(sock, from, text, msg, buttons);
        }

        const setting = args[0].toLowerCase();
        if (setting !== 'on' && setting !== 'off') {
            return reply('❌ Please specify on or off');
        }

        await bot.db.setSetting('auto_bio', setting);
        await react(setting === 'on' ? '✅' : '❌');
        
        const responseText = `✅ *Auto-bio ${setting === 'on' ? 'enabled' : 'disabled'}*\n\n> created by wanga`;
        
        await sendWithButtons(sock, from, responseText, msg, buttons);
    }
});

// ============================================
// VIEW-ONCE CAPTURE - Owner Only
// ============================================
commands.push({
    name: 'autoviewonce',
    description: 'Toggle view-once capture (on/off) - Owner Only',
    aliases: ['avo'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner, buttons }) {
        if (!isOwner) {
            await react('❌');
            return reply('❌ Only the owner can use this command!');
        }

        if (args.length === 0) {
            const current = await bot.db.getSetting('auto_view_once', 'off');
            const status = current === 'on' ? 'ON' : 'OFF';
            
            const text = `🔐 *𝐕𝐢𝐞𝐰-𝐎𝐧𝐜𝐞 𝐂𝐚𝐩𝐭𝐮𝐫𝐞*\n\nCurrent: ${status}\n\nWhen ON, view-once media is saved and forwarded to owner.\n\n*Usage:* ${config.PREFIX}autoviewonce on/off\n\n> created by wanga`;
            
            return await sendWithButtons(sock, from, text, msg, buttons);
        }

        const setting = args[0].toLowerCase();
        if (setting !== 'on' && setting !== 'off') {
            return reply('❌ Please specify on or off');
        }

        await bot.db.setSetting('auto_view_once', setting);
        await react(setting === 'on' ? '✅' : '❌');
        
        const responseText = `✅ *View-once capture ${setting === 'on' ? 'enabled' : 'disabled'}*\n\n> created by wanga`;
        
        await sendWithButtons(sock, from, responseText, msg, buttons);
    }
});

// ============================================
// ANTI-LINK - Public
// ============================================
commands.push({
    name: 'antilink',
    description: 'Toggle anti-link (on/off)',
    aliases: ['al'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (args.length === 0) {
            const current = await bot.db.getSetting('antilink', 'off');
            const status = current === 'on' ? 'ON' : 'OFF';
            
            const text = `🔗 *𝐀𝐧𝐭𝐢-𝐋𝐢𝐧𝐤*\n\nCurrent: ${status}\n\n*Usage:* ${config.PREFIX}antilink on/off\n\n> created by wanga`;
            
            return await sendWithButtons(sock, from, text, msg, buttons);
        }

        const setting = args[0].toLowerCase();
        if (setting !== 'on' && setting !== 'off') {
            return reply('❌ Please specify on or off');
        }

        await bot.db.setSetting('antilink', setting);
        await react(setting === 'on' ? '✅' : '❌');
        
        const responseText = `✅ *Anti-link ${setting === 'on' ? 'enabled' : 'disabled'}*\n\n> created by wanga`;
        
        await sendWithButtons(sock, from, responseText, msg, buttons);
    }
});

commands.push({
    name: 'antilinkaction',
    description: 'Set anti-link action (delete/warn/kick)',
    aliases: ['ala'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (args.length === 0) {
            const current = await bot.db.getSetting('antilinkaction', 'delete');
            
            const text = `⚙️ *𝐀𝐧𝐭𝐢-𝐋𝐢𝐧𝐤 𝐀𝐜𝐭𝐢𝐨𝐧*\n\nCurrent: ${current}\n\nOptions: delete, warn, kick\n\n*Usage:* ${config.PREFIX}antilinkaction delete/warn/kick\n\n> created by wanga`;
            
            return await sendWithButtons(sock, from, text, msg, buttons);
        }

        const action = args[0].toLowerCase();
        if (!['delete', 'warn', 'kick'].includes(action)) {
            return reply('❌ Action must be delete, warn, or kick');
        }

        await bot.db.setSetting('antilinkaction', action);
        await react('✅');
        
        const responseText = `✅ *Anti-link action set to:* ${action}\n\n> created by wanga`;
        
        await sendWithButtons(sock, from, responseText, msg, buttons);
    }
});

// ============================================
// ANTI-CALL - Owner Only
// ============================================
commands.push({
    name: 'anticall',
    description: 'Toggle anti-call (on/off) - Owner Only',
    aliases: ['ac'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner, buttons }) {
        if (!isOwner) {
            await react('❌');
            return reply('❌ Only the owner can use this command!');
        }

        if (args.length === 0) {
            const current = await bot.db.getSetting('anticall', 'off');
            const status = current === 'on' ? 'ON' : 'OFF';
            
            const text = `📞 *𝐀𝐧𝐭𝐢-𝐂𝐚𝐥𝐥*\n\nCurrent: ${status}\n\n*Usage:* ${config.PREFIX}anticall on/off\n\n> created by wanga`;
            
            return await sendWithButtons(sock, from, text, msg, buttons);
        }

        const setting = args[0].toLowerCase();
        if (setting !== 'on' && setting !== 'off') {
            return reply('❌ Please specify on or off');
        }

        await bot.db.setSetting('anticall', setting);
        await react(setting === 'on' ? '✅' : '❌');
        
        const responseText = `✅ *Anti-call ${setting === 'on' ? 'enabled' : 'disabled'}*\n\n> created by wanga`;
        
        await sendWithButtons(sock, from, responseText, msg, buttons);
    }
});

// ============================================
// ANTI-DELETE - Owner Only
// ============================================
commands.push({
    name: 'antidelete',
    description: 'Toggle anti-delete (on/off) - Owner Only',
    aliases: ['ad'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner, buttons }) {
        if (!isOwner) {
            await react('❌');
            return reply('❌ Only the owner can use this command!');
        }

        if (args.length === 0) {
            const current = await bot.db.getSetting('antidelete', 'on');
            const status = current === 'on' ? 'ON' : 'OFF';
            
            const text = `🗑️ *𝐀𝐧𝐭𝐢-𝐃𝐞𝐥𝐞𝐭𝐞*\n\nCurrent: ${status}\n\n*Usage:* ${config.PREFIX}antidelete on/off\n\n> created by wanga`;
            
            return await sendWithButtons(sock, from, text, msg, buttons);
        }

        const setting = args[0].toLowerCase();
        if (setting !== 'on' && setting !== 'off') {
            return reply('❌ Please specify on or off');
        }

        await bot.db.setSetting('antidelete', setting);
        await react(setting === 'on' ? '✅' : '❌');
        
        const responseText = `✅ *Anti-delete ${setting === 'on' ? 'enabled' : 'disabled'}*\n\n> created by wanga`;
        
        await sendWithButtons(sock, from, responseText, msg, buttons);
    }
});

// ============================================
// ANTI-EDIT - Owner Only
// ============================================
commands.push({
    name: 'antiedit',
    description: 'Toggle edited message detection (on/off) - Owner Only',
    aliases: ['ae'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner, buttons }) {
        if (!isOwner) {
            await react('❌');
            return reply('❌ Only the owner can use this command!');
        }

        if (args.length === 0) {
            const current = await bot.db.getSetting('antiedit', 'on');
            const status = current === 'on' ? 'ON' : 'OFF';
            
            const text = `📝 *𝐀𝐧𝐭𝐢-𝐄𝐝𝐢𝐭*\n\nCurrent: ${status}\n\nWhen ON, edited messages are detected and forwarded to owner.\n\n*Usage:* ${config.PREFIX}antiedit on/off\n\n> created by wanga`;
            
            return await sendWithButtons(sock, from, text, msg, buttons);
        }

        const setting = args[0].toLowerCase();
        if (setting !== 'on' && setting !== 'off') {
            return reply('❌ Please specify on or off');
        }

        await bot.db.setSetting('antiedit', setting);
        await react(setting === 'on' ? '✅' : '❌');
        
        const responseText = `✅ *Anti-edit ${setting === 'on' ? 'enabled' : 'disabled'}*\n\n> created by wanga`;
        
        await sendWithButtons(sock, from, responseText, msg, buttons);
    }
});

// ============================================
// ANTI-DELETE STATUS - Owner Only
// ============================================
commands.push({
    name: 'antideletestatus',
    description: 'Toggle status delete detection (on/off) - Owner Only',
    aliases: ['ads'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner, buttons }) {
        if (!isOwner) {
            await react('❌');
            return reply('❌ Only the owner can use this command!');
        }

        if (args.length === 0) {
            const current = await bot.db.getSetting('antidelete_status', 'on');
            const status = current === 'on' ? 'ON' : 'OFF';
            
            const text = `📱 *𝐀𝐧𝐭𝐢-𝐃𝐞𝐥𝐞𝐭𝐞 𝐒𝐭𝐚𝐭𝐮𝐬*\n\nCurrent: ${status}\n\nWhen ON, deleted statuses are detected and recovered.\n\n*Usage:* ${config.PREFIX}antideletestatus on/off\n\n> created by wanga`;
            
            return await sendWithButtons(sock, from, text, msg, buttons);
        }

        const setting = args[0].toLowerCase();
        if (setting !== 'on' && setting !== 'off') {
            return reply('❌ Please specify on or off');
        }

        await bot.db.setSetting('antidelete_status', setting);
        await react(setting === 'on' ? '✅' : '❌');
        
        const responseText = `✅ *Status delete detection ${setting === 'on' ? 'enabled' : 'disabled'}*\n\n> created by wanga`;
        
        await sendWithButtons(sock, from, responseText, msg, buttons);
    }
});

// ============================================
// STATUS AUTO-VIEW - Owner Only
// ============================================
commands.push({
    name: 'autoviewstatus',
    description: 'Toggle auto-view status (on/off) - Owner Only',
    aliases: ['avs'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner, buttons }) {
        if (!isOwner) {
            await react('❌');
            return reply('❌ Only the owner can use this command!');
        }

        if (args.length === 0) {
            const current = await bot.db.getSetting('status_auto_view', 'off');
            const status = current === 'on' ? 'ON' : 'OFF';
            
            const text = `👁️ *𝐀𝐮𝐭𝐨-𝐕𝐢𝐞𝐰 𝐒𝐭𝐚𝐭𝐮𝐬*\n\nCurrent: ${status}\n\nWhen ON, bot automatically views all statuses.\n\n*Usage:* ${config.PREFIX}autoviewstatus on/off\n\n> created by wanga`;
            
            return await sendWithButtons(sock, from, text, msg, buttons);
        }

        const setting = args[0].toLowerCase();
        if (setting !== 'on' && setting !== 'off') {
            return reply('❌ Please specify on or off');
        }

        await bot.db.setSetting('status_auto_view', setting);
        await react(setting === 'on' ? '✅' : '❌');
        
        const responseText = `✅ *Auto-view status ${setting === 'on' ? 'enabled' : 'disabled'}*\n\n> created by wanga`;
        
        await sendWithButtons(sock, from, responseText, msg, buttons);
    }
});

// ============================================
// STATUS AUTO-REACT - Owner Only
// ============================================
commands.push({
    name: 'autoreactstatus',
    description: 'Toggle auto-react status (on/off) - Owner Only',
    aliases: ['ars'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner, buttons }) {
        if (!isOwner) {
            await react('❌');
            return reply('❌ Only the owner can use this command!');
        }

        if (args.length === 0) {
            const current = await bot.db.getSetting('status_auto_react', 'off');
            const status = current === 'on' ? 'ON' : 'OFF';
            
            const text = `❤️ *𝐀𝐮𝐭𝐨-𝐑𝐞𝐚𝐜𝐭 𝐒𝐭𝐚𝐭𝐮𝐬*\n\nCurrent: ${status}\n\nWhen ON, bot reacts to statuses with random emojis.\n\n*Usage:* ${config.PREFIX}autoreactstatus on/off\n\n> created by wanga`;
            
            return await sendWithButtons(sock, from, text, msg, buttons);
        }

        const setting = args[0].toLowerCase();
        if (setting !== 'on' && setting !== 'off') {
            return reply('❌ Please specify on or off');
        }

        await bot.db.setSetting('status_auto_react', setting);
        await react(setting === 'on' ? '✅' : '❌');
        
        const responseText = `✅ *Auto-react status ${setting === 'on' ? 'enabled' : 'disabled'}*\n\n> created by wanga`;
        
        await sendWithButtons(sock, from, responseText, msg, buttons);
    }
});

// ============================================
// STATUS AUTO-DOWNLOAD - Owner Only
// ============================================
commands.push({
    name: 'autodownloadstatus',
    description: 'Toggle auto-download status (on/off) - Owner Only',
    aliases: ['ads'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner, buttons }) {
        if (!isOwner) {
            await react('❌');
            return reply('❌ Only the owner can use this command!');
        }

        if (args.length === 0) {
            const current = await bot.db.getSetting('status_auto_download', 'off');
            const status = current === 'on' ? 'ON' : 'OFF';
            
            const text = `⬇️ *𝐀𝐮𝐭𝐨-𝐃𝐨𝐰𝐧𝐥𝐨𝐚𝐝 𝐒𝐭𝐚𝐭𝐮𝐬*\n\nCurrent: ${status}\n\nWhen ON, status media is downloaded and forwarded to owner.\n\n*Usage:* ${config.PREFIX}autodownloadstatus on/off\n\n> created by wanga`;
            
            return await sendWithButtons(sock, from, text, msg, buttons);
        }

        const setting = args[0].toLowerCase();
        if (setting !== 'on' && setting !== 'off') {
            return reply('❌ Please specify on or off');
        }

        await bot.db.setSetting('status_auto_download', setting);
        await react(setting === 'on' ? '✅' : '❌');
        
        const responseText = `✅ *Auto-download status ${setting === 'on' ? 'enabled' : 'disabled'}*\n\n> created by wanga`;
        
        await sendWithButtons(sock, from, responseText, msg, buttons);
    }
});

// ============================================
// SET STATUS EMOJIS - Owner Only
// ============================================
commands.push({
    name: 'setstatusemoji',
    description: 'Set emojis for status reactions',
    aliases: ['ssemoji'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner, buttons }) {
        if (!isOwner) {
            await react('❌');
            return reply('❌ Only the owner can use this command!');
        }

        if (args.length === 0) {
            const current = await bot.db.getSetting('status_react_emojis', '💛,❤️,💜,💙,👍,🔥');
            
            const text = `🎯 *𝐒𝐭𝐚𝐭𝐮𝐬 𝐑𝐞𝐚𝐜𝐭𝐢𝐨𝐧 𝐄𝐦𝐨𝐣𝐢𝐬*\n\nCurrent: ${current}\n\n*Usage:* ${config.PREFIX}setstatusemoji ❤️,👍,🔥,✨\n\nSeparate emojis with commas.\n\n> created by wanga`;
            
            return await sendWithButtons(sock, from, text, msg, buttons);
        }

        const emojis = args.join(' ');
        await bot.db.setSetting('status_react_emojis', emojis);
        await react('✅');
        
        const responseText = `✅ *Status reaction emojis updated to:* ${emojis}\n\n> created by wanga`;
        
        await sendWithButtons(sock, from, responseText, msg, buttons);
    }
});

// ============================================
// PRESENCE FEATURES - Owner Only
// ============================================
commands.push({
    name: 'presencepm',
    description: 'Set presence in private messages - Owner Only',
    aliases: ['ppm'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner, buttons }) {
        if (!isOwner) {
            await react('❌');
            return reply('❌ Only the owner can use this command!');
        }

        if (args.length === 0) {
            const current = await bot.db.getSetting('presence_pm', 'typing');
            
            const text = `💬 *𝐏𝐫𝐞𝐬𝐞𝐧𝐜𝐞 𝐏𝐌*\n\nCurrent: ${current}\n\nOptions: online, typing, recording, offline\n\n*Usage:* ${config.PREFIX}presencepm online/typing/recording/offline\n\n> created by wanga`;
            
            return await sendWithButtons(sock, from, text, msg, buttons);
        }

        const presence = args[0].toLowerCase();
        if (!['online', 'typing', 'recording', 'offline'].includes(presence)) {
            return reply('❌ Presence must be online, typing, recording, or offline');
        }

        await bot.db.setSetting('presence_pm', presence);
        await react('✅');
        
        const responseText = `✅ *Presence in PMs set to:* ${presence}\n\n> created by wanga`;
        
        await sendWithButtons(sock, from, responseText, msg, buttons);
    }
});

commands.push({
    name: 'presencegroup',
    description: 'Set presence in groups - Owner Only',
    aliases: ['pg'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner, buttons }) {
        if (!isOwner) {
            await react('❌');
            return reply('❌ Only the owner can use this command!');
        }

        if (args.length === 0) {
            const current = await bot.db.getSetting('presence_group', 'typing');
            
            const text = `👥 *𝐏𝐫𝐞𝐬𝐞𝐧𝐜𝐞 𝐆𝐫𝐨𝐮𝐩*\n\nCurrent: ${current}\n\nOptions: online, typing, recording, offline\n\n*Usage:* ${config.PREFIX}presencegroup online/typing/recording/offline\n\n> created by wanga`;
            
            return await sendWithButtons(sock, from, text, msg, buttons);
        }

        const presence = args[0].toLowerCase();
        if (!['online', 'typing', 'recording', 'offline'].includes(presence)) {
            return reply('❌ Presence must be online, typing, recording, or offline');
        }

        await bot.db.setSetting('presence_group', presence);
        await react('✅');
        
        const responseText = `✅ *Presence in groups set to:* ${presence}\n\n> created by wanga`;
        
        await sendWithButtons(sock, from, responseText, msg, buttons);
    }
});

commands.push({
    name: 'autotyping',
    description: 'Show typing indicator (dm/group/both/off) - Owner Only',
    aliases: ['atyping'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner, buttons }) {
        if (!isOwner) {
            await react('❌');
            return reply('❌ Only the owner can use this command!');
        }

        if (args.length === 0) {
            const current = await bot.db.getSetting('autotyping', 'off');
            
            const text = `⌨️ *𝐀𝐮𝐭𝐨 𝐓𝐲𝐩𝐢𝐧𝐠*\n\nCurrent: ${current}\n\nOptions: dm, group, both, off\n\n*Usage:* ${config.PREFIX}autotyping dm/group/both/off\n\n> created by wanga`;
            
            return await sendWithButtons(sock, from, text, msg, buttons);
        }

        const setting = args[0].toLowerCase();
        if (!['dm', 'group', 'both', 'off'].includes(setting)) {
            return reply('❌ Option must be dm, group, both, or off');
        }

        await bot.db.setSetting('autotyping', setting);
        await react('✅');
        
        const responseText = `✅ *Auto typing set to:* ${setting}\n\n> created by wanga`;
        
        await sendWithButtons(sock, from, responseText, msg, buttons);
    }
});

commands.push({
    name: 'autorecording',
    description: 'Show recording indicator (dm/group/both/off) - Owner Only',
    aliases: ['arec'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, isOwner, buttons }) {
        if (!isOwner) {
            await react('❌');
            return reply('❌ Only the owner can use this command!');
        }

        if (args.length === 0) {
            const current = await bot.db.getSetting('autorecording', 'off');
            
            const text = `🎤 *𝐀𝐮𝐭𝐨 𝐑𝐞𝐜𝐨𝐫𝐝𝐢𝐧𝐠*\n\nCurrent: ${current}\n\nOptions: dm, group, both, off\n\n*Usage:* ${config.PREFIX}autorecording dm/group/both/off\n\n> created by wanga`;
            
            return await sendWithButtons(sock, from, text, msg, buttons);
        }

        const setting = args[0].toLowerCase();
        if (!['dm', 'group', 'both', 'off'].includes(setting)) {
            return reply('❌ Option must be dm, group, both, or off');
        }

        await bot.db.setSetting('autorecording', setting);
        await react('✅');
        
        const responseText = `✅ *Auto recording set to:* ${setting}\n\n> created by wanga`;
        
        await sendWithButtons(sock, from, responseText, msg, buttons);
    }
});

// ============================================
// FEATURES HELP - Public
// ============================================
commands.push({
    name: 'features',
    description: 'Show all feature toggle commands',
    aliases: ['featurehelp', 'toggles'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const prefix = config.PREFIX;
        
        const helpText = `⚙️ *𝐅𝐄𝐀𝐓𝐔𝐑𝐄 𝐓𝐎𝐆𝐆𝐋𝐄𝐒*\n\n` +
            
            `*𝐀𝐔𝐓𝐎 (Owner)*\n` +
            `• ${prefix}autoreact on/off\n` +
            `• ${prefix}autoread on/off\n` +
            `• ${prefix}autobio on/off\n` +
            `• ${prefix}autoviewonce on/off\n\n` +
            
            `*𝐀𝐍𝐓𝐈 (Owner)*\n` +
            `• ${prefix}antidelete on/off\n` +
            `• ${prefix}antiedit on/off\n` +
            `• ${prefix}anticall on/off\n` +
            `• ${prefix}antideletestatus on/off\n\n` +
            
            `*𝐀𝐍𝐓𝐈-𝐋𝐈𝐍𝐊 (Public)*\n` +
            `• ${prefix}antilink on/off\n` +
            `• ${prefix}antilinkaction delete/warn/kick\n\n` +
            
            `*𝐒𝐓𝐀𝐓𝐔𝐒 (Owner)*\n` +
            `• ${prefix}autoviewstatus on/off\n` +
            `• ${prefix}autoreactstatus on/off\n` +
            `• ${prefix}autodownloadstatus on/off\n` +
            `• ${prefix}setstatusemoji ❤️,👍,🔥\n\n` +
            
            `*𝐏𝐑𝐄𝐒𝐄𝐍𝐂𝐄 (Owner)*\n` +
            `• ${prefix}presencepm online/typing/recording/offline\n` +
            `• ${prefix}presencegroup online/typing/recording/offline\n` +
            `• ${prefix}autotyping dm/group/both/off\n` +
            `• ${prefix}autorecording dm/group/both/off\n\n` +
            
            `> created by wanga`;

        await sendWithButtons(sock, from, helpText, msg, buttons);
        await react('✅');
    }
});

module.exports = { commands };
