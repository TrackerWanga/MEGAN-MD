// MEGAN-MD Basic Commands - Clean version with buttons

const config = require('../../megan/config');
const moment = require('moment-timezone');
const os = require('os');

const commands = [];

const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbCWWXi9hXF2SXUHgZ1b';

async function sendWithButtons(sock, from, text, quotedMsg, buttons) {
    const buttonOptions = {
        title: '𝐌𝐄𝐆𝐀𝐍-𝐌𝐃',
        text: text,
        footer: '> created by wanga',
        buttons: buttons || [
            {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                    display_text: '📢 Join Channel',
                    url: CHANNEL_LINK
                })
            }
        ]
    };
    
    if (buttons) {
        await buttons.send(from, buttonOptions, quotedMsg);
    } else {
        await sock.sendMessage(from, { text: text }, { quoted: quotedMsg });
    }
}

// ==================== PING COMMAND ====================
commands.push({
    name: 'ping',
    description: 'Check bot response time',
    aliases: ['p'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const start = Date.now();
        const sentMsg = await sock.sendMessage(from, { text: '🏓 Pong!' }, { quoted: msg });
        const end = Date.now();
        const ping = end - start;
        
        const resultText = `*🏓 PONG!*\n\n📡 *Response:* ${ping}ms\n\n> created by wanga`;

        await sock.sendMessage(from, { text: resultText, edit: sentMsg.key }, { quoted: msg });
        await sendWithButtons(sock, from, resultText, msg, buttons);
    }
});

// ==================== UPTIME COMMAND ====================
commands.push({
    name: 'uptime',
    description: 'Show bot uptime',
    aliases: ['runtime'],
    async execute({ msg, from, sender, bot, sock, react, reply, buttons }) {
        const uptime = process.uptime();
        const days = Math.floor(uptime / 86400);
        const hours = Math.floor((uptime % 86400) / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        const seconds = Math.floor(uptime % 60);

        const resultText = `*⏱️ UPTIME*\n\n📅 *Days:* ${days}\n⏰ *Hours:* ${hours}\n⏱️ *Minutes:* ${minutes}\n⏲️ *Seconds:* ${seconds}\n\n> created by wanga`;

        await sendWithButtons(sock, from, resultText, msg, buttons);
    }
});

// ==================== INFO COMMAND ====================
commands.push({
    name: 'info',
    description: 'Show bot information',
    aliases: ['bot'],
    async execute({ msg, from, sender, bot, sock, react, reply, buttons }) {
        const now = moment().tz(config.TIMEZONE || 'Africa/Nairobi');
        const timeStr = now.format('h:mm A');
        const dateStr = now.format('DD/MM/YYYY');
        
        const uptime = process.uptime();
        const days = Math.floor(uptime / 86400);
        const hours = Math.floor((uptime % 86400) / 3600);
        
        const totalMem = os.totalmem() / (1024 * 1024 * 1024);
        const freeMem = os.freemem() / (1024 * 1024 * 1024);
        const usedMem = (totalMem - freeMem).toFixed(2);
        const totalMemFixed = totalMem.toFixed(2);

        const infoText = `📱 *𝐁𝐎𝐓 𝐈𝐍𝐅𝐎*\n\n` +
            `👤 *Owner:* ${config.OWNER_NAME}\n` +
            `📞 *Phone:* ${config.OWNER_NUMBER}\n` +
            `🤖 *Bot:* ${config.BOT_NAME}\n` +
            `🔧 *Prefix:* ${config.PREFIX}\n` +
            `⚙️ *Mode:* ${config.MODE}\n` +
            `📚 *Commands:* ${bot.commands.size}\n` +
            `⏱️ *Uptime:* ${days}d ${hours}h\n` +
            `🕒 *Time:* ${timeStr}\n` +
            `📅 *Date:* ${dateStr}\n` +
            `💾 *RAM:* ${usedMem}GB/${totalMemFixed}GB\n\n` +
            `> created by wanga`;

        await sendWithButtons(sock, from, infoText, msg, buttons);
        await react('✅');
    }
});

// ==================== MAIN MENU COMMAND ====================
commands.push({
    name: 'menu',
    description: 'Show all commands',
    aliases: ['help', 'cmds'],
    async execute({ msg, from, sender, bot, sock, react, reply, buttons }) {
        
        const now = moment().tz(config.TIMEZONE || 'Africa/Nairobi');
        const timeStr = now.format('h:mm A');
        const dateStr = now.format('DD/MM/YYYY');
        
        const uptime = process.uptime();
        const days = Math.floor(uptime / 86400);
        const hours = Math.floor((uptime % 86400) / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        
        const totalMem = os.totalmem() / (1024 * 1024 * 1024);
        const freeMem = os.freemem() / (1024 * 1024 * 1024);
        const usedMem = (totalMem - freeMem).toFixed(2);
        const totalMemFixed = totalMem.toFixed(2);

        let menu = `        𝐌𝐄𝐆𝐀𝐍 𝐌𝐃\n\n`;

        menu += `✧･ﾟ: ✧･ﾟ:  𝐒𝐘𝐒𝐓𝐄𝐌  :･ﾟ✧:･ﾟ✧\n`;
        menu += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        menu += `➤ 𝑽𝒆𝒓𝒔𝒊𝒐𝒏  : 3.0.0\n`;
        menu += `➤ 𝑶𝒘𝒏𝒆𝒓   : ${config.OWNER_NAME}\n`;
        menu += `➤ 𝑷𝒍𝒂𝒕𝒇𝒐𝒓𝒎 : Ubuntu 20.04\n`;
        menu += `➤ 𝑷𝒓𝒆𝒇𝒊𝒙  : ${config.PREFIX}\n`;
        menu += `➤ 𝑪𝒐𝒎𝒎𝒂𝒏𝒅𝒔: ${bot.commands.size}\n`;
        menu += `➤ 𝑼𝒑𝒕𝒊𝒎𝒆  : ${days}d ${hours}h ${minutes}m\n`;
        menu += `➤ 𝑻𝒊𝒎𝒆    : ${timeStr}\n`;
        menu += `➤ 𝑫𝒂𝒕𝒆    : ${dateStr}\n`;
        menu += `➤ 𝑹𝑨𝑴     : ${usedMem}GB/${totalMemFixed}GB\n`;
        menu += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n`;

        menu += `        𝗠𝗢𝗦𝗧 𝗨𝗦𝗘𝗗\n`;
        menu += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        menu += `➥ ᴍᴇɢᴀɴ\n`;
        menu += `➥ ᴍᴏᴠɪᴇ\n`;
        menu += `➥ ᴋᴇɴʏᴀɴᴇᴡs\n`;
        menu += `➥ ᴘʟᴀʏ\n`;
        menu += `➥ ᴅʟ\n`;
        menu += `➥ ʙʀᴏᴡsᴇ\n`;
        menu += `➥ sᴘᴏᴛɪғʏ\n`;
        menu += `➥ ɢᴀᴍᴇs\n\n`;

        menu += `            𝗔𝗜\n`;
        menu += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        menu += `➥ ᴍᴇɢᴀɴ\n`;
        menu += `➥ ᴍᴇɢᴀɴ-ᴘʀᴏ\n`;
        menu += `➥ ɢᴇᴍɪɴɪ\n`;
        menu += `➥ ɢᴇᴍɪɴɪ-ʟɪᴛᴇ\n`;
        menu += `➥ ɢᴘᴛ\n`;
        menu += `➥ ᴅᴇᴇᴘsᴇᴇᴋ\n`;
        menu += `➥ ɢʟᴍ\n`;
        menu += `➥ ᴘʜɪ\n`;
        menu += `➥ ǫᴡᴇɴ\n`;
        menu += `➥ ʟʟᴀᴍᴀ\n`;
        menu += `➥ ᴍɪsᴛʀᴀʟ\n`;
        menu += `➥ ᴅᴜᴄᴋᴀɪ\n`;
        menu += `➥ ʙɪʙʟᴇᴀɪ\n`;
        menu += `➥ ɢɪᴛᴀ\n`;
        menu += `➥ ᴛᴇᴀᴄʜᴇʀ\n`;
        menu += `➥ ᴄᴏᴅᴇʟʟᴀᴍᴀ\n`;
        menu += `➥ ʀᴇᴘʟɪᴛ\n`;
        menu += `➥ ᴡᴏʀᴍɢᴘᴛ\n`;
        menu += `➥ ᴄʜᴀᴛɢʟᴍ\n`;
        menu += `➥ ɴᴇᴍᴏᴛʀᴏɴ\n`;
        menu += `➥ ᴄᴏᴍᴍᴀɴᴅ\n`;
        menu += `➥ ᴏʀᴄᴀ\n`;
        menu += `➥ ᴛɪɴʏʟʟᴀᴍᴀ\n`;
        menu += `➥ ʏɪ\n`;
        menu += `➥ ᴏᴘᴇɴʜᴇʀᴍᴇs\n`;
        menu += `➥ ɴᴏᴜs\n`;
        menu += `➥ ᴅᴏʟᴘʜɪɴ\n`;
        menu += `➥ ᴢᴇᴘʜʏʀ\n`;
        menu += `➥ ɢʀᴏǫ\n`;
        menu += `➥ sᴇᴛʙɪʙʟᴇᴠᴇʀsɪᴏɴ\n`;
        menu += `➥ ᴀɪᴍᴏᴅᴇ\n`;
        menu += `➥ ᴀɪᴍᴇɴᴜ\n\n`;

        menu += `         𝗔𝗜 𝗜𝗠𝗔𝗚𝗘\n`;
        menu += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        menu += `➥ ɪᴍᴀɢᴇ\n`;
        menu += `➥ ɪᴍᴀɢᴇs\n`;
        menu += `➥ ᴘɪɴᴛᴇʀᴇsᴛ\n`;
        menu += `➥ ᴡᴀʟʟᴘᴀᴘᴇʀ\n`;
        menu += `➥ ɪᴍᴀɢɪɴᴇ\n`;
        menu += `➥ ᴄʀᴇᴀᴛᴇ\n`;
        menu += `➥ ʙᴇᴀᴜᴛɪғᴜʟ\n`;
        menu += `➥ ᴄɪʀᴄʟᴇ\n`;
        menu += `➥ ғɪʟᴛᴇʀ\n`;
        menu += `➥ ʀᴇᴍᴏᴠᴇʙɢ\n`;
        menu += `➥ ᴜᴘsᴄᴀʟᴇ\n`;
        menu += `➥ sᴅxʟ\n`;
        menu += `➥ ғʟᴜx\n`;
        menu += `➥ ɪᴍᴀɢᴇᴍᴇɴ\n\n`;

        menu += `          𝗕𝗥𝗢𝗪𝗦𝗘\n`;
        menu += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        menu += `➥ ʙʀᴏᴡsᴇ\n`;
        menu += `➥ sᴜʙᴅᴏᴍᴀɪɴs\n`;
        menu += `➥ ᴛɪɴʏᴜʀʟ\n\n`;

        menu += `        𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗𝗘𝗥\n`;
        menu += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        menu += `➥ ᴘʟᴀʏ\n`;
        menu += `➥ ʏᴛᴍᴘ𝟹\n`;
        menu += `➥ ʏᴛᴍᴘ𝟺\n`;
        menu += `➥ sᴘᴏᴛɪғʏᴅʟ\n`;
        menu += `➥ sᴏᴜɴᴅᴄʟᴏᴜᴅ\n`;
        menu += `➥ ᴛɪᴋᴛᴏᴋᴅʟ\n`;
        menu += `➥ ɪɴsᴛᴀɢʀᴀᴍᴅʟ\n`;
        menu += `➥ ғᴀᴄᴇʙᴏᴏᴋᴅʟ\n`;
        menu += `➥ ᴛᴡɪᴛᴛᴇʀᴅʟ\n`;
        menu += `➥ ɢᴅʀɪᴠᴇᴅʟ\n`;
        menu += `➥ ᴄᴀᴘᴄᴜᴛ\n`;
        menu += `➥ sᴀᴠᴇғʀᴏᴍ\n`;
        menu += `➥ ᴅʟғɪʟᴇs\n\n`;

        menu += `      𝗘𝗣𝗛𝗢𝗧𝗢 𝗘𝗙𝗙𝗘𝗖𝗧𝗦\n`;
        menu += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        menu += `➥ 𝟷𝟿𝟷𝟽sᴛʏʟᴇ\n`;
        menu += `➥ ᴀᴅᴠᴀɴᴄᴇᴅɢʟᴏᴡ\n`;
        menu += `➥ ʙʟᴀᴄᴋᴘɪɴᴋʟᴏɢᴏ\n`;
        menu += `➥ ʙʟᴀᴄᴋᴘɪɴᴋsᴛʏʟᴇ\n`;
        menu += `➥ ᴄᴀʀᴛᴏᴏɴsᴛʏʟᴇ\n`;
        menu += `➥ ᴅʀᴀɢᴏɴʙᴀʟʟ\n`;
        menu += `➥ ɢᴀʟᴀxʏsᴛʏʟᴇ\n`;
        menu += `➥ ɢʟɪᴛᴄʜᴛᴇxᴛ\n`;
        menu += `➥ ɢʟᴏᴡɪɴɢᴛᴇxᴛ\n`;
        menu += `➥ ɢʀᴀᴅɪᴇɴᴛᴛᴇxᴛ\n`;
        menu += `➥ ɢʀᴀғғɪᴛɪ\n`;
        menu += `➥ ʟᴜxᴜʀʏɢᴏʟᴅ\n`;
        menu += `➥ ᴍᴀᴛʀɪx\n`;
        menu += `➥ ɴᴇᴏɴɢʟɪᴛᴄʜ\n`;
        menu += `➥ sᴀɴᴅ\n`;
        menu += `➥ ᴡᴀᴛᴇʀᴄᴏʟᴏʀᴛᴇxᴛ\n\n`;

        menu += `          𝗚𝗥𝗢𝗨𝗣\n`;
        menu += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        menu += `➥ ᴄʀᴇᴀᴛᴇɢʀᴏᴜᴘ\n`;
        menu += `➥ ɢʀᴏᴜᴘɪɴғᴏ\n`;
        menu += `➥ ᴛᴀɢᴀʟʟ\n`;
        menu += `➥ ᴛᴀɢᴀᴅᴍɪɴs\n`;
        menu += `➥ ɪɴᴠɪᴛᴇ\n`;
        menu += `➥ ᴊᴏɪɴ\n`;
        menu += `➥ ʟᴇᴀᴠᴇ\n`;
        menu += `➥ ʟᴏᴄᴋ\n`;
        menu += `➥ ᴘᴏʟʟ\n\n`;

        menu += `          𝗠𝗘𝗗𝗜𝗔\n`;
        menu += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        menu += `➥ sᴛɪᴄᴋᴇʀ\n`;
        menu += `➥ ᴛᴏɪᴍᴀɢᴇ\n`;
        menu += `➥ sᴀʏ\n`;
        menu += `➥ ᴠᴏɪᴄᴇ\n`;
        menu += `➥ ᴛᴏᴀᴜᴅɪᴏ\n`;
        menu += `➥ ᴄᴀᴛʙᴏx\n`;
        menu += `➥ ᴡᴀɪғᴜ\n`;
        menu += `➥ ɴᴇᴋᴏ\n`;
        menu += `➥ ᴍᴇᴍᴇ\n`;
        menu += `➥ ᴄʟᴇᴀɴᴛᴇᴍᴘ\n`;
        menu += `➥ ᴛᴇxᴛᴘʀᴏ\n\n`;

        menu += `          𝗡𝗘𝗪𝗦\n`;
        menu += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        menu += `➥ ɴᴇᴡsᴛᴏᴘ\n`;
        menu += `➥ ᴛᴇᴄʜɴᴇᴡs\n`;
        menu += `➥ sᴘᴏʀᴛsɴᴇᴡs\n`;
        menu += `➥ ᴋᴇɴʏᴀɴᴇᴡs\n\n`;

        menu += `          𝗢𝗪𝗡𝗘𝗥\n`;
        menu += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        menu += `➥ sᴇᴛᴘʀᴇғɪx\n`;
        menu += `➥ sᴇᴛʙᴏᴛɴᴀᴍᴇ\n`;
        menu += `➥ sᴇᴛᴍᴏᴅᴇ\n`;
        menu += `➥ sᴇᴛᴏᴡɴᴇʀɴᴀᴍᴇ\n`;
        menu += `➥ sᴇᴛʙɪᴏ\n`;
        menu += `➥ ʙʟᴏᴄᴋ\n`;
        menu += `➥ ᴜɴʙʟᴏᴄᴋ\n`;
        menu += `➥ ʙʟᴀᴄᴋʟɪsᴛ\n`;
        menu += `➥ ᴡʜɪᴛᴇʟɪsᴛ\n`;
        menu += `➥ ᴍᴜᴛᴇᴜsᴇʀ\n`;
        menu += `➥ ᴡᴀʀɴᴜsᴇʀ\n`;
        menu += `➥ ʀᴇsᴇᴛᴡᴀʀɴs\n`;
        menu += `➥ ᴀᴜᴛᴏʀᴇᴀᴄᴛ\n`;
        menu += `➥ ᴀᴜᴛᴏʀᴇᴀᴅ\n`;
        menu += `➥ ᴀɴᴛɪᴅᴇʟᴇᴛᴇ\n`;
        menu += `➥ ᴀɴᴛɪᴄᴀʟʟ\n`;
        menu += `➥ ғᴇᴀᴛᴜʀᴇs\n\n`;

        menu += `         𝗦𝗘𝗔𝗥𝗖𝗛\n`;
        menu += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        menu += `➥ ɢᴏᴏɢʟᴇ\n`;
        menu += `➥ ʙɪɴɢ\n`;
        menu += `➥ ᴅᴜᴄᴋᴅᴜᴄᴋɢᴏ\n`;
        menu += `➥ ᴡɪᴋɪ\n`;
        menu += `➥ ᴅɪᴄᴛɪᴏɴᴀʀʏ\n`;
        menu += `➥ ᴛʜᴇsᴀᴜʀᴜs\n`;
        menu += `➥ ᴍᴏᴠɪᴇ\n`;
        menu += `➥ ᴀɴɪᴍᴇ\n`;
        menu += `➥ ʏᴏᴜᴛᴜʙᴇ\n`;
        menu += `➥ sᴘᴏᴛɪғʏsᴇᴀʀᴄʜ\n`;
        menu += `➥ ʟʏʀɪᴄs\n`;
        menu += `➥ ᴡᴇᴀᴛʜᴇʀ\n`;
        menu += `➥ ɢɪᴛʜᴜʙ\n`;
        menu += `➥ ɴᴘᴍ\n`;
        menu += `➥ ʙɪʙʟᴇ\n`;
        menu += `➥ ǫᴜʀᴀɴ\n\n`;

        menu += `        𝗦𝗘𝗧𝗧𝗜𝗡𝗚𝗦\n`;
        menu += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        menu += `➥ ᴍʏᴘɪᴄ\n`;
        menu += `➥ ᴍʏᴀʙᴏᴜᴛ\n`;
        menu += `➥ ʟɪsᴛʙʟᴏᴄᴋᴇᴅ\n`;
        menu += `➥ ᴀɴᴛɪʟɪɴᴋ\n`;
        menu += `➥ sᴀᴠᴇ\n`;
        menu += `➥ ᴠᴠ\n`;
        menu += `➥ sᴛᴀᴛᴜsʜᴇʟᴘ\n\n`;

        menu += `          𝗧𝗢𝗢𝗟𝗦\n`;
        menu += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        menu += `➥ ʙɪɴᴀʀʏ\n`;
        menu += `➥ ʙᴀsᴇ𝟼𝟺\n`;
        menu += `➥ ʜᴀsʜ\n`;
        menu += `➥ ᴍᴏʀsᴇ\n`;
        menu += `➥ ᴇɴᴄʀʏᴘᴛ\n`;
        menu += `➥ ᴅᴇᴄʀʏᴘᴛ\n`;
        menu += `➥ ᴘᴀssᴡᴏʀᴅ\n`;
        menu += `➥ ᴠᴄᴄ\n`;
        menu += `➥ ᴇᴍᴀɪʟ\n`;
        menu += `➥ ᴜᴜɪᴅ\n`;
        menu += `➥ ᴄᴀʟᴄᴜʟᴀᴛᴇ\n`;
        menu += `➥ ғʟɪᴘᴛᴇxᴛ\n`;
        menu += `➥ ᴇᴍᴏᴊɪᴍɪx\n`;
        menu += `➥ ᴢᴏᴅɪᴀᴋ\n`;
        menu += `➥ ᴘɪɴɢ\n`;
        menu += `➥ ᴜᴘᴛɪᴍᴇ\n`;
        menu += `➥ ɪɴғᴏ\n`;
        menu += `➥ ᴛᴏᴏʟs\n\n`;

        menu += `       𝗛𝗘𝗟𝗣𝗘𝗥 𝗠𝗘𝗡𝗨𝗦\n`;
        menu += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        menu += `➥ ᴀɪᴍᴇɴᴜ\n`;
        menu += `➥ ɪᴍᴀɢᴇᴍᴇɴ\n`;
        menu += `➥ ᴇᴘʜᴏᴛᴏᴍᴇɴᴜ\n`;
        menu += `➥ ɢʀᴏᴜᴘʜᴇʟᴘ\n`;
        menu += `➥ ғᴇᴀᴛᴜʀᴇs\n`;
        menu += `➥ sᴇᴀʀᴄʜʜᴇʟᴘ\n`;
        menu += `➥ ᴛᴏᴏʟs\n`;
        menu += `➥ ᴜsᴇʀᴍɢᴍᴛ\n`;
        menu += `➥ ᴄʜᴀᴛʜᴇʟᴘ\n\n`;

        menu += `✤✥✤✥✤✥✤✥✤✥✤✥✤✥✤✥✤✥✤✥\n`;
        menu += `   ᴘᴏᴡᴇʀᴇᴅ ʙʏ 𝐌𝐄𝐆𝐀𝐍-𝐌𝐃   \n`;
        menu += `✤✥✤✥✤✥✤✥✤✥✤✥✤✥✤✥✤✥✤✥\n`;
        menu += `✨ created by wanga ✨`;

        await sendWithButtons(sock, from, menu, msg, buttons);
    }
});

// ==================== OWNER COMMAND ====================
commands.push({
    name: 'owner',
    description: 'Show owner information',
    aliases: ['creator'],
    async execute({ msg, from, sender, bot, sock, buttons }) {
        const ownerInfo = `👑 *𝐎𝐖𝐍𝐄𝐑 𝐈𝐍𝐅𝐎*\n\n` +
            `📛 *Name:* ${config.OWNER_NAME}\n` +
            `📞 *Phone:* ${config.OWNER_NUMBER}\n` +
            `🌍 *Country:* Kenya\n\n` +
            `> created by wanga`;

        await sendWithButtons(sock, from, ownerInfo, msg, buttons);
    }
});

// ==================== STATUS COMMAND ====================
commands.push({
    name: 'status',
    description: 'Show bot status',
    aliases: ['stats'],
    async execute({ msg, from, sender, bot, sock, buttons }) {
        const uptime = process.uptime();
        const days = Math.floor(uptime / 86400);
        const hours = Math.floor((uptime % 86400) / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        const seconds = Math.floor(uptime % 60);
        
        const memory = process.memoryUsage();
        const usedMB = Math.round(memory.heapUsed / 1024 / 1024);

        const statusText = `📊 *𝐁𝐎𝐓 𝐒𝐓𝐀𝐓𝐔𝐒*\n\n` +
            `⏱️ *Uptime:* ${days}d ${hours}h ${minutes}m ${seconds}s\n` +
            `💾 *Memory:* ${usedMB}MB\n` +
            `📚 *Commands:* ${bot.commands.size}\n` +
            `⚡ *Node:* ${process.version}\n\n` +
            `> created by wanga`;

        await sendWithButtons(sock, from, statusText, msg, buttons);
    }
});

// ==================== DEBUG COMMAND ====================
commands.push({
    name: 'debug',
    description: 'Show debug information',
    aliases: [],
    async execute({ msg, from, sender, bot, sock, buttons }) {
        const uptime = process.uptime();
        const days = Math.floor(uptime / 86400);
        const hours = Math.floor((uptime % 86400) / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        const seconds = Math.floor(uptime % 60);

        const debugInfo = `🔧 *𝐃𝐄𝐁𝐔𝐆 𝐈𝐍𝐅𝐎*\n\n` +
            `🤖 *Bot:* ${config.BOT_NAME}\n` +
            `👤 *Owner:* ${config.OWNER_NAME}\n` +
            `🔧 *Prefix:* ${config.PREFIX}\n` +
            `⏱️ *Uptime:* ${days}d ${hours}h ${minutes}m ${seconds}s\n` +
            `⚡ *Node:* ${process.version}\n` +
            `💻 *Platform:* ${process.platform}\n` +
            `📚 *Commands:* ${bot.commands.size}\n\n` +
            `> created by wanga`;

        await sendWithButtons(sock, from, debugInfo, msg, buttons);
    }
});

// ==================== TRACKER COMMAND ====================
commands.push({
    name: 'tracker',
    description: 'Show database tracker statistics',
    aliases: ['dbstats'],
    async execute({ msg, from, sender, bot, sock, buttons }) {
        try {
            const stats = bot.db?.getStats ? bot.db.getStats() : { 
                totalCommands: 0, 
                totalUsers: 0, 
                totalGroups: 0 
            };

            const uptime = process.uptime();
            const days = Math.floor(uptime / 86400);
            const hours = Math.floor((uptime % 86400) / 3600);
            const minutes = Math.floor((uptime % 3600) / 60);

            const statText = `📊 *𝐃𝐀𝐓𝐀𝐁𝐀𝐒𝐄 𝐒𝐓𝐀𝐓𝐒*\n\n` +
                `📨 *Commands Run:* ${stats.totalCommands}\n` +
                `👥 *Users:* ${stats.totalUsers}\n` +
                `👥 *Groups:* ${stats.totalGroups}\n` +
                `⏱️ *Uptime:* ${days}d ${hours}h ${minutes}m\n\n` +
                `> created by wanga`;

            await sendWithButtons(sock, from, statText, msg, buttons);

        } catch (error) {
            console.error('Tracker error:', error);
            await sendWithButtons(sock, from, '❌ Error getting tracker stats.\n\n> created by wanga', msg, buttons);
        }
    }
});

module.exports = { commands };
