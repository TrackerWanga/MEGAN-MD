// MEGAN-MD Tools Commands - Clean version with beautiful buttons

const axios = require('axios');
const CryptoJS = require('crypto-js');
const morse = require('morse');
const { v4: uuidv4 } = require('uuid');
const translate = require('@iamtraction/google-translate');
const { faker } = require('@faker-js/faker');
const math = require('mathjs');
const fs = require('fs-extra');
const path = require('path');
const config = require('../../megan/config');

const TEMP_DIR = path.join(__dirname, '../../temp');
fs.ensureDirSync(TEMP_DIR);
const commands = [];

// ==================== HELPER FUNCTIONS ====================

async function translateToEnglish(text) {
    if (!text || text.length < 10) return text;
    try {
        const result = await translate(text, { to: 'en' });
        return result.text;
    } catch (e) {
        return text;
    }
}

// ==================== SECTION 1: ENCODING TOOLS ====================

// 1. BINARY ENCODER
commands.push({
    name: 'binary',
    description: 'Convert text to binary code',
    aliases: ['bin', 'texttobinary'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const text = args.join(' ');
        if (!text) {
            await react('🔢');
            return reply(`🔢 *BINARY ENCODER*\n\n*Usage:* ${config.PREFIX}binary <text>\n*Example:* ${config.PREFIX}binary Hello\n\n> created by wanga`);
        }
        
        await react('🔄');
        const binaryResult = text.split('').map(char => char.charCodeAt(0).toString(2).padStart(8, '0')).join(' ');
        
        const buttonOptions = {
            title: '🔢 Binary Encoder',
            text: `*Original:* ${text}\n\n*Binary:*\n${binaryResult}`,
            footer: '> created by wanga',
            buttons: [
                {
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📋 Copy Binary',
                        copy_code: binaryResult
                    })
                }
            ]
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        } else {
            await sock.sendMessage(from, { text: `*Binary:*\n${binaryResult}` }, { quoted: msg });
        }
        await react('✅');
    }
});

// 2. BINARY DECODER
commands.push({
    name: 'debinary',
    description: 'Convert binary code to text',
    aliases: ['unbinary'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const text = args.join(' ');
        if (!text) {
            await react('🔢');
            return reply(`🔢 *BINARY DECODER*\n\n*Usage:* ${config.PREFIX}debinary <binary>\n*Example:* ${config.PREFIX}debinary 01001000 01100101\n\n> created by wanga`);
        }
        
        await react('🔄');
        const cleanBinary = text.replace(/\s+/g, '');
        if (!/^[01]+$/.test(cleanBinary)) return reply('❌ Invalid binary code');
        
        let result = '';
        for (let i = 0; i < cleanBinary.length; i += 8) {
            const byte = cleanBinary.substr(i, 8);
            if (byte.length === 8) result += String.fromCharCode(parseInt(byte, 2));
        }
        
        const buttonOptions = {
            title: '🔢 Binary Decoder',
            text: `*Binary:* ${text}\n\n*Text:* ${result}`,
            footer: '> created by wanga',
            buttons: [
                {
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📋 Copy Text',
                        copy_code: result
                    })
                }
            ]
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        } else {
            await sock.sendMessage(from, { text: `*Decoded:* ${result}` }, { quoted: msg });
        }
        await react('✅');
    }
});

// 3. BASE64
commands.push({
    name: 'base64',
    description: 'Encode/decode Base64',
    aliases: ['b64'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const text = args.join(' ');
        if (!text) {
            await react('📄');
            return reply(`📄 *BASE64*\n\n*Usage:*\n• ${config.PREFIX}base64 <text> (encode)\n• ${config.PREFIX}base64 decode <base64> (decode)\n\n> created by wanga`);
        }
        
        await react('🔄');
        
        if (text.toLowerCase().startsWith('decode ')) {
            const base64Text = text.substring(7);
            const decoded = Buffer.from(base64Text, 'base64').toString('utf8');
            
            const buttonOptions = {
                title: '📄 Base64 Decoder',
                text: `*Decoded:*\n${decoded}`,
                footer: '> created by wanga',
                buttons: [
                    {
                        name: 'cta_copy',
                        buttonParamsJson: JSON.stringify({
                            display_text: '📋 Copy',
                            copy_code: decoded
                        })
                    }
                ]
            };
            if (buttons) {
                await buttons.send(from, buttonOptions, msg);
            } else {
                await sock.sendMessage(from, { text: `*Decoded:* ${decoded}` }, { quoted: msg });
            }
        } else {
            const encodeText = text.toLowerCase().startsWith('encode ') ? text.substring(7) : text;
            const encoded = Buffer.from(encodeText, 'utf8').toString('base64');
            
            const buttonOptions = {
                title: '📄 Base64 Encoder',
                text: `*Encoded:*\n${encoded}`,
                footer: '> created by wanga',
                buttons: [
                    {
                        name: 'cta_copy',
                        buttonParamsJson: JSON.stringify({
                            display_text: '📋 Copy',
                            copy_code: encoded
                        })
                    }
                ]
            };
            if (buttons) {
                await buttons.send(from, buttonOptions, msg);
            } else {
                await sock.sendMessage(from, { text: `*Encoded:* ${encoded}` }, { quoted: msg });
            }
        }
        await react('✅');
    }
});

// 4. HASH GENERATOR
commands.push({
    name: 'hash',
    description: 'Generate hash values',
    aliases: ['hashgen'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const text = args.join(' ');
        if (!text) {
            await react('🔒');
            return reply(`🔒 *HASH GENERATOR*\n\n*Usage:* ${config.PREFIX}hash <text>\n*Example:* ${config.PREFIX}hash password123\n\n> created by wanga`);
        }
        
        await react('🔄');
        
        const md5 = CryptoJS.MD5(text).toString();
        const sha1 = CryptoJS.SHA1(text).toString();
        const sha256 = CryptoJS.SHA256(text).toString();
        
        const buttonOptions = {
            title: '🔒 Hash Generator',
            text: `*MD5:* \`${md5}\`\n\n*SHA1:* \`${sha1}\`\n\n*SHA256:* \`${sha256}\``,
            footer: '> created by wanga',
            buttons: [
                {
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📋 Copy MD5',
                        copy_code: md5
                    })
                },
                {
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📋 Copy SHA256',
                        copy_code: sha256
                    })
                }
            ]
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        } else {
            await sock.sendMessage(from, { text: `*MD5:* ${md5}\n\n*SHA1:* ${sha1}\n\n*SHA256:* ${sha256}` }, { quoted: msg });
        }
        await react('✅');
    }
});

// 5. MORSE CODE
commands.push({
    name: 'morse',
    description: 'Convert text to Morse code',
    aliases: ['morsecode'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const text = args.join(' ');
        if (!text) {
            await react('📡');
            return reply(`📡 *MORSE CODE*\n\n*Usage:*\n• ${config.PREFIX}morse <text> (encode)\n• ${config.PREFIX}morse .... . .-.. .-.. --- (decode)\n\n> created by wanga`);
        }
        
        await react('🔄');
        
        if (/^[\.\-\s]+$/.test(text)) {
            const decoded = morse.decode(text);
            const buttonOptions = {
                title: '📡 Morse Decoder',
                text: `*Morse:* ${text}\n\n*Text:* ${decoded}`,
                footer: '> created by wanga',
                buttons: [
                    {
                        name: 'cta_copy',
                        buttonParamsJson: JSON.stringify({
                            display_text: '📋 Copy Text',
                            copy_code: decoded
                        })
                    }
                ]
            };
            if (buttons) {
                await buttons.send(from, buttonOptions, msg);
            } else {
                await sock.sendMessage(from, { text: `*Decoded:* ${decoded}` }, { quoted: msg });
            }
        } else {
            const encoded = morse.encode(text);
            const buttonOptions = {
                title: '📡 Morse Encoder',
                text: `*Text:* ${text}\n\n*Morse:* ${encoded}`,
                footer: '> created by wanga',
                buttons: [
                    {
                        name: 'cta_copy',
                        buttonParamsJson: JSON.stringify({
                            display_text: '📋 Copy Morse',
                            copy_code: encoded
                        })
                    }
                ]
            };
            if (buttons) {
                await buttons.send(from, buttonOptions, msg);
            } else {
                await sock.sendMessage(from, { text: `*Morse:* ${encoded}` }, { quoted: msg });
            }
        }
        await react('✅');
    }
});

// ==================== SECTION 2: SECURITY TOOLS ====================

// 6. ENCRYPT
commands.push({
    name: 'encrypt',
    description: 'Encrypt text with password',
    aliases: ['encode'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const text = args.join(' ');
        if (!text) {
            await react('🔐');
            return reply(`🔐 *ENCRYPT*\n\n*Usage:* ${config.PREFIX}encrypt <password> <text>\n*Example:* ${config.PREFIX}encrypt mysecret Hello World\n\n> created by wanga`);
        }
        
        const [password, ...messageParts] = text.split(' ');
        const message = messageParts.join(' ');
        if (!password || !message) return reply('❌ Need both password and message');
        
        await react('🔄');
        const encrypted = CryptoJS.AES.encrypt(message, password).toString();
        
        const buttonOptions = {
            title: '🔐 Encrypted',
            text: `*Password:* ||${password}||\n\n*Encrypted:*\n${encrypted}`,
            footer: '> created by wanga',
            buttons: [
                {
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📋 Copy',
                        copy_code: encrypted
                    })
                }
            ]
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        } else {
            await sock.sendMessage(from, { text: `*Encrypted:* ${encrypted}` }, { quoted: msg });
        }
        await react('✅');
    }
});

// 7. DECRYPT
commands.push({
    name: 'decrypt',
    description: 'Decrypt text with password',
    aliases: ['decode'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const text = args.join(' ');
        if (!text) {
            await react('🔐');
            return reply(`🔐 *DECRYPT*\n\n*Usage:* ${config.PREFIX}decrypt <password> <encrypted>\n*Example:* ${config.PREFIX}decrypt mysecret U2FsdGVkX1...\n\n> created by wanga`);
        }
        
        const [password, ...encryptedParts] = text.split(' ');
        const encrypted = encryptedParts.join(' ');
        if (!password || !encrypted) return reply('❌ Need both password and encrypted text');
        
        await react('🔄');
        const bytes = CryptoJS.AES.decrypt(encrypted, password);
        const decrypted = bytes.toString(CryptoJS.enc.Utf8);
        if (!decrypted) return reply('❌ Wrong password or corrupted data');
        
        const buttonOptions = {
            title: '🔐 Decrypted',
            text: `*Password:* ||${password}||\n\n*Decrypted:*\n${decrypted}`,
            footer: '> created by wanga',
            buttons: [
                {
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📋 Copy',
                        copy_code: decrypted
                    })
                }
            ]
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        } else {
            await sock.sendMessage(from, { text: `*Decrypted:* ${decrypted}` }, { quoted: msg });
        }
        await react('✅');
    }
});

// 8. PASSWORD GENERATOR
commands.push({
    name: 'password',
    description: 'Generate strong passwords',
    aliases: ['pass', 'genpass'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const length = Math.min(Math.max(parseInt(args[0]) || 16, 8), 64);
        await react('🔐');
        
        const passwords = [];
        for (let i = 0; i < 3; i++) {
            const lowercase = 'abcdefghijklmnopqrstuvwxyz';
            const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            const numbers = '0123456789';
            const symbols = '!@#$%^&*()_+-=[]{}|;:,.<>?';
            const allChars = lowercase + uppercase + numbers + symbols;
            
            let password = '';
            password += lowercase[Math.floor(Math.random() * lowercase.length)];
            password += uppercase[Math.floor(Math.random() * uppercase.length)];
            password += numbers[Math.floor(Math.random() * numbers.length)];
            password += symbols[Math.floor(Math.random() * symbols.length)];
            
            for (let j = 4; j < length; j++) {
                password += allChars[Math.floor(Math.random() * allChars.length)];
            }
            password = password.split('').sort(() => Math.random() - 0.5).join('');
            passwords.push(password);
        }
        
        const buttonOptions = {
            title: '🔐 Strong Passwords',
            text: `*Length:* ${length} characters\n\n*Password 1:* \`${passwords[0]}\`\n\n*Password 2:* \`${passwords[1]}\`\n\n*Password 3:* \`${passwords[2]}\``,
            footer: '> created by wanga',
            buttons: [
                {
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📋 Copy 1',
                        copy_code: passwords[0]
                    })
                },
                {
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📋 Copy 2',
                        copy_code: passwords[1]
                    })
                },
                {
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📋 Copy 3',
                        copy_code: passwords[2]
                    })
                }
            ]
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        } else {
            await sock.sendMessage(from, { text: `*Length:* ${length}\n\n1. ${passwords[0]}\n2. ${passwords[1]}\n3. ${passwords[2]}` }, { quoted: msg });
        }
        await react('✅');
    }
});

// 9. VCC GENERATOR
commands.push({
    name: 'vcc',
    description: 'Generate fake credit cards',
    aliases: ['vccgen'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const type = args[0]?.toUpperCase() || 'Visa';
        const count = Math.min(parseInt(args[1]) || 1, 5);
        
        const validTypes = ['Visa', 'MasterCard', 'Amex', 'JCB', 'Diners'];
        if (!validTypes.includes(type)) {
            return reply(`❌ Invalid type. Use: ${validTypes.join(', ')}`);
        }
        
        await react('💳');
        
        try {
            const response = await axios.get(`https://api.siputzx.my.id/api/tools/vcc-generator`, {
                params: { type, count },
                timeout: 20000
            });
            
            if (response.data?.data?.length) {
                const cards = response.data.data;
                let resultText = `*💳 ${type} Cards (${cards.length})*\n\n`;
                
                cards.forEach((card, i) => {
                    resultText += `*${i+1}.* \`${card.cardNumber}\`\n`;
                    resultText += `   Exp: ${card.expirationDate} | CVV: ${card.cvv}\n`;
                    resultText += `   Name: ${card.cardholderName}\n\n`;
                });
                
                const buttonOptions = {
                    title: '💳 VCC Generator',
                    text: resultText,
                    footer: '> created by wanga',
                    buttons: cards.slice(0, 3).map((card, i) => ({
                        name: 'cta_copy',
                        buttonParamsJson: JSON.stringify({
                            display_text: `📋 Copy Card ${i+1}`,
                            copy_code: `${card.cardNumber}|${card.expirationDate}|${card.cvv}`
                        })
                    }))
                };
                
                if (buttons) {
                    await buttons.send(from, buttonOptions, msg);
                } else {
                    await sock.sendMessage(from, { text: resultText }, { quoted: msg });
                }
                await react('✅');
                return;
            }
        } catch (apiError) {
            // Fallback to local generation
        }
        
        // Fallback: Generate fake data locally
        const cards = [];
        for (let i = 0; i < count; i++) {
            const cardNumber = Math.floor(Math.random() * 10000000000000000).toString().padStart(16, '0');
            const expMonth = Math.floor(Math.random() * 12) + 1;
            const expYear = 25 + Math.floor(Math.random() * 5);
            const cvv = Math.floor(Math.random() * 900) + 100;
            const names = ['John Doe', 'Jane Smith', 'Robert Johnson', 'Maria Garcia', 'David Brown'];
            const cardholderName = names[Math.floor(Math.random() * names.length)];
            
            cards.push({
                cardNumber,
                expirationDate: `${expMonth.toString().padStart(2, '0')}/${expYear}`,
                cardholderName,
                cvv: cvv.toString()
            });
        }
        
        let resultText = `*💳 ${type} Cards (${cards.length})* [Fallback]\n\n`;
        cards.forEach((card, i) => {
            resultText += `*${i+1}.* \`${card.cardNumber}\`\n`;
            resultText += `   Exp: ${card.expirationDate} | CVV: ${card.cvv}\n`;
            resultText += `   Name: ${card.cardholderName}\n\n`;
        });
        
        const buttonOptions = {
            title: '💳 VCC Generator',
            text: resultText,
            footer: '> created by wanga',
            buttons: cards.slice(0, 3).map((card, i) => ({
                name: 'cta_copy',
                buttonParamsJson: JSON.stringify({
                    display_text: `📋 Copy Card ${i+1}`,
                    copy_code: `${card.cardNumber}|${card.expirationDate}|${card.cvv}`
                })
            }))
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        } else {
            await sock.sendMessage(from, { text: resultText }, { quoted: msg });
        }
        await react('✅');
    }
});

// ==================== SECTION 3: GENERATOR TOOLS ====================

// 10. EMAIL GENERATOR
commands.push({
    name: 'email',
    description: 'Generate random email addresses',
    aliases: ['genemail'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const count = Math.min(parseInt(args[0]) || 1, 20);
        await react('📧');
        
        const emails = [];
        for (let i = 0; i < count; i++) {
            emails.push(faker.internet.email());
        }
        
        const buttonOptions = {
            title: '📧 Random Emails',
            text: `*${count} Email(s)*\n\n${emails.map((e, i) => `${i+1}. \`${e}\``).join('\n')}`,
            footer: '> created by wanga',
            buttons: emails.slice(0, 3).map((email, i) => ({
                name: 'cta_copy',
                buttonParamsJson: JSON.stringify({
                    display_text: `📋 Copy ${i+1}`,
                    copy_code: email
                })
            }))
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        } else {
            await sock.sendMessage(from, { text: `*${count} Email(s)*\n\n${emails.map((e, i) => `${i+1}. ${e}`).join('\n')}` }, { quoted: msg });
        }
        await react('✅');
    }
});

// 11. UUID GENERATOR
commands.push({
    name: 'uuid',
    description: 'Generate UUIDs',
    aliases: ['guid'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const count = Math.min(parseInt(args[0]) || 5, 20);
        await react('🔑');
        
        const uuids = [];
        for (let i = 0; i < count; i++) {
            uuids.push(uuidv4());
        }
        
        const buttonOptions = {
            title: '🔑 UUID Generator',
            text: `*${count} UUID(s)*\n\n${uuids.map((u, i) => `${i+1}. \`${u}\``).join('\n')}`,
            footer: '> created by wanga',
            buttons: uuids.slice(0, 3).map((uuid, i) => ({
                name: 'cta_copy',
                buttonParamsJson: JSON.stringify({
                    display_text: `📋 Copy ${i+1}`,
                    copy_code: uuid
                })
            }))
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        } else {
            await sock.sendMessage(from, { text: `*${count} UUID(s)*\n\n${uuids.map((u, i) => `${i+1}. ${u}`).join('\n')}` }, { quoted: msg });
        }
        await react('✅');
    }
});

// ==================== SECTION 4: WEB TOOLS ====================

// 12. BROWSE WEB
commands.push({
    name: 'browse',
    description: 'Fetch webpage content',
    aliases: ['fetch'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('🌐');
            return reply(`🌐 *BROWSE*\n\n*Usage:* ${config.PREFIX}browse <url>\n*Example:* ${config.PREFIX}browse https://example.com\n\n> created by wanga`);
        }
        
        const url = args[0];
        if (!url.startsWith('http')) return reply('❌ Please include http:// or https://');
        
        await react('🌐');
        
        try {
            const response = await axios.get(url, { timeout: 15000 });
            const textData = typeof response.data === 'string' ? response.data : JSON.stringify(response.data);
            const truncated = textData.length > 4000 ? textData.substring(0, 4000) + '...' : textData;
            
            const buttonOptions = {
                title: '🌐 Web Content',
                text: truncated,
                footer: '> created by wanga',
                buttons: [
                    {
                        name: 'cta_copy',
                        buttonParamsJson: JSON.stringify({
                            display_text: '📋 Copy',
                            copy_code: truncated
                        })
                    },
                    {
                        name: 'cta_url',
                        buttonParamsJson: JSON.stringify({
                            display_text: '🔗 Open URL',
                            url: url
                        })
                    }
                ]
            };
            
            if (buttons) {
                await buttons.send(from, buttonOptions, msg);
            } else {
                await sock.sendMessage(from, { text: truncated }, { quoted: msg });
            }
            await react('✅');
        } catch (error) {
            await react('❌');
            await reply(`❌ Error fetching URL: ${error.message}`);
        }
    }
});

// 13. TINYURL SHORTENER
commands.push({
    name: 'tinyurl',
    description: 'Shorten URLs',
    aliases: ['short'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('🔗');
            return reply(`🔗 *SHORTEN URL*\n\n*Usage:* ${config.PREFIX}tinyurl <url>\n*Example:* ${config.PREFIX}tinyurl https://example.com\n\n> created by wanga`);
        }
        
        const url = args[0];
        if (!url.startsWith('http')) return reply('❌ Please include http:// or https://');
        
        await react('🔗');
        
        try {
            const response = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(url)}`, {
                timeout: 15000
            });
            const shortUrl = response.data;
            
            const buttonOptions = {
                title: '🔗 Short URL',
                text: `*Original:* ${url}\n\n*Short:* ${shortUrl}`,
                footer: '> created by wanga',
                buttons: [
                    {
                        name: 'cta_copy',
                        buttonParamsJson: JSON.stringify({
                            display_text: '📋 Copy',
                            copy_code: shortUrl
                        })
                    },
                    {
                        name: 'cta_url',
                        buttonParamsJson: JSON.stringify({
                            display_text: '🔗 Open',
                            url: shortUrl
                        })
                    }
                ]
            };
            
            if (buttons) {
                await buttons.send(from, buttonOptions, msg);
            } else {
                await sock.sendMessage(from, { text: `*Short URL:* ${shortUrl}` }, { quoted: msg });
            }
            await react('✅');
        } catch (error) {
            await react('❌');
            await reply('❌ Failed to shorten URL.');
        }
    }
});

// 14. SCREENSHOT
commands.push({
    name: 'screenshot',
    description: 'Take screenshot of a website',
    aliases: ['ss', 'ssweb'],
    async execute({ msg, from, sender, args, bot, sock, react, reply }) {
        if (!args.length) {
            await react('📸');
            return reply(`📸 *SCREENSHOT*\n\n*Usage:* ${config.PREFIX}screenshot <url>\n*Example:* ${config.PREFIX}screenshot https://google.com\n\n*Options:*\n• Desktop (default)\n• Add 'mobile' for mobile view\n• Add 'full' for full page\n\n> created by wanga`);
        }
        
        let url = args[0];
        let device = 'desktop';
        let fullPage = false;
        
        if (args[1]) {
            if (args[1].toLowerCase() === 'mobile') device = 'mobile';
            if (args[1].toLowerCase() === 'full') fullPage = true;
            if (args[2] && args[2].toLowerCase() === 'full') fullPage = true;
        }
        
        if (!url.startsWith('http')) url = 'https://' + url;
        
        await react('📸');
        
        try {
            const response = await axios.get(`https://api.siputzx.my.id/api/tools/ssweb`, {
                params: {
                    url: url,
                    device: device,
                    theme: 'light',
                    fullPage: fullPage
                },
                responseType: 'arraybuffer',
                timeout: 30000,
                headers: { 'User-Agent': 'Mozilla/5.0' }
            });
            
            const imageBuffer = Buffer.from(response.data);
            const caption = `📸 *Screenshot*\n\n🌐 URL: ${url}\n📱 Device: ${device}\n📄 Full Page: ${fullPage ? 'Yes' : 'No'}\n\n> created by wanga`;
            
            await sock.sendMessage(from, {
                image: imageBuffer,
                caption: caption
            }, { quoted: msg });
            
            await react('✅');
        } catch (error) {
            await react('❌');
            await reply(`❌ Screenshot failed.\n\nTry: ${config.PREFIX}screenshot https://google.com`);
        }
    }
});

// 15. SUBDOMAINS FINDER
commands.push({
    name: 'subdomains',
    description: 'Find subdomains for a domain',
    aliases: ['subdomain'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('🔍');
            return reply(`🔍 *SUBDOMAINS*\n\n*Usage:* ${config.PREFIX}subdomains <domain>\n*Example:* ${config.PREFIX}subdomains github.com\n\n> created by wanga`);
        }
        
        const domain = args[0];
        await react('🔍');
        
        try {
            const response = await axios.get(`https://api.siputzx.my.id/api/tools/subdomains`, {
                params: { domain },
                timeout: 20000
            });
            
            if (!response.data?.data?.length) throw new Error('No subdomains found');
            
            const subdomains = response.data.data.slice(0, 20);
            
            const buttonOptions = {
                title: '🔍 Subdomains',
                text: `*🌐 Subdomains for ${domain}*\n\n${subdomains.map((s, i) => `${i+1}. ${s}`).join('\n')}`,
                footer: '> created by wanga',
                buttons: [
                    {
                        name: 'cta_copy',
                        buttonParamsJson: JSON.stringify({
                            display_text: '📋 Copy List',
                            copy_code: subdomains.join('\n')
                        })
                    }
                ]
            };
            
            if (buttons) {
                await buttons.send(from, buttonOptions, msg);
            } else {
                await sock.sendMessage(from, { text: `*Subdomains for ${domain}*\n\n${subdomains.join('\n')}` }, { quoted: msg });
            }
            await react('✅');
        } catch (error) {
            await react('❌');
            await reply(`❌ Failed to find subdomains.`);
        }
    }
});

// ==================== SECTION 5: INFO TOOLS ====================

// 16. COUNTRY INFO
commands.push({
    name: 'countryinfo',
    description: 'Get information about a country',
    aliases: ['country'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('🌍');
            return reply(`🌍 *COUNTRY INFO*\n\n*Usage:* ${config.PREFIX}countryinfo <country>\n*Example:* ${config.PREFIX}countryinfo Kenya\n\n> created by wanga`);
        }
        
        const country = args.join(' ');
        await react('🌍');
        
        try {
            const response = await axios.get(`https://api.siputzx.my.id/api/tools/countryInfo`, {
                params: { name: country },
                timeout: 15000
            });
            
            if (!response.data?.data) throw new Error('Country not found');
            
            const data = response.data.data;
            
            let languages = 'N/A';
            if (data.languages) {
                if (Array.isArray(data.languages)) {
                    languages = data.languages.join(', ');
                } else if (typeof data.languages === 'object') {
                    languages = Object.values(data.languages).join(', ');
                } else {
                    languages = data.languages.toString();
                }
            }
            
            let resultText = `*🌍 ${data.name}*\n\n`;
            resultText += `🏛️ *Capital:* ${data.capital || 'N/A'}\n`;
            resultText += `👥 *Population:* ${data.population?.toLocaleString() || 'N/A'}\n`;
            resultText += `🗺️ *Area:* ${data.area?.toLocaleString() || 'N/A'} km²\n`;
            resultText += `💰 *Currency:* ${data.currency || 'N/A'}\n`;
            resultText += `🗣️ *Languages:* ${languages}\n`;
            resultText += `⏰ *Timezones:* ${data.timezones?.join(', ') || 'N/A'}\n`;
            
            const buttonOptions = {
                title: '🌍 Country Info',
                text: resultText,
                footer: '> created by wanga',
                buttons: [
                    {
                        name: 'cta_copy',
                        buttonParamsJson: JSON.stringify({
                            display_text: '📋 Copy',
                            copy_code: resultText.replace(/\*/g, '')
                        })
                    }
                ]
            };
            
            if (buttons) {
                await buttons.send(from, buttonOptions, msg);
            } else {
                await sock.sendMessage(from, { text: resultText }, { quoted: msg });
            }
            await react('✅');
        } catch (error) {
            await react('❌');
            await reply(`❌ Country not found.`);
        }
    }
});

// ==================== SECTION 6: SOCIAL STALKING ====================

// 17. GITHUB STALK
commands.push({
    name: 'githubstalk',
    description: 'Get GitHub user info',
    aliases: ['ghstalk'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('🐙');
            return reply(`🐙 *GITHUB STALK*\n\n*Usage:* ${config.PREFIX}githubstalk <username>\n*Example:* ${config.PREFIX}githubstalk torvalds\n\n> created by wanga`);
        }
        
        const username = args[0];
        await react('🐙');
        
        try {
            let user = null;
            let htmlUrl = `https://github.com/${username}`;
            
            try {
                const response = await axios.get(`https://api.github.com/users/${username}`, {
                    timeout: 10000,
                    headers: { 'User-Agent': 'Mozilla/5.0' }
                });
                user = response.data;
            } catch (githubError) {
                try {
                    const response = await axios.get(`https://api.siputzx.my.id/api/stalk/github`, {
                        params: { user: username },
                        timeout: 10000
                    });
                    if (response.data?.data) user = response.data.data;
                } catch (siputzxError) {
                    user = {
                        login: username,
                        name: username,
                        bio: 'GitHub user',
                        public_repos: 0,
                        followers: 0,
                        following: 0,
                        created_at: new Date().toISOString(),
                        html_url: htmlUrl
                    };
                }
            }
            
            let resultText = `*🐙 ${user.login || username}*\n\n`;
            resultText += `📛 *Name:* ${user.name || 'N/A'}\n`;
            resultText += `📝 *Bio:* ${user.bio || 'N/A'}\n`;
            resultText += `📦 *Public Repos:* ${user.public_repos || 0}\n`;
            resultText += `👥 *Followers:* ${user.followers || 0}\n`;
            resultText += `👤 *Following:* ${user.following || 0}\n`;
            resultText += `📅 *Created:* ${new Date(user.created_at).toLocaleDateString()}\n`;
            
            const buttonOptions = {
                title: '🐙 GitHub Profile',
                text: resultText,
                footer: '> created by wanga',
                buttons: [
                    {
                        name: 'cta_url',
                        buttonParamsJson: JSON.stringify({
                            display_text: '🔗 View Profile',
                            url: user.html_url || htmlUrl
                        })
                    }
                ]
            };
            
            if (buttons) {
                await buttons.send(from, buttonOptions, msg);
            } else {
                await sock.sendMessage(from, { text: resultText }, { quoted: msg });
            }
            await react('✅');
        } catch (error) {
            await react('❌');
            await reply(`❌ User not found.`);
        }
    }
});

// 18. YOUTUBE STALK
commands.push({
    name: 'youtubestalk',
    description: 'Get YouTube channel info',
    aliases: ['ytstalk'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('📺');
            return reply(`📺 *YOUTUBE STALK*\n\n*Usage:* ${config.PREFIX}youtubestalk <channel>\n*Example:* ${config.PREFIX}youtubestalk MrBeast\n\n> created by wanga`);
        }
        
        const channel = args[0];
        await react('📺');
        
        try {
            let channelData = null;
            let channelUrl = `https://youtube.com/@${channel}`;
            
            try {
                const response = await axios.get(`https://api.siputzx.my.id/api/stalk/youtube`, {
                    params: { username: channel },
                    timeout: 15000
                });
                if (response.data?.data) channelData = response.data.data;
            } catch (apiError) {
                channelData = {
                    channelName: channel,
                    subscribers: 'N/A',
                    totalViews: 'N/A',
                    totalVideos: 'N/A',
                    joinedDate: 'N/A',
                    channelUrl: channelUrl
                };
            }
            
            let resultText = `*📺 ${channelData.channelName || channel}*\n\n`;
            resultText += `👥 *Subscribers:* ${channelData.subscribers || 'N/A'}\n`;
            resultText += `👁️ *Total Views:* ${channelData.totalViews || 'N/A'}\n`;
            resultText += `🎬 *Total Videos:* ${channelData.totalVideos || 'N/A'}\n`;
            resultText += `📅 *Joined:* ${channelData.joinedDate || 'N/A'}\n`;
            
            const buttonOptions = {
                title: '📺 YouTube Channel',
                text: resultText,
                footer: '> created by wanga',
                buttons: [
                    {
                        name: 'cta_url',
                        buttonParamsJson: JSON.stringify({
                            display_text: '🔗 View Channel',
                            url: channelData.channelUrl || channelUrl
                        })
                    }
                ]
            };
            
            if (buttons) {
                await buttons.send(from, buttonOptions, msg);
            } else {
                await sock.sendMessage(from, { text: resultText }, { quoted: msg });
            }
            await react('✅');
        } catch (error) {
            await react('❌');
            await reply(`❌ Channel not found.`);
        }
    }
});

// ==================== SECTION 7: MATH & TEXT TOOLS ====================

// 19. CALCULATE
commands.push({
    name: 'calculate',
    description: 'Solve math equations',
    aliases: ['calc', 'math'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('🧮');
            return reply(`🧮 *CALCULATOR*\n\n*Usage:* ${config.PREFIX}calc <equation>\n*Example:* ${config.PREFIX}calc 2+2\n\n> created by wanga`);
        }
        
        const equation = args.join(' ').replace(/×/g, '*').replace(/÷/g, '/');
        await react('🧮');
        
        try {
            const result = math.evaluate(equation);
            
            const buttonOptions = {
                title: '🧮 Calculator',
                text: `*Equation:* ${equation}\n\n*Result:* ${result}`,
                footer: '> created by wanga',
                buttons: [
                    {
                        name: 'cta_copy',
                        buttonParamsJson: JSON.stringify({
                            display_text: '📋 Copy',
                            copy_code: result.toString()
                        })
                    }
                ]
            };
            
            if (buttons) {
                await buttons.send(from, buttonOptions, msg);
            } else {
                await sock.sendMessage(from, { text: `*Result:* ${result}` }, { quoted: msg });
            }
            await react('✅');
        } catch (error) {
            await react('❌');
            await reply(`❌ Invalid equation: ${error.message}`);
        }
    }
});

// 20. FLIP TEXT
commands.push({
    name: 'fliptext',
    description: 'Flip text upside down',
    aliases: ['flip'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('🔄');
            return reply(`🔄 *FLIP TEXT*\n\n*Usage:* ${config.PREFIX}fliptext <text>\n*Example:* ${config.PREFIX}fliptext Hello\n\n> created by wanga`);
        }
        
        const text = args.join(' ');
        
        const flipMap = {
            'a': 'ɐ', 'b': 'q', 'c': 'ɔ', 'd': 'p', 'e': 'ǝ', 'f': 'ɟ', 'g': 'ƃ',
            'h': 'ɥ', 'i': 'ᴉ', 'j': 'ɾ', 'k': 'ʞ', 'l': 'l', 'm': 'ɯ', 'n': 'u',
            'o': 'o', 'p': 'd', 'q': 'b', 'r': 'ɹ', 's': 's', 't': 'ʇ', 'u': 'n',
            'v': 'ʌ', 'w': 'ʍ', 'x': 'x', 'y': 'ʎ', 'z': 'z', 'A': '∀', 'B': '𐐒',
            'C': 'Ɔ', 'D': 'ᗡ', 'E': 'Ǝ', 'F': 'Ⅎ', 'G': '⅁', 'H': 'H', 'I': 'I',
            'J': 'ſ', 'K': 'ʞ', 'L': '⅂', 'M': 'W', 'N': 'N', 'O': 'O', 'P': 'Ԁ',
            'Q': 'Q', 'R': 'ᴚ', 'S': 'S', 'T': '⊥', 'U': '∩', 'V': 'Λ', 'W': 'M',
            'X': 'X', 'Y': '⅄', 'Z': 'Z', '0': '0', '1': 'Ɩ', '2': 'ᄅ', '3': 'Ɛ',
            '4': 'ㄣ', '5': 'ϛ', '6': '9', '7': 'ㄥ', '8': '8', '9': '6', '!': '¡',
            '?': '¿', '.': '˙', ',': "'", '"': '„', "'": ',', '(': ')', ')': '(',
            '[': ']', ']': '[', '{': '}', '}': '{', '<': '>', '>': '<', '&': '⅋', '_': '‾'
        };
        
        const flipped = text.split('').map(char => flipMap[char] || char).reverse().join('');
        
        const buttonOptions = {
            title: '🔄 Flipped Text',
            text: `*Original:* ${text}\n\n*Flipped:* ${flipped}`,
            footer: '> created by wanga',
            buttons: [
                {
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📋 Copy',
                        copy_code: flipped
                    })
                }
            ]
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        } else {
            await sock.sendMessage(from, { text: `*Flipped:* ${flipped}` }, { quoted: msg });
        }
        await react('✅');
    }
});

// 21. EMOJI MIX
commands.push({
    name: 'emojimix',
    description: 'Mix two emojis together',
    aliases: ['emix'],
    async execute({ msg, from, sender, args, bot, sock, react, reply }) {
        if (args.length < 1 || !args[0].includes('+')) {
            await react('😊');
            return reply(`😊 *EMOJI MIX*\n\n*Usage:* ${config.PREFIX}emojimix 😅+🤔\n*Example:* ${config.PREFIX}emojimix 🐱+🐶\n\n> created by wanga`);
        }
        
        const [emoji1, emoji2] = args[0].split('+').map(e => e.trim());
        if (!emoji1 || !emoji2) return reply('❌ Please provide two emojis separated by +');
        
        await react('🎨');
        
        try {
            const response = await axios.get(
                `https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`,
                { timeout: 15000 }
            );
            
            if (!response.data.results?.length) return reply('❌ Could not mix these emojis.');
            
            const result = response.data.results[0];
            
            await sock.sendMessage(from, {
                image: { url: result.url },
                caption: `🎨 *Emoji Mix*\n\n${emoji1} + ${emoji2}\n\n> created by wanga`
            }, { quoted: msg });
            await react('✅');
        } catch (error) {
            await react('❌');
            await reply('❌ Failed to mix emojis.');
        }
    }
});

// 22. ZODIAK
commands.push({
    name: 'zodiak',
    description: 'Get zodiac information',
    aliases: ['zodiac'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('⭐');
            return reply(`⭐ *ZODIAK*\n\n*Usage:* ${config.PREFIX}zodiak <sign>\n*Example:* ${config.PREFIX}zodiak gemini\n\n*Signs:* aries, taurus, gemini, cancer, leo, virgo, libra, scorpio, sagittarius, capricorn, aquarius, pisces\n\n> created by wanga`);
        }
        
        const sign = args[0].toLowerCase();
        await react('⭐');
        
        try {
            const response = await axios.get(`https://api.siputzx.my.id/api/primbon/zodiak`, {
                params: { zodiak: sign },
                timeout: 15000
            });
            
            if (!response.data?.data) throw new Error('Zodiac not found');
            
            const data = response.data.data;
            const translatedDesc = await translateToEnglish(data.zodiak);
            
            let resultText = `*⭐ ${sign.toUpperCase()}*\n\n`;
            resultText += `📝 *Description:* ${translatedDesc}\n\n`;
            resultText += `🔢 *Lucky Numbers:* ${data.nomor_keberuntungan || 'N/A'}\n`;
            resultText += `🌸 *Lucky Flowers:* ${data.bunga_keberuntungan || 'N/A'}\n`;
            resultText += `🎨 *Lucky Color:* ${data.warna_keberuntungan || 'N/A'}\n`;
            resultText += `💧 *Element:* ${data.elemen_keberuntungan || 'N/A'}\n`;
            resultText += `🪐 *Planet:* ${data.planet_yang_mengitari || 'N/A'}\n`;
            
            const buttonOptions = {
                title: '⭐ Zodiac',
                text: resultText,
                footer: '> created by wanga',
                buttons: [
                    {
                        name: 'cta_copy',
                        buttonParamsJson: JSON.stringify({
                            display_text: '📋 Copy',
                            copy_code: resultText.replace(/\*/g, '')
                        })
                    }
                ]
            };
            
            if (buttons) {
                await buttons.send(from, buttonOptions, msg);
            } else {
                await sock.sendMessage(from, { text: resultText }, { quoted: msg });
            }
            await react('✅');
        } catch (error) {
            await react('❌');
            await reply(`❌ Zodiac not found.\n\nTry: ${config.PREFIX}zodiak gemini`);
        }
    }
});

// ==================== SECTION 8: HELP ====================

// 23. TOOLS HELP
commands.push({
    name: 'tools',
    description: 'Show all tool commands',
    aliases: ['toolhelp'],
    async execute({ msg, from, sender, args, bot, sock, react, reply }) {
        await react('🛠️');
        
        const helpText = `*🛠️ MEGAN TOOLS*\n\n` +
        
            `*🔢 ENCODING*\n` +
            `• ${config.PREFIX}binary - Text to binary\n` +
            `• ${config.PREFIX}debinary - Binary to text\n` +
            `• ${config.PREFIX}base64 - Encode/decode\n` +
            `• ${config.PREFIX}hash - MD5, SHA1, SHA256\n` +
            `• ${config.PREFIX}morse - Morse code\n\n` +
            
            `*🔐 SECURITY*\n` +
            `• ${config.PREFIX}encrypt - AES encrypt\n` +
            `• ${config.PREFIX}decrypt - AES decrypt\n` +
            `• ${config.PREFIX}password - Strong passwords\n` +
            `• ${config.PREFIX}vcc - Credit cards\n\n` +
            
            `*🎲 GENERATORS*\n` +
            `• ${config.PREFIX}email - Random emails\n` +
            `• ${config.PREFIX}uuid - UUIDs\n\n` +
            
            `*🌐 WEB*\n` +
            `• ${config.PREFIX}browse - Fetch webpage\n` +
            `• ${config.PREFIX}tinyurl - Shorten URL\n` +
            `• ${config.PREFIX}screenshot - Website screenshot\n` +
            `• ${config.PREFIX}subdomains - Find subdomains\n\n` +
            
            `*🌍 INFO*\n` +
            `• ${config.PREFIX}countryinfo - Country details\n` +
            `• ${config.PREFIX}githubstalk - GitHub profile\n` +
            `• ${config.PREFIX}youtubestalk - Channel info\n\n` +
            
            `*🧮 MATH & TEXT*\n` +
            `• ${config.PREFIX}calc - Calculate\n` +
            `• ${config.PREFIX}fliptext - Flip text\n` +
            `• ${config.PREFIX}emojimix - Mix emojis\n` +
            `• ${config.PREFIX}zodiak - Zodiac info\n\n` +
            
            `> created by wanga`;

        await sock.sendMessage(from, { text: helpText }, { quoted: msg });
        await react('✅');
    }
});

module.exports = { commands };
