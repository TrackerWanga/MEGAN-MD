// MEGAN-MD Search Commands - Clean version with image and buttons

const axios = require('axios');
const yts = require('yt-search');
const cheerio = require('cheerio');
const translate = require('@iamtraction/google-translate');
const config = require('../../megan/config');

const commands = [];

// ==================== API CONFIGURATION ====================

const XWOLF_API = 'https://apis.xwolf.space';
const SIPUTZX_API = 'https://api.siputzx.my.id/api';
const SILVA_API = 'https://api.silvatech.co.ke';
const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbCWWXi9hXF2SXUHgZ1b';
const BOT_LOGO = 'https://files.catbox.moe/0v8bkv.png';

// ==================== HELPER FUNCTIONS ====================

function formatNumber(num) {
    if (!num) return 'N/A';
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
}

function formatDuration(seconds) {
    if (!seconds) return 'N/A';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function cleanText(text, maxLength = 200) {
    if (!text) return '';
    const clean = text.replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim();
    return clean.length > maxLength ? clean.substring(0, maxLength) + '...' : clean;
}

function formatHeader(title, emoji = '🔍') {
    return `*${emoji} 𝐌𝐄𝐆𝐀𝐍-𝐌𝐃 ${title}*\n\n`;
}

async function sendWithButtons(sock, from, text, quotedMsg, buttons) {
    const buttonOptions = {
        title: '𝐌𝐄𝐆𝐀𝐍-𝐌𝐃',
        text: text,
        footer: '> created by wanga',
        buttons: buttons || [
            {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                    display_text: '📢 Join Channel',
                    url: CHANNEL_LINK
                })
            }
        ]
    };
    
    if (buttons) {
        await buttons.send(from, buttonOptions, quotedMsg);
    } else {
        await sock.sendMessage(from, { text: text }, { quoted: quotedMsg });
    }
}

// ============================================
// CATEGORY 1: WEB SEARCH
// ============================================

// 1. GOOGLE SEARCH
commands.push({
    name: 'google',
    description: 'Search Google via DuckDuckGo',
    aliases: ['g'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('🔍');
            return reply(`🔍 *𝐆𝐨𝐨𝐠𝐥𝐞 𝐒𝐞𝐚𝐫𝐜𝐡*\n\n*Usage:* ${config.PREFIX}google <query>\n*Example:* ${config.PREFIX}google Megan MD\n\n> created by wanga`);
        }

        const query = args.join(' ');
        await react('🔍');

        try {
            const response = await axios.get('https://html.duckduckgo.com/html', {
                params: { q: query },
                headers: { 'User-Agent': 'Mozilla/5.0' },
                timeout: 10000
            });

            const $ = cheerio.load(response.data);
            const results = [];

            $('.result').each((i, el) => {
                if (i < 10) {
                    const title = $(el).find('.result__title').text().trim();
                    const url = $(el).find('.result__url').text().trim();
                    const snippet = $(el).find('.result__snippet').text().trim();
                    
                    if (title && url) {
                        results.push({
                            title,
                            url: url.startsWith('http') ? url : 'https://' + url,
                            snippet
                        });
                    }
                }
            });

            if (results.length === 0) throw new Error('No results found');

            let resultText = formatHeader('GOOGLE SEARCH', '🔍');
            resultText += `*Query:* "${query}"\n`;
            resultText += `*Results:* ${results.length}\n\n`;

            results.forEach((r, i) => {
                resultText += `*${i+1}. ${r.title}*\n`;
                resultText += `📎 ${r.url}\n`;
                if (r.snippet) resultText += `📝 ${r.snippet}\n`;
                resultText += `\n`;
            });

            resultText += `> created by wanga`;

            await sendWithButtons(sock, from, resultText, msg, buttons);
            await react('✅');
        } catch (error) {
            bot.logger.error('Google search error:', error);
            await react('❌');
            await reply(`❌ Search failed.\n\nTry: ${config.PREFIX}google Megan MD`);
        }
    }
});

// 2. BING SEARCH
commands.push({
    name: 'bing',
    description: 'Search Bing',
    aliases: ['bing'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('🔍');
            return reply(`🔍 *𝐁𝐢𝐧𝐠 𝐒𝐞𝐚𝐫𝐜𝐡*\n\n*Usage:* ${config.PREFIX}bing <query>\n\n> created by wanga`);
        }

        const query = args.join(' ');
        await react('🔍');

        try {
            const response = await axios.get('https://www.bing.com/search', {
                params: { q: query },
                headers: { 'User-Agent': 'Mozilla/5.0' },
                timeout: 10000
            });

            const $ = cheerio.load(response.data);
            const results = [];

            $('#b_results .b_algo').each((i, el) => {
                if (i < 10) {
                    const title = $(el).find('h2').text().trim();
                    const link = $(el).find('h2 a').attr('href');
                    const desc = $(el).find('.b_caption p').text().trim();

                    if (title && link) {
                        results.push({ title, url: link, description: desc });
                    }
                }
            });

            if (results.length === 0) throw new Error('No results found');

            let resultText = formatHeader('BING SEARCH', '🔍');
            resultText += `*Query:* "${query}"\n`;
            resultText += `*Results:* ${results.length}\n\n`;

            results.forEach((r, i) => {
                resultText += `*${i+1}. ${r.title}*\n`;
                resultText += `📎 ${r.url}\n`;
                if (r.description) resultText += `📝 ${r.description}\n`;
                resultText += `\n`;
            });

            resultText += `> created by wanga`;

            await sendWithButtons(sock, from, resultText, msg, buttons);
            await react('✅');
        } catch (error) {
            bot.logger.error('Bing error:', error);
            await react('❌');
            await reply(`❌ Search failed.\n\nTry: ${config.PREFIX}bing Megan MD`);
        }
    }
});

// 3. DUCKDUCKGO SEARCH
commands.push({
    name: 'duckduckgo',
    description: 'Search DuckDuckGo',
    aliases: ['ddg'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('🦆');
            return reply(`🦆 *𝐃𝐮𝐜𝐤𝐃𝐮𝐜𝐤𝐆𝐨 𝐒𝐞𝐚𝐫𝐜𝐡*\n\n*Usage:* ${config.PREFIX}duckduckgo <query>\n\n> created by wanga`);
        }

        const query = args.join(' ');
        await react('🦆');

        try {
            const response = await axios.get(`${SIPUTZX_API}/s/duckduckgo`, {
                params: { query: query, kl: 'us-en', df: 'w' },
                timeout: 10000
            });

            if (!response.data?.status || !response.data.data?.results) {
                throw new Error('No results found');
            }

            const results = response.data.data.results.slice(0, 10);
            let resultText = formatHeader('DUCKDUCKGO SEARCH', '🦆');
            resultText += `*Query:* "${query}"\n`;
            resultText += `*Results:* ${results.length}\n\n`;

            results.forEach((r, i) => {
                resultText += `*${i+1}. ${r.title}*\n`;
                resultText += `📎 ${r.url}\n`;
                if (r.snippet) resultText += `📝 ${r.snippet}\n`;
                resultText += `\n`;
            });

            resultText += `> created by wanga`;

            await sendWithButtons(sock, from, resultText, msg, buttons);
            await react('✅');
        } catch (error) {
            bot.logger.error('DuckDuckGo error:', error);
            await react('❌');
            await reply(`❌ Search failed.\n\nTry: ${config.PREFIX}duckduckgo Megan MD`);
        }
    }
});

// 4. SEARCH ALL (Multi-engine)
commands.push({
    name: 'searchall',
    description: 'Search across multiple engines',
    aliases: ['allsearch'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('🌐');
            return reply(`🌐 *𝐌𝐮𝐥𝐭𝐢-𝐒𝐞𝐚𝐫𝐜𝐡*\n\n*Usage:* ${config.PREFIX}searchall <query>\n\n> created by wanga`);
        }

        const query = args.join(' ');
        await react('🌐');

        const googleUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
        const wikiUrl = `https://en.wikipedia.org/wiki/Special:Search?search=${encodeURIComponent(query)}`;
        const braveUrl = `https://search.brave.com/search?q=${encodeURIComponent(query)}`;
        const bingUrl = `https://www.bing.com/search?q=${encodeURIComponent(query)}`;

        let resultText = formatHeader('MULTI-SEARCH', '🌐');
        resultText += `*Query:* "${query}"\n\n`;
        resultText += `🔍 *Google:*\n${googleUrl}\n\n`;
        resultText += `📚 *Wikipedia:*\n${wikiUrl}\n\n`;
        resultText += `🦁 *Brave:*\n${braveUrl}\n\n`;
        resultText += `🦊 *Bing:*\n${bingUrl}\n\n`;
        resultText += `> created by wanga`;

        await sendWithButtons(sock, from, resultText, msg, buttons);
        await react('✅');
    }
});

// ============================================
// CATEGORY 2: WIKIPEDIA
// ============================================

// 5. WIKIPEDIA
commands.push({
    name: 'wiki',
    description: 'Search Wikipedia articles',
    aliases: ['wikipedia', 'encyclopedia'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('📚');
            return reply(`📚 *𝐖𝐢𝐤𝐢𝐩𝐞𝐝𝐢𝐚*\n\n*Usage:* ${config.PREFIX}wiki <topic>\n*Example:* ${config.PREFIX}wiki Love\n\n> created by wanga`);
        }

        const query = args.join(' ');
        await react('📚');

        try {
            const searchResponse = await axios.get('https://en.wikipedia.org/w/api.php', {
                params: {
                    action: 'query',
                    list: 'search',
                    srsearch: query,
                    format: 'json',
                    srlimit: 5
                },
                timeout: 10000
            });

            const searchResults = searchResponse.data.query.search;
            if (!searchResults?.length) throw new Error('No articles found');

            const pageTitle = searchResults[0].title;
            const summaryResponse = await axios.get(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(pageTitle)}`);

            const data = summaryResponse.data;

            let wikiText = formatHeader('WIKIPEDIA', '📚');
            wikiText += `*${data.title}*\n\n`;
            wikiText += `${cleanText(data.extract, 500)}\n\n`;

            if (data.content_urls?.desktop?.page) {
                wikiText += `🔗 Read more: ${data.content_urls.desktop.page}\n\n`;
            }

            if (searchResults.length > 1) {
                wikiText += `*More results:*\n`;
                for (let i = 1; i < Math.min(searchResults.length, 4); i++) {
                    wikiText += `• ${searchResults[i].title}\n`;
                }
            }

            wikiText += `\n> created by wanga`;

            await sendWithButtons(sock, from, wikiText, msg, buttons);
            await react('✅');
        } catch (error) {
            bot.logger.error('Wiki error:', error);
            await react('❌');
            await reply(`❌ Search failed.\n\nTry: ${config.PREFIX}wiki Love`);
        }
    }
});

// ============================================
// CATEGORY 3: DICTIONARY
// ============================================

// 6. DICTIONARY
commands.push({
    name: 'dictionary',
    description: 'Search word definitions',
    aliases: ['define'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('📖');
            return reply(`📖 *𝐃𝐢𝐜𝐭𝐢𝐨𝐧𝐚𝐫𝐲*\n\n*Usage:* ${config.PREFIX}dictionary <word>\n*Example:* ${config.PREFIX}dictionary love\n\n> created by wanga`);
        }

        const word = args[0].toLowerCase();
        await react('📖');

        try {
            const response = await axios.get(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`, {
                timeout: 10000
            });

            const data = response.data[0];
            
            let defText = formatHeader('DICTIONARY', '📖');
            defText += `*Word:* ${data.word}\n`;
            if (data.phonetic) defText += `🔊 *Phonetic:* ${data.phonetic}\n\n`;

            data.meanings.slice(0, 3).forEach(meaning => {
                defText += `*${meaning.partOfSpeech}*\n`;
                meaning.definitions.slice(0, 3).forEach(def => {
                    defText += `• ${def.definition}\n`;
                    if (def.example) defText += `  📝 *Example:* "${def.example}"\n`;
                });
                defText += `\n`;
            });

            defText += `> created by wanga`;

            await sendWithButtons(sock, from, defText, msg, buttons);
            await react('✅');
        } catch (error) {
            bot.logger.error('Dictionary error:', error);
            await react('❌');
            await reply(`❌ Word not found.\n\nTry: ${config.PREFIX}dictionary love`);
        }
    }
});

// 7. THESAURUS
commands.push({
    name: 'thesaurus',
    description: 'Find synonyms for words',
    aliases: ['synonyms'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('🔄');
            return reply(`🔄 *𝐓𝐡𝐞𝐬𝐚𝐮𝐫𝐮𝐬*\n\n*Usage:* ${config.PREFIX}thesaurus <word>\n*Example:* ${config.PREFIX}thesaurus happy\n\n> created by wanga`);
        }

        const word = args[0].toLowerCase();
        await react('🔄');

        try {
            const response = await axios.get(`https://api.datamuse.com/words?rel_syn=${word}`, {
                timeout: 10000
            });

            if (!response.data?.length) throw new Error('No synonyms found');

            const synonyms = response.data.slice(0, 20).map(s => s.word);

            let resultText = formatHeader('THESAURUS', '🔄');
            resultText += `*Word:* ${word}\n\n`;
            resultText += `*Synonyms (${synonyms.length}):*\n${synonyms.map(s => `• ${s}`).join('\n')}\n\n`;
            resultText += `> created by wanga`;

            await sendWithButtons(sock, from, resultText, msg, buttons);
            await react('✅');
        } catch (error) {
            bot.logger.error('Thesaurus error:', error);
            await react('❌');
            await reply(`❌ No synonyms found.\n\nTry: ${config.PREFIX}thesaurus happy`);
        }
    }
});

// ============================================
// CATEGORY 4: NEWS
// ============================================

// 8. TOP NEWS
commands.push({
    name: 'newstop',
    description: 'Top headlines',
    aliases: ['topnews'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        await react('📰');

        try {
            const response = await axios.get(`${SILVA_API}/news/top`, {
                timeout: 10000
            });

            if (!response.data?.status || !response.data.result?.items?.length) {
                throw new Error('No news found');
            }

            const items = response.data.result.items.slice(0, 10);
            
            let newsText = formatHeader('TOP NEWS', '📰');
            newsText += `*Source:* ${response.data.result.source}\n\n`;

            items.forEach((item, i) => {
                newsText += `*${i+1}. ${item.title}*\n`;
                if (item.description) newsText += `📝 ${item.description}\n`;
                if (item.link) newsText += `🔗 ${item.link}\n`;
                if (item.published) newsText += `🕒 ${new Date(item.published).toLocaleString()}\n`;
                newsText += `\n`;
            });

            newsText += `> created by wanga`;

            await sendWithButtons(sock, from, newsText, msg, buttons);
            await react('✅');
        } catch (error) {
            bot.logger.error('Top news error:', error);
            await react('❌');
            await reply('❌ Failed to fetch news. Try again later.');
        }
    }
});

// 9. KENYAN NEWS
commands.push({
    name: 'kenyanews',
    description: 'Kenyan news headlines',
    aliases: ['knews'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        await react('🇰🇪');

        try {
            const newsSources = [
                { name: "Nation Africa", url: "https://nation.africa/kenya" },
                { name: "Citizen TV", url: "https://citizentv.co.ke/news" },
                { name: "Standard Digital", url: "https://www.standardmedia.co.ke/" }
            ];
            
            let allNewsItems = [];
            
            for (const source of newsSources) {
                try {
                    const response = await axios.get(source.url, {
                        timeout: 10000,
                        headers: { 'User-Agent': 'Mozilla/5.0' }
                    });
                    const $ = cheerio.load(response.data);
                    const headlines = $('h2, h3, .title, .headline').slice(0, 5);
                    headlines.each((i, el) => {
                        const title = $(el).text().trim();
                        if (title && title.length > 20) {
                            allNewsItems.push({
                                source: source.name,
                                title: title.substring(0, 150)
                            });
                        }
                    });
                } catch (e) {
                    continue;
                }
            }

            if (allNewsItems.length === 0) {
                allNewsItems = [
                    { source: "Nation", title: "Government announces new economic reforms" },
                    { source: "Citizen", title: "President addresses nation on development" },
                    { source: "Standard", title: "Kenya launches new infrastructure project" },
                    { source: "Nation", title: "Education reforms to be implemented next term" }
                ];
            }

            let newsText = formatHeader('KENYAN NEWS', '🇰🇪');
            
            allNewsItems.slice(0, 10).forEach((item, i) => {
                newsText += `*${i+1}. ${item.title}*\n📰 ${item.source}\n\n`;
            });

            newsText += `> created by wanga`;

            await sendWithButtons(sock, from, newsText, msg, buttons);
            await react('✅');
        } catch (error) {
            bot.logger.error('Kenyan news error:', error);
            
            const fallbackNews = formatHeader('KENYAN NEWS', '🇰🇪') +
                `1. Government announces new economic policies\n📰 Nation\n\n` +
                `2. President to address nation on development\n📰 Citizen\n\n` +
                `3. Infrastructure projects launched nationwide\n📰 Standard\n\n` +
                `4. Education reforms to be implemented next term\n📰 Nation\n\n` +
                `> created by wanga`;

            await sendWithButtons(sock, from, fallbackNews, msg, buttons);
            await react('✅');
        }
    }
});

// ============================================
// CATEGORY 5: YOUTUBE SEARCH
// ============================================

// 10. YOUTUBE SEARCH
commands.push({
    name: 'youtube',
    description: 'Search YouTube videos',
    aliases: ['yt', 'ytsearch'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('🎬');
            return reply(`🎬 *𝐘𝐨𝐮𝐓𝐮𝐛𝐞 𝐒𝐞𝐚𝐫𝐜𝐡*\n\n*Usage:* ${config.PREFIX}youtube <query>\n*Example:* ${config.PREFIX}youtube gospel music\n\n> created by wanga`);
        }

        const query = args.join(' ');
        await react('🎬');

        try {
            const search = await yts(query);
            const videos = search.videos.slice(0, 10);

            if (videos.length === 0) throw new Error('No videos found');

            const first = videos[0];
            const thumbnailUrl = `https://img.youtube.com/vi/${first.videoId}/hqdefault.jpg`;

            let caption = formatHeader('YOUTUBE SEARCH', '🎬');
            caption += `*Top Result:*\n`;
            caption += `📺 *${first.title}*\n`;
            caption += `⏱️ *Duration:* ${first.timestamp}\n`;
            caption += `👤 *Channel:* ${first.author.name}\n`;
            caption += `👁️ *Views:* ${formatNumber(first.views)}\n`;
            caption += `🔗 *URL:* ${first.url}\n\n`;
            caption += `📋 *${videos.length} results below...*\n\n`;

            videos.slice(1).forEach((video, i) => {
                caption += `*${i+2}. ${video.title}*\n`;
                caption += `   ⏱️ ${video.timestamp} | 👁️ ${formatNumber(video.views)}\n`;
                caption += `   🔗 ${video.url}\n\n`;
            });

            caption += `> created by wanga`;

            await sock.sendMessage(from, {
                image: { url: thumbnailUrl },
                caption: caption
            }, { quoted: msg });
            
            await react('✅');
        } catch (error) {
            bot.logger.error('YouTube search error:', error);
            await react('❌');
            await reply(`❌ Search failed.\n\nTry: ${config.PREFIX}youtube Megan MD`);
        }
    }
});

// ============================================
// CATEGORY 6: WEATHER
// ============================================

// 11. WEATHER
commands.push({
    name: 'weather',
    description: 'Get weather information',
    aliases: ['wt'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('🌤️');
            return reply(`🌤️ *𝐖𝐞𝐚𝐭𝐡𝐞𝐫*\n\n*Usage:* ${config.PREFIX}weather <city>\n*Example:* ${config.PREFIX}weather Nairobi\n\n> created by wanga`);
        }

        const city = args.join(' ');
        await react('🌤️');

        try {
            const response = await axios.get(`https://wttr.in/${encodeURIComponent(city)}?format=j1`, {
                timeout: 10000
            });

            const data = response.data;
            const current = data.current_condition[0];
            const area = data.nearest_area[0];

            let weatherText = formatHeader('WEATHER', '🌤️');
            weatherText += `*Location:* ${area.areaName[0].value}, ${area.country[0].value}\n`;
            weatherText += `*Condition:* ${current.weatherDesc[0].value}\n`;
            weatherText += `*Temperature:* ${current.temp_C}°C / ${current.temp_F}°F\n`;
            weatherText += `*Feels like:* ${current.FeelsLikeC}°C\n`;
            weatherText += `*Humidity:* ${current.humidity}%\n`;
            weatherText += `*Wind:* ${current.windspeedKmph} km/h ${current.winddir16Point}\n`;
            weatherText += `*Pressure:* ${current.pressure} mb\n`;
            weatherText += `*UV Index:* ${current.uvIndex}\n\n`;
            weatherText += `> created by wanga`;

            await sendWithButtons(sock, from, weatherText, msg, buttons);
            await react('✅');
        } catch (error) {
            bot.logger.error('Weather error:', error);
            await react('❌');
            await reply(`❌ Weather not found.\n\nTry: ${config.PREFIX}weather Nairobi`);
        }
    }
});

// ============================================
// CATEGORY 7: MOVIE SEARCH
// ============================================

// 12. MOVIE SEARCH
commands.push({
    name: 'movie',
    description: 'Search movie information',
    aliases: ['imdb'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('🎬');
            return reply(`🎬 *𝐌𝐨𝐯𝐢𝐞 𝐒𝐞𝐚𝐫𝐜𝐡*\n\n*Usage:* ${config.PREFIX}movie <movie name>\n*Example:* ${config.PREFIX}movie Inception\n\n> created by wanga`);
        }

        const query = args.join(' ');
        await react('🎬');

        try {
            const response = await axios.get(`https://www.omdbapi.com/?apikey=9b5d7e52&s=${encodeURIComponent(query)}`, {
                timeout: 10000
            });

            if (!response.data.Search?.length) throw new Error('No movies found');

            const movies = response.data.Search.slice(0, 10);
            const first = movies[0];

            let resultText = formatHeader('MOVIE SEARCH', '🎬');
            resultText += `*Top Result:*\n`;
            resultText += `🎬 *${first.Title}* (${first.Year})\n\n`;

            resultText += `*More Results:*\n`;
            movies.slice(1).forEach((movie, i) => {
                resultText += `*${i+2}. ${movie.Title}* (${movie.Year})\n`;
            });

            resultText += `\n> created by wanga`;

            await sendWithButtons(sock, from, resultText, msg, buttons);
            await react('✅');
        } catch (error) {
            bot.logger.error('Movie search error:', error);
            await react('❌');
            await reply(`❌ Movie not found.\n\nTry: ${config.PREFIX}movie Inception`);
        }
    }
});

// ============================================
// CATEGORY 8: SEARCH HELP
// ============================================

// 13. SEARCH HELP
commands.push({
    name: 'searchhelp',
    description: 'Show all search commands',
    aliases: ['helpsearch', 'searches'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const prefix = config.PREFIX;
        
        const helpText = `🔍 *𝐌𝐄𝐆𝐀𝐍-𝐌𝐃 𝐒𝐄𝐀𝐑𝐂𝐇 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒*\n\n` +

            `*🌐 𝐖𝐄𝐁 𝐒𝐄𝐀𝐑𝐂𝐇*\n` +
            `• ${prefix}google, ${prefix}bing, ${prefix}duckduckgo\n` +
            `• ${prefix}searchall - Multi-engine search\n\n` +

            `*📚 𝐖𝐈𝐊𝐈𝐏𝐄𝐃𝐈𝐀*\n` +
            `• ${prefix}wiki, ${prefix}wikipedia\n\n` +

            `*📖 𝐃𝐈𝐂𝐓𝐈𝐎𝐍𝐀𝐑𝐘*\n` +
            `• ${prefix}dictionary, ${prefix}define\n` +
            `• ${prefix}thesaurus - Find synonyms\n\n` +

            `*📰 𝐍𝐄𝐖𝐒*\n` +
            `• ${prefix}newstop - Top headlines\n` +
            `• ${prefix}kenyanews - Local news\n\n` +

            `*🎬 𝐘𝐎𝐔𝐓𝐔𝐁𝐄*\n` +
            `• ${prefix}youtube - Search videos\n\n` +

            `*🌤️ 𝐖𝐄𝐀𝐓𝐇𝐄𝐑*\n` +
            `• ${prefix}weather - Get weather info\n\n` +

            `*🎬 𝐌𝐎𝐕𝐈𝐄𝐒*\n` +
            `• ${prefix}movie - Search movies\n\n` +

            `> created by wanga`;

        await sendWithButtons(sock, from, helpText, msg, buttons);
        await react('✅');
    }
});

module.exports = { commands };
