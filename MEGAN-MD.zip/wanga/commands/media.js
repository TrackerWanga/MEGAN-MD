// MEGAN-MD Media Commands - Clean version with buttons

const axios = require('axios');
const fs = require('fs-extra');
const path = require('path');
const config = require('../../megan/config');
const MediaProcessor = require('../../megan/lib/mediaProcessor');
const { downloadMediaMessage } = require('gifted-baileys');

const commands = [];
const mediaProcessor = new MediaProcessor();
const TEMP_DIR = path.join(__dirname, '../../temp');
fs.ensureDirSync(TEMP_DIR);

const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbCWWXi9hXF2SXUHgZ1b';

// Static meme images
const MEME_IMAGES = [
    'https://files.catbox.moe/xnqfhk.jpg',
    'https://files.catbox.moe/99jcbd.jpg',
    'https://files.catbox.moe/a8yflv.jpg',
    'https://files.catbox.moe/xn7fef.jpg',
    'https://files.catbox.moe/fzo3sg.jpg',
    'https://files.catbox.moe/ypi5fw.jpg',
    'https://files.catbox.moe/f9eqxi.jpg',
    'https://files.catbox.moe/eswum9.jpg',
    'https://files.catbox.moe/1w2z1i.jpg',
    'https://files.catbox.moe/5qkf90.jpg',
    'https://files.catbox.moe/hp4nki.jpg',
    'https://files.catbox.moe/hq6hhu.jpg',
    'https://files.catbox.moe/ggwzc9.jpg',
    'https://files.catbox.moe/evpzeb.jpg',
    'https://files.catbox.moe/xdtch8.jpg',
    'https://files.catbox.moe/u8itde.jpg',
    'https://files.catbox.moe/qzmfuo.jpg',
    'https://files.catbox.moe/lgqabr.jpg',
    'https://files.catbox.moe/rxoajf.jpg',
    'https://files.catbox.moe/k1qck3.jpg',
    'https://files.catbox.moe/al7u80.jpg'
];

// Helper functions
async function downloadMedia(msg) {
    return await downloadMediaMessage(msg, 'buffer', {}, { logger: console });
}

async function uploadToCatbox(buffer, filename) {
    const FormData = require('form-data');
    const formData = new FormData();
    formData.append('reqtype', 'fileupload');
    formData.append('fileToUpload', buffer, { filename });
    
    const response = await axios.post('https://catbox.moe/user/api.php', formData, {
        headers: formData.getHeaders()
    });
    return response.data.trim();
}

function formatFileSize(bytes) {
    if (bytes >= 1024 * 1024 * 1024) return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
    if (bytes >= 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    if (bytes >= 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return bytes + ' bytes';
}

// ==================== STICKER COMMANDS ====================

// 1. STICKER MAKER
commands.push({
    name: 'sticker',
    description: 'Create sticker from image/video',
    aliases: ['s', 'stick'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const hasImage = msg.message?.imageMessage || quoted?.imageMessage;
        const hasVideo = msg.message?.videoMessage || quoted?.videoMessage;
        
        if (!hasImage && !hasVideo) {
            await react('❌');
            return reply(`🎨 *𝐒𝐓𝐈𝐂𝐊𝐄𝐑 𝐌𝐀𝐊𝐄𝐑*\n\n*Usage:* Reply to image/video with ${config.PREFIX}sticker\n\n> created by wanga`);
        }
        
        await react('🎨');
        const targetMsg = msg.message?.imageMessage || msg.message?.videoMessage ? msg : { ...msg, message: quoted };
        const buffer = await downloadMedia(targetMsg);
        const stickerBuffer = await mediaProcessor.createSticker(buffer);
        
        await sock.sendMessage(from, { sticker: stickerBuffer }, { quoted: msg });
        
        const buttonOptions = {
            title: '✅ 𝐒𝐓𝐈𝐂𝐊𝐄𝐑 𝐂𝐑𝐄𝐀𝐓𝐄𝐃',
            text: `🎨 *Sticker created successfully!*\n\nJoin our channel for more updates.`,
            footer: '> created by wanga',
            buttons: [
                {
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📢 Join Channel',
                        url: CHANNEL_LINK
                    })
                }
            ]
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        }
        await react('✅');
    }
});

// 2. STICKER TO IMAGE
commands.push({
    name: 'toimage',
    description: 'Convert sticker to image',
    aliases: ['img', 'toimg'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const hasSticker = msg.message?.stickerMessage || quoted?.stickerMessage;
        
        if (!hasSticker) {
            await react('❌');
            return reply(`🖼️ *𝐒𝐓𝐈𝐂𝐊𝐄𝐑 𝐓𝐎 𝐈𝐌𝐀𝐆𝐄*\n\n*Usage:* Reply to sticker with ${config.PREFIX}toimage\n\n> created by wanga`);
        }
        
        await react('🔄');
        const targetMsg = msg.message?.stickerMessage ? msg : { ...msg, message: quoted };
        const buffer = await downloadMedia(targetMsg);
        const imageBuffer = await mediaProcessor.stickerToImage(buffer);
        
        await sock.sendMessage(from, {
            image: imageBuffer,
            caption: `✅ *Converted to image*\n\n> created by wanga`
        }, { quoted: msg });
        
        const buttonOptions = {
            title: '✅ 𝐈𝐌𝐀𝐆𝐄 𝐂𝐑𝐄𝐀𝐓𝐄𝐃',
            text: `🖼️ *Sticker converted to image successfully!*\n\nJoin our channel for more tools.`,
            footer: '> created by wanga',
            buttons: [
                {
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📢 Join Channel',
                        url: CHANNEL_LINK
                    })
                }
            ]
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        }
        await react('✅');
    }
});

// ==================== AUDIO COMMANDS ====================

// 3. TEXT TO SPEECH (audio)
commands.push({
    name: 'say',
    description: 'Convert text to audio',
    aliases: ['tts'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('🗣️');
            return reply(`🗣️ *𝐓𝐄𝐗𝐓 𝐓𝐎 𝐒𝐏𝐄𝐄𝐂𝐇*\n\n*Usage:* ${config.PREFIX}say <text>\n*Example:* ${config.PREFIX}say Hello world\n\n> created by wanga`);
        }
        
        const text = args.join(' ').substring(0, 200);
        await react('🗣️');

        const ttsUrl = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(text)}&tl=en&client=tw-ob`;
        const response = await axios({ method: 'GET', url: ttsUrl, responseType: 'arraybuffer', timeout: 30000 });
        const audioBuffer = Buffer.from(response.data);
        const formattedAudio = await mediaProcessor.toAudio(audioBuffer);

        await sock.sendMessage(from, {
            audio: formattedAudio,
            mimetype: 'audio/mpeg',
            ptt: false
        }, { quoted: msg });
        
        const buttonOptions = {
            title: '✅ 𝐀𝐔𝐃𝐈𝐎 𝐂𝐑𝐄𝐀𝐓𝐄𝐃',
            text: `🗣️ *Text converted to audio*\n\nJoin our channel for more features.`,
            footer: '> created by wanga',
            buttons: [
                {
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📢 Join Channel',
                        url: CHANNEL_LINK
                    })
                }
            ]
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        }
        await react('✅');
    }
});

// 4. VOICE NOTE (PTT)
commands.push({
    name: 'voice',
    description: 'Convert text to voice note',
    aliases: ['vn', 'voicenote'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('🎤');
            return reply(`🎤 *𝐕𝐎𝐈𝐂𝐄 𝐍𝐎𝐓𝐄*\n\n*Usage:* ${config.PREFIX}voice <text>\n*Example:* ${config.PREFIX}voice Hello world\n\n> created by wanga`);
        }
        
        const text = args.join(' ').substring(0, 200);
        await react('🎤');

        const ttsUrl = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(text)}&tl=en&client=tw-ob`;
        const response = await axios({ method: 'GET', url: ttsUrl, responseType: 'arraybuffer', timeout: 30000 });
        const audioBuffer = Buffer.from(response.data);
        const pttBuffer = await mediaProcessor.toPTT(audioBuffer);

        await sock.sendMessage(from, {
            audio: pttBuffer,
            mimetype: 'audio/ogg; codecs=opus',
            ptt: true
        }, { quoted: msg });
        
        const buttonOptions = {
            title: '✅ 𝐕𝐎𝐈𝐂𝐄 𝐍𝐎𝐓𝐄 𝐂𝐑𝐄𝐀𝐓𝐄𝐃',
            text: `🎤 *Voice note created successfully!*\n\nJoin our channel for more tools.`,
            footer: '> created by wanga',
            buttons: [
                {
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📢 Join Channel',
                        url: CHANNEL_LINK
                    })
                }
            ]
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        }
        await react('✅');
    }
});

// 5. EXTRACT AUDIO FROM VIDEO
commands.push({
    name: 'toaudio',
    description: 'Extract audio from video',
    aliases: ['mp3', 'extract'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const hasVideo = msg.message?.videoMessage || quoted?.videoMessage;
        
        if (!hasVideo) {
            await react('❌');
            return reply(`🎵 *𝐀𝐔𝐃𝐈𝐎 𝐄𝐗𝐓𝐑𝐀𝐂𝐓𝐎𝐑*\n\n*Usage:* Reply to video with ${config.PREFIX}toaudio\n\n> created by wanga`);
        }
        
        await react('🎵');
        const targetMsg = msg.message?.videoMessage ? msg : { ...msg, message: quoted };
        const buffer = await downloadMedia(targetMsg);
        const audioBuffer = await mediaProcessor.extractAudio(buffer);

        await sock.sendMessage(from, {
            audio: audioBuffer,
            mimetype: 'audio/mpeg',
            ptt: false
        }, { quoted: msg });
        
        const buttonOptions = {
            title: '✅ 𝐀𝐔𝐃𝐈𝐎 𝐄𝐗𝐓𝐑𝐀𝐂𝐓𝐄𝐃',
            text: `🎵 *Audio extracted from video!*\n\nJoin our channel for more features.`,
            footer: '> created by wanga',
            buttons: [
                {
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📢 Join Channel',
                        url: CHANNEL_LINK
                    })
                }
            ]
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        }
        await react('✅');
    }
});

// ==================== IMAGE COMMANDS ====================

// 6. CIRCLE IMAGE
commands.push({
    name: 'circle',
    description: 'Make circular image',
    aliases: ['round'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const hasImage = msg.message?.imageMessage || quoted?.imageMessage;
        
        if (!hasImage) {
            await react('⭕');
            return reply(`⭕ *𝐂𝐈𝐑𝐂𝐋𝐄 𝐈𝐌𝐀𝐆𝐄*\n\n*Usage:* Reply to image with ${config.PREFIX}circle\n\n> created by wanga`);
        }
        
        await react('🔄');
        const targetMsg = msg.message?.imageMessage ? msg : { ...msg, message: quoted };
        const buffer = await downloadMedia(targetMsg);
        const circleBuffer = await mediaProcessor.createCircle(buffer);

        await sock.sendMessage(from, {
            image: circleBuffer,
            caption: `✅ *Circular image created*\n\n> created by wanga`
        }, { quoted: msg });
        
        const buttonOptions = {
            title: '✅ 𝐂𝐈𝐑𝐂𝐋𝐄 𝐈𝐌𝐀𝐆𝐄',
            text: `⭕ *Image converted to circle!*\n\nJoin our channel for more tools.`,
            footer: '> created by wanga',
            buttons: [
                {
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📢 Join Channel',
                        url: CHANNEL_LINK
                    })
                }
            ]
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        }
        await react('✅');
    }
});

// 7. TEXT PRO EFFECT
commands.push({
    name: 'textpro',
    description: 'Create text effects',
    aliases: ['texteffect'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (args.length < 2) {
            await react('🎨');
            return reply(`🎨 *𝐓𝐄𝐗𝐓𝐏𝐑𝐎 𝐄𝐅𝐅𝐄𝐂𝐓𝐒*\n\n*Usage:* ${config.PREFIX}textpro <effect> <text>\n\n*Effects:* 3d, neon, gold, fire, matrix\n\n*Example:* ${config.PREFIX}textpro 3d MEGAN\n\n> created by wanga`);
        }

        const effect = args[0].toLowerCase();
        const text = args.slice(1).join(' ');
        
        const effectUrls = {
            '3d': 'https://textpro.me/create-3d-text-effects-1046.html',
            'neon': 'https://textpro.me/neon-text-effect-1019.html',
            'gold': 'https://textpro.me/gold-text-effect-1060.html',
            'fire': 'https://textpro.me/fire-text-effect-1073.html',
            'matrix': 'https://textpro.me/matrix-style-text-effect-1107.html'
        };

        const url = effectUrls[effect];
        if (!url) {
            return reply(`❌ *Invalid effect!* Available: 3d, neon, gold, fire, matrix\n\n> created by wanga`);
        }

        await react('🎨');

        const response = await axios.get(`https://api.siputzx.my.id/api/m/textpro`, {
            params: { url: url, text1: text },
            responseType: 'arraybuffer',
            timeout: 30000
        });

        await sock.sendMessage(from, {
            image: Buffer.from(response.data),
            caption: `🎨 *𝐓𝐞𝐱𝐭𝐏𝐫𝐨 𝐄𝐟𝐟𝐞𝐜𝐭*\n\nEffect: ${effect}\nText: ${text}\n\n> created by wanga`
        }, { quoted: msg });
        
        const buttonOptions = {
            title: '✅ 𝐓𝐄𝐗𝐓 𝐄𝐅𝐅𝐄𝐂𝐓 𝐂𝐑𝐄𝐀𝐓𝐄𝐃',
            text: `🎨 *Text effect created!*\n\nJoin our channel for more tools.`,
            footer: '> created by wanga',
            buttons: [
                {
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📢 Join Channel',
                        url: CHANNEL_LINK
                    })
                }
            ]
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        }
        await react('✅');
    }
});

// ==================== UPLOAD COMMANDS ====================

// 8. CATBOX UPLOAD
commands.push({
    name: 'catbox',
    description: 'Upload media to Catbox.moe',
    aliases: ['cat'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const hasMedia = msg.message?.imageMessage || msg.message?.videoMessage || 
                       msg.message?.audioMessage || quoted?.imageMessage ||
                       quoted?.videoMessage || quoted?.audioMessage;

        if (!hasMedia && args.length === 0) {
            await react('📤');
            return reply(`📤 *𝐂𝐀𝐓𝐁𝐎𝐗 𝐔𝐏𝐋𝐎𝐀𝐃*\n\n*Usage:* Reply to media with ${config.PREFIX}catbox\nOr: ${config.PREFIX}catbox <image url>\n\n> created by wanga`);
        }

        await react('📤');

        let buffer, filename;
        
        if (args.length > 0 && args[0].startsWith('http')) {
            const response = await axios.get(args[0], { responseType: 'arraybuffer', timeout: 30000 });
            buffer = Buffer.from(response.data);
            filename = `upload_${Date.now()}.jpg`;
        } else {
            const targetMsg = msg.message?.imageMessage || msg.message?.videoMessage || msg.message?.audioMessage 
                ? msg : { ...msg, message: quoted };
            buffer = await downloadMedia(targetMsg);
            filename = `upload_${Date.now()}.jpg`;
        }

        const url = await uploadToCatbox(buffer, filename);
        const fileSize = formatFileSize(buffer.length);

        const buttonOptions = {
            title: '✅ 𝐔𝐏𝐋𝐎𝐀𝐃𝐄𝐃',
            text: `📁 *File:* ${filename}\n📦 *Size:* ${fileSize}\n🔗 *URL:* ${url}`,
            footer: '> created by wanga',
            buttons: [
                {
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📋 Copy URL',
                        copy_code: url
                    })
                },
                {
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: '🔗 Open Link',
                        url: url
                    })
                },
                {
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📢 Channel',
                        url: CHANNEL_LINK
                    })
                }
            ]
        };

        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        } else {
            await sock.sendMessage(from, { text: `✅ Uploaded: ${url}` }, { quoted: msg });
        }
        await react('✅');
    }
});

// ==================== RANDOM IMAGE COMMANDS ====================

// 9. RANDOM WAIFU
commands.push({
    name: 'waifu',
    description: 'Get random waifu image',
    aliases: ['waifuimg'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        await react('🌸');
        const response = await axios.get('https://api.siputzx.my.id/api/r/waifu', {
            responseType: 'arraybuffer',
            timeout: 10000
        });
        
        await sock.sendMessage(from, {
            image: Buffer.from(response.data),
            caption: `🌸 *𝐑𝐚𝐧𝐝𝐨𝐦 𝐖𝐚𝐢𝐟𝐮*\n\n> created by wanga`
        }, { quoted: msg });
        
        const buttonOptions = {
            title: '🌸 𝐑𝐀𝐍𝐃𝐎𝐌 𝐖𝐀𝐈𝐅𝐔',
            text: `*Enjoy your waifu image!*\n\nJoin our channel for more anime content.`,
            footer: '> created by wanga',
            buttons: [
                {
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📢 Join Channel',
                        url: CHANNEL_LINK
                    })
                },
                {
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({
                        display_text: '🔄 Another',
                        id: 'waifu'
                    })
                }
            ]
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        }
        await react('✅');
    }
});

// 10. RANDOM NEKO
commands.push({
    name: 'neko',
    description: 'Get random neko girl image',
    aliases: ['nekogirl'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        await react('🐱');
        const response = await axios.get('https://api.siputzx.my.id/api/r/neko', {
            responseType: 'arraybuffer',
            timeout: 10000
        });
        
        await sock.sendMessage(from, {
            image: Buffer.from(response.data),
            caption: `🐱 *𝐑𝐚𝐧𝐝𝐨𝐦 𝐍𝐞𝐤𝐨*\n\n> created by wanga`
        }, { quoted: msg });
        
        const buttonOptions = {
            title: '🐱 𝐑𝐀𝐍𝐃𝐎𝐌 𝐍𝐄𝐊𝐎',
            text: `*Enjoy your neko image!*\n\nJoin our channel for more cute content.`,
            footer: '> created by wanga',
            buttons: [
                {
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📢 Join Channel',
                        url: CHANNEL_LINK
                    })
                },
                {
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({
                        display_text: '🔄 Another',
                        id: 'neko'
                    })
                }
            ]
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        }
        await react('✅');
    }
});

// 11. RANDOM MEME (using static images)
commands.push({
    name: 'meme',
    description: 'Get random meme from collection',
    aliases: ['randommeme', 'memes'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        await react('😂');
        
        const randomUrl = MEME_IMAGES[Math.floor(Math.random() * MEME_IMAGES.length)];
        
        try {
            const response = await axios.get(randomUrl, {
                responseType: 'arraybuffer',
                timeout: 15000
            });
            
            const imageBuffer = Buffer.from(response.data);
            
            await sock.sendMessage(from, {
                image: imageBuffer,
                caption: `😂 *𝐑𝐚𝐧𝐝𝐨𝐦 𝐌𝐞𝐦𝐞*\n\n> created by wanga`
            }, { quoted: msg });
            
            const buttonOptions = {
                title: '😂 𝐑𝐀𝐍𝐃𝐎𝐌 𝐌𝐄𝐌𝐄',
                text: `*Enjoy your meme!*\n\nJoin our channel for more fun content.`,
                footer: '> created by wanga',
                buttons: [
                    {
                        name: 'cta_url',
                        buttonParamsJson: JSON.stringify({
                            display_text: '📢 Join Channel',
                            url: CHANNEL_LINK
                        })
                    },
                    {
                        name: 'quick_reply',
                        buttonParamsJson: JSON.stringify({
                            display_text: '🔄 Another Meme',
                            id: 'meme'
                        })
                    }
                ]
            };
            
            if (buttons) {
                await buttons.send(from, buttonOptions, msg);
            }
            await react('✅');
            
        } catch (error) {
            console.error('Meme error:', error);
            await react('❌');
            await reply(`❌ *Failed to get meme*\n\nTry again later.\n\n> created by wanga`);
        }
    }
});

// ==================== CLEANUP ====================

// 12. CLEAN TEMP FILES
commands.push({
    name: 'cleantemp',
    description: 'Clean temporary files',
    aliases: ['cleantemp'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        await react('🧹');
        const result = await mediaProcessor.cleanup();
        
        const buttonOptions = {
            title: '🧹 𝐂𝐋𝐄𝐀𝐍𝐔𝐏',
            text: `🗑️ *Deleted:* ${result.deleted} temp files\n💾 *Freed:* ${formatFileSize(result.freed || 0)}`,
            footer: '> created by wanga',
            buttons: [
                {
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📢 Join Channel',
                        url: CHANNEL_LINK
                    })
                }
            ]
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        } else {
            await sock.sendMessage(from, { text: `🧹 Deleted ${result.deleted} temp files` }, { quoted: msg });
        }
        await react('✅');
    }
});

// ==================== MEDIA HELP ====================

// 13. MEDIA HELP
commands.push({
    name: 'media',
    description: 'Show all media commands',
    aliases: ['mediahelp'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const helpText = `🛠️ *𝐌𝐄𝐃𝐈𝐀 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒*\n\n` +
        
            `*🎨 𝐒𝐓𝐈𝐂𝐊𝐄𝐑𝐒*\n` +
            `• ${config.PREFIX}sticker - Make sticker\n` +
            `• ${config.PREFIX}toimage - Sticker to image\n\n` +
            
            `*🎵 𝐀𝐔𝐃𝐈𝐎*\n` +
            `• ${config.PREFIX}say - Text to speech\n` +
            `• ${config.PREFIX}voice - Voice note\n` +
            `• ${config.PREFIX}toaudio - Extract audio\n\n` +
            
            `*🖼️ 𝐈𝐌𝐀𝐆𝐄*\n` +
            `• ${config.PREFIX}circle - Circular image\n` +
            `• ${config.PREFIX}textpro - Text effects\n` +
            `• ${config.PREFIX}waifu - Random waifu\n` +
            `• ${config.PREFIX}neko - Random neko\n` +
            `• ${config.PREFIX}meme - Random meme\n\n` +
            
            `*📤 𝐔𝐏𝐋𝐎𝐀𝐃*\n` +
            `• ${config.PREFIX}catbox - Upload to Catbox\n` +
            `• ${config.PREFIX}cleantemp - Clean temp files\n\n` +
            
            `> created by wanga`;

        const buttonOptions = {
            title: '🛠️ 𝐌𝐄𝐃𝐈𝐀 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒',
            text: helpText,
            footer: '> created by wanga',
            buttons: [
                {
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: '📢 Join Channel',
                        url: CHANNEL_LINK
                    })
                }
            ]
        };
        
        if (buttons) {
            await buttons.send(from, buttonOptions, msg);
        } else {
            await sock.sendMessage(from, { text: helpText }, { quoted: msg });
        }
        await react('✅');
    }
});

module.exports = { commands };
