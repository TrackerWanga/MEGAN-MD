// MEGAN-MD Complete Downloader - 30+ Commands with Multi-API Fallbacks

const axios = require('axios');
const yts = require('yt-search');
const fs = require('fs-extra');
const path = require('path');
const config = require('../../megan/config');

const commands = [];

const CHANNEL_LINK = 'https://whatsapp.com/channel/0029VbCWWXi9hXF2SXUHgZ1b';
const TEMP_DIR = path.join(__dirname, '../../temp');
fs.ensureDirSync(TEMP_DIR);

// Auto-clean temp files every 30 minutes
setInterval(async () => {
    try {
        const files = await fs.readdir(TEMP_DIR);
        let deleted = 0;
        for (const file of files) {
            try {
                await fs.unlink(path.join(TEMP_DIR, file));
                deleted++;
            } catch (e) {}
        }
        if (deleted > 0) console.log(`🧹 Cleaned ${deleted} temp files`);
    } catch (error) {}
}, 30 * 60 * 1000);

// ==================== HELPER FUNCTIONS ====================

async function sendWithButtons(sock, from, text, quotedMsg, buttons) {
    const buttonOptions = {
        title: '𝐌𝐄𝐆𝐀𝐍-𝐌𝐃',
        text: text,
        footer: '> created by wanga',
        buttons: buttons || [
            {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                    display_text: '📢 Join Channel',
                    url: CHANNEL_LINK
                })
            }
        ]
    };
    
    if (buttons) {
        await buttons.send(from, buttonOptions, quotedMsg);
    } else {
        await sock.sendMessage(from, { text: text }, { quoted: quotedMsg });
    }
}

async function downloadFile(url, filename) {
    const filePath = path.join(TEMP_DIR, filename);
    
    const response = await axios({
        method: 'GET',
        url: url,
        responseType: 'stream',
        headers: { 'User-Agent': 'Mozilla/5.0' },
        timeout: 300000
    });

    return new Promise((resolve, reject) => {
        const writer = fs.createWriteStream(filePath);
        response.data.pipe(writer);
        writer.on('finish', () => resolve(filePath));
        writer.on('error', reject);
    });
}

async function tryDownload(urls, filename) {
    for (let i = 0; i < urls.length; i++) {
        try {
            const url = urls[i];
            if (!url) continue;
            const filePath = await downloadFile(url, filename);
            return filePath;
        } catch (error) {
            console.log(`Download attempt ${i+1} failed: ${error.message}`);
            if (i === urls.length - 1) throw error;
        }
    }
    throw new Error('All download attempts failed');
}

function cleanFilename(filename) {
    return filename.replace(/[^\w\s.-]/gi, '').substring(0, 50);
}

function formatDuration(seconds) {
    if (!seconds) return 'N/A';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function formatNumber(num) {
    if (!num) return 'N/A';
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
}

function getThumbnailUrl(videoId, quality = 'high') {
    const qualities = {
        'default': 'default.jpg',
        'medium': 'mqdefault.jpg',
        'high': 'hqdefault.jpg',
        'standard': 'sddefault.jpg',
        'maxres': 'maxresdefault.jpg'
    };
    return `https://img.youtube.com/vi/${videoId}/${qualities[quality] || qualities.high}`;
}

function extractVideoId(url) {
    const match = url.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/);
    return match ? match[1] : null;
}

function extractSpotifyId(url) {
    const match = url.match(/track\/([a-zA-Z0-9]+)/);
    return match ? match[1] : null;
}

async function sendMedia(sock, from, buffer, filename, caption, quoted, buttons, isAudio = true, isVideo = false) {
    const stats = { size: buffer.length };
    const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
    
    if (parseFloat(fileSizeMB) > 50) {
        await sock.sendMessage(from, {
            document: buffer,
            fileName: filename,
            mimetype: isAudio ? 'audio/mpeg' : (isVideo ? 'video/mp4' : 'application/octet-stream'),
            caption: `📁 *Large File*\n📄 ${filename}\n💾 ${fileSizeMB} MB\n\n${caption}`
        }, { quoted });
    } else if (isVideo) {
        await sock.sendMessage(from, {
            video: buffer,
            caption: caption
        }, { quoted });
    } else if (isAudio) {
        await sock.sendMessage(from, {
            audio: buffer,
            mimetype: 'audio/mpeg',
            ptt: false,
            fileName: filename
        }, { quoted });
    } else {
        await sock.sendMessage(from, {
            image: buffer,
            caption: caption
        }, { quoted });
    }
    
    await sendWithButtons(sock, from, caption, quoted, buttons);
}

// ==================== YOUTUBE DOWNLOADERS ====================

// 1. PLAY - XWolf API
commands.push({
    name: 'play',
    description: 'Search and download audio (XWolf)',
    aliases: ['song'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `🎵 *𝐏𝐋𝐀𝐘 (XWolf)*\n\n*Usage:* ${config.PREFIX}play <song name>\n*Example:* ${config.PREFIX}play Maintain by ssaru\n\n> created by wanga`, 
                msg, buttons);
        }

        const query = args.join(' ');
        let tempFile = null;
        
        await react('🔍');
        await sendWithButtons(sock, from, `🔍 *Searching:* "${query}"...`, msg, buttons);

        try {
            const search = await yts(query);
            const videos = search.videos.slice(0, 5);
            if (videos.length === 0) throw new Error('No results found');

            const video = videos[0];
            const videoId = video.videoId;
            const title = video.title;
            const duration = video.timestamp || formatDuration(video.duration);
            const thumbnailUrl = getThumbnailUrl(videoId, 'high');
            
            await sock.sendMessage(from, {
                image: { url: thumbnailUrl },
                caption: `🎵 *${title}*\n⏱️ ${duration}\n👤 ${video.author?.name || 'Unknown'}\n\n⬇️ *Downloading...*`
            }, { quoted: msg });

            const youtubeUrl = `https://www.youtube.com/watch?v=${videoId}`;
            let downloadUrl = null;
            let usedApi = 'dlmp3';
            
            try {
                const response = await axios.get(`https://apis.xwolf.space/download/dlmp3`, {
                    params: { url: youtubeUrl },
                    timeout: 20000
                });
                if (response.data?.success && response.data?.downloadUrl) downloadUrl = response.data.downloadUrl;
            } catch (e) { console.log('dlmp3 failed'); }
            
            if (!downloadUrl) {
                try {
                    const response = await axios.get(`https://apis.xwolf.space/download/audio`, {
                        params: { url: youtubeUrl },
                        timeout: 20000
                    });
                    if (response.data?.success && response.data?.downloadUrl) {
                        downloadUrl = response.data.downloadUrl;
                        usedApi = 'audio';
                    }
                } catch (e) { console.log('audio failed'); }
            }
            
            if (!downloadUrl) throw new Error('All download attempts failed');

            const filename = `play_${Date.now()}.mp3`;
            tempFile = await downloadFile(downloadUrl, filename);
            const buffer = await fs.readFile(tempFile);
            
            await sendMedia(sock, from, buffer, cleanFilename(title) + '.mp3', 
                `🎵 *${title}*\n📡 Source: XWolf (${usedApi})\n\n> created by wanga`, msg, buttons);

            await react('✅');
        } catch (error) {
            bot.logger.error('Play error:', error);
            await react('❌');
            await sendWithButtons(sock, from, 
                `❌ *Download failed*\n\nTry: ${config.PREFIX}play2 "${query}"\n\n> created by wanga`, msg, buttons);
        } finally {
            if (tempFile && await fs.pathExists(tempFile)) await fs.unlink(tempFile).catch(() => {});
        }
    }
});

// 2. PLAY2 - Aswin Sparky API
commands.push({
    name: 'play2',
    description: 'Search and download audio (Aswin Sparky)',
    aliases: ['song2'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `🎵 *𝐏𝐋𝐀𝐘𝟐 (Aswin Sparky)*\n\n*Usage:* ${config.PREFIX}play2 <song name>\n\n> created by wanga`, msg, buttons);
        }

        const query = args.join(' ');
        let tempFile = null;
        
        await react('🔍');
        await sendWithButtons(sock, from, `🔍 *Searching:* "${query}"...`, msg, buttons);

        try {
            const search = await yts(query);
            const videos = search.videos.slice(0, 5);
            if (videos.length === 0) throw new Error('No results found');

            const video = videos[0];
            const videoId = video.videoId;
            const title = video.title;
            const thumbnailUrl = getThumbnailUrl(videoId, 'high');
            
            await sock.sendMessage(from, {
                image: { url: thumbnailUrl },
                caption: `🎵 *${title}*\n\n⬇️ *Downloading via Aswin...*`
            }, { quoted: msg });

            const youtubeUrl = `https://youtu.be/${videoId}`;
            let downloadUrl = null;
            
            try {
                const response = await axios.get(`https://api-aswin-sparky.koyeb.app/api/downloader/song`, {
                    params: { search: youtubeUrl },
                    timeout: 30000
                });
                if (response.data?.status && response.data?.data?.url) downloadUrl = response.data.data.url;
            } catch (e) { console.log('Aswin failed'); }
            
            if (!downloadUrl) {
                try {
                    const response = await axios.get(`https://apis.xwolf.space/download/dlmp3`, {
                        params: { url: `https://www.youtube.com/watch?v=${videoId}` },
                        timeout: 20000
                    });
                    if (response.data?.success && response.data?.downloadUrl) downloadUrl = response.data.downloadUrl;
                } catch (e) { console.log('XWolf fallback failed'); }
            }
            
            if (!downloadUrl) throw new Error('All download attempts failed');

            const filename = `play2_${Date.now()}.mp3`;
            tempFile = await downloadFile(downloadUrl, filename);
            const buffer = await fs.readFile(tempFile);
            
            await sendMedia(sock, from, buffer, cleanFilename(title) + '.mp3', 
                `🎵 *${title}*\n📡 Source: Aswin Sparky\n\n> created by wanga`, msg, buttons);
            await react('✅');
        } catch (error) {
            bot.logger.error('Play2 error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Download failed*\n\nTry: ${config.PREFIX}play "${query}"\n\n> created by wanga`, msg, buttons);
        } finally {
            if (tempFile && await fs.pathExists(tempFile)) await fs.unlink(tempFile).catch(() => {});
        }
    }
});

// 3. PLAY3 - List and Select
commands.push({
    name: 'play3',
    description: 'Search, select and download audio',
    aliases: ['song3', 'select'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `🎵 *𝐏𝐋𝐀𝐘𝟑 (Select & Download)*\n\n*Usage:* ${config.PREFIX}play3 <song name>\nThen reply with number 1-10\n\n> created by wanga`, msg, buttons);
        }

        const query = args.join(' ');
        await react('🔍');
        
        try {
            const search = await yts(query);
            const videos = search.videos.slice(0, 10);
            if (videos.length === 0) throw new Error('No results found');

            let listText = `🎵 *𝐒𝐄𝐀𝐑𝐂𝐇 𝐑𝐄𝐒𝐔𝐋𝐓𝐒*\n\n*Query:* "${query}"\n\n`;
            videos.forEach((video, i) => {
                listText += `*${i+1}.* ${video.title}\n`;
                listText += `   ⏱️ ${video.timestamp || formatDuration(video.duration)} | 👁️ ${formatNumber(video.views)}\n\n`;
            });
            listText += `*Reply with number (1-${videos.length}) to download*\n\n> created by wanga`;
            
            if (!global.downloaderSearches) global.downloaderSearches = {};
            global.downloaderSearches[from] = { videos: videos, timestamp: Date.now() };
            
            await sock.sendMessage(from, { text: listText }, { quoted: msg });
            await react('✅');
        } catch (error) {
            bot.logger.error('Play3 search error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Search failed*\n\n> created by wanga`, msg, buttons);
        }
    }
});

// 4. SELECT - Download from play3 results
commands.push({
    name: 'select',
    description: 'Select a song from search results',
    aliases: ['sel'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length || isNaN(parseInt(args[0]))) {
            return reply(`📌 *Select Song*\n\nUsage: ${config.PREFIX}select <number>\n\n> created by wanga`);
        }
        
        const selection = parseInt(args[0]);
        if (!global.downloaderSearches || !global.downloaderSearches[from]) {
            return reply(`❌ No recent search. Use ${config.PREFIX}play3 first.\n\n> created by wanga`);
        }
        
        const searchData = global.downloaderSearches[from];
        if (Date.now() - searchData.timestamp > 300000) {
            delete global.downloaderSearches[from];
            return reply(`❌ Search expired. Use ${config.PREFIX}play3 again.\n\n> created by wanga`);
        }
        
        const videos = searchData.videos;
        if (selection > videos.length) {
            return reply(`❌ Choose 1-${videos.length}\n\n> created by wanga`);
        }
        
        const video = videos[selection - 1];
        const videoId = video.videoId;
        const title = video.title;
        let tempFile = null;
        
        await react('🎵');
        
        try {
            const thumbnailUrl = getThumbnailUrl(videoId, 'high');
            await sock.sendMessage(from, { image: { url: thumbnailUrl }, caption: `🎵 *${title}*\n\n⬇️ *Downloading...*` }, { quoted: msg });
            
            let downloadUrl = null;
            let usedApi = '';
            
            try {
                const response = await axios.get(`https://apis.xwolf.space/download/dlmp3`, {
                    params: { url: `https://www.youtube.com/watch?v=${videoId}` },
                    timeout: 20000
                });
                if (response.data?.success && response.data?.downloadUrl) {
                    downloadUrl = response.data.downloadUrl;
                    usedApi = 'XWolf dlmp3';
                }
            } catch (e) {}
            
            if (!downloadUrl) {
                try {
                    const response = await axios.get(`https://apis.xwolf.space/download/audio`, {
                        params: { url: `https://www.youtube.com/watch?v=${videoId}` },
                        timeout: 20000
                    });
                    if (response.data?.success && response.data?.downloadUrl) {
                        downloadUrl = response.data.downloadUrl;
                        usedApi = 'XWolf audio';
                    }
                } catch (e) {}
            }
            
            if (!downloadUrl) {
                try {
                    const response = await axios.get(`https://api-aswin-sparky.koyeb.app/api/downloader/song`, {
                        params: { search: `https://youtu.be/${videoId}` },
                        timeout: 30000
                    });
                    if (response.data?.status && response.data?.data?.url) {
                        downloadUrl = response.data.data.url;
                        usedApi = 'Aswin Sparky';
                    }
                } catch (e) {}
            }
            
            if (!downloadUrl) throw new Error('All download APIs failed');

            const filename = `select_${Date.now()}.mp3`;
            tempFile = await downloadFile(downloadUrl, filename);
            const buffer = await fs.readFile(tempFile);
            
            await sendMedia(sock, from, buffer, cleanFilename(title) + '.mp3', 
                `🎵 *${title}*\n📡 Source: ${usedApi}\n\n> created by wanga`, msg, buttons);
            await react('✅');
            
            delete global.downloaderSearches[from];
        } catch (error) {
            bot.logger.error('Select error:', error);
            await react('❌');
            await reply(`❌ *Download failed*\n\nTry: ${config.PREFIX}play "${title}"\n\n> created by wanga`);
        } finally {
            if (tempFile && await fs.pathExists(tempFile)) await fs.unlink(tempFile).catch(() => {});
        }
    }
});

// 5. PLAY4 - Direct URL Download
commands.push({
    name: 'play4',
    description: 'Download audio from YouTube URL',
    aliases: ['song4', 'url'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `🎵 *𝐏𝐋𝐀𝐘𝟒 (URL Download)*\n\n*Usage:* ${config.PREFIX}play4 <YouTube URL>\n\n> created by wanga`, msg, buttons);
        }

        const url = args[0];
        let tempFile = null;
        
        await react('🔗');
        
        try {
            if (!url.includes('youtube.com') && !url.includes('youtu.be')) throw new Error('Invalid YouTube URL');
            
            const videoId = extractVideoId(url);
            if (!videoId) throw new Error('Could not extract video ID');
            
            const videoInfo = await yts({ videoId });
            const title = videoInfo.videos[0]?.title || 'Unknown';
            const thumbnailUrl = getThumbnailUrl(videoId, 'high');
            
            await sock.sendMessage(from, { image: { url: thumbnailUrl }, caption: `🎵 *${title}*\n\n⬇️ *Downloading...*` }, { quoted: msg });
            
            let downloadUrl = null;
            let usedApi = '';
            
            try {
                const response = await axios.get(`https://apis.xwolf.space/download/dlmp3`, {
                    params: { url: `https://www.youtube.com/watch?v=${videoId}` },
                    timeout: 20000
                });
                if (response.data?.success && response.data?.downloadUrl) {
                    downloadUrl = response.data.downloadUrl;
                    usedApi = 'XWolf dlmp3';
                }
            } catch (e) {}
            
            if (!downloadUrl) {
                try {
                    const response = await axios.get(`https://apis.xwolf.space/download/audio`, {
                        params: { url: `https://www.youtube.com/watch?v=${videoId}` },
                        timeout: 20000
                    });
                    if (response.data?.success && response.data?.downloadUrl) {
                        downloadUrl = response.data.downloadUrl;
                        usedApi = 'XWolf audio';
                    }
                } catch (e) {}
            }
            
            if (!downloadUrl) {
                try {
                    const response = await axios.get(`https://api-aswin-sparky.koyeb.app/api/downloader/song`, {
                        params: { search: `https://youtu.be/${videoId}` },
                        timeout: 30000
                    });
                    if (response.data?.status && response.data?.data?.url) {
                        downloadUrl = response.data.data.url;
                        usedApi = 'Aswin Sparky';
                    }
                } catch (e) {}
            }
            
            if (!downloadUrl) throw new Error('All download APIs failed');

            const filename = `play4_${Date.now()}.mp3`;
            tempFile = await downloadFile(downloadUrl, filename);
            const buffer = await fs.readFile(tempFile);
            
            await sendMedia(sock, from, buffer, cleanFilename(title) + '.mp3', 
                `🎵 *${title}*\n📡 Source: ${usedApi}\n\n> created by wanga`, msg, buttons);
            await react('✅');
        } catch (error) {
            bot.logger.error('Play4 error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Download failed*\n\nCheck URL and try again.\n\n> created by wanga`, msg, buttons);
        } finally {
            if (tempFile && await fs.pathExists(tempFile)) await fs.unlink(tempFile).catch(() => {});
        }
    }
});

// ==================== SPOTIFY DOWNLOADERS ====================

// 6. SPOTIFY SEARCH
commands.push({
    name: 'spotifysearch',
    description: 'Search for Spotify tracks',
    aliases: ['spsearch'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `🎵 *𝐒𝐏𝐎𝐓𝐈𝐅𝐘 𝐒𝐄𝐀𝐑𝐂𝐇*\n\n*Usage:* ${config.PREFIX}spotifysearch <song name>\n\n> created by wanga`, msg, buttons);
        }

        const query = args.join(' ');
        await react('🔍');
        
        try {
            const response = await axios.get(`https://apis.xwolf.space/api/spotify/search`, {
                params: { q: query },
                timeout: 15000
            });

            if (!response.data?.success || !response.data.tracks?.length) throw new Error('No tracks found');

            const tracks = response.data.tracks.slice(0, 10);
            
            let listText = `🎵 *𝐒𝐏𝐎𝐓𝐈𝐅𝐘 𝐑𝐄𝐒𝐔𝐋𝐓𝐒*\n\n*Query:* "${query}"\n\n`;
            tracks.forEach((track, i) => {
                listText += `*${i+1}.* ${track.title}\n`;
                listText += `   👤 ${track.artist}\n`;
                listText += `   💿 ${track.album}\n`;
                listText += `   🔗 Use: ${config.PREFIX}spotifydl ${i+1}\n\n`;
            });
            listText += `> created by wanga`;
            
            if (!global.spotifySearches) global.spotifySearches = {};
            global.spotifySearches[from] = { tracks: tracks, timestamp: Date.now() };
            
            await sock.sendMessage(from, { text: listText }, { quoted: msg });
            await react('✅');
        } catch (error) {
            bot.logger.error('Spotify search error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Search failed*\n\n> created by wanga`, msg, buttons);
        }
    }
});

// 7. SPOTIFY DOWNLOAD
commands.push({
    name: 'spotifydl',
    description: 'Download Spotify track',
    aliases: ['spdl', 'sdd'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `🎵 *𝐒𝐏𝐎𝐓𝐈𝐅𝐘 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃*\n\n*Usage:* ${config.PREFIX}spotifydl <number> (after search)\nOr: ${config.PREFIX}spotifydl <URL>\n\n> created by wanga`, msg, buttons);
        }

        let query = args.join(' ');
        let tempFile = null;
        
        await react('🎵');
        
        try {
            // Check if selection from search
            if (global.spotifySearches && global.spotifySearches[from]) {
                const selection = parseInt(args[0]);
                if (!isNaN(selection) && selection > 0 && selection <= global.spotifySearches[from].tracks.length) {
                    const track = global.spotifySearches[from].tracks[selection - 1];
                    query = track.title + ' ' + track.artist;
                    await sock.sendMessage(from, { text: `✅ Selected: *${track.title}*\n\n⬇️ *Downloading...*` }, { quoted: msg });
                }
            }

            const isUrl = query.includes('spotify.com') || query.includes('open.spotify');
            let response;
            
            if (isUrl) {
                const trackId = extractSpotifyId(query);
                if (!trackId) throw new Error('Invalid Spotify URL');
                response = await axios.get(`https://apis.xwolf.space/api/spotify/download`, {
                    params: { id: trackId },
                    timeout: 30000
                });
            } else {
                response = await axios.get(`https://apis.xwolf.space/api/spotify/download`, {
                    params: { q: query },
                    timeout: 30000
                });
            }

            if (!response.data?.success) throw new Error('Download failed');

            const data = response.data;
            
            if (data.albumArt) {
                await sock.sendMessage(from, {
                    image: { url: data.albumArt },
                    caption: `🎵 *${data.title}*\n👤 ${data.artist}\n💿 ${data.album || 'Single'}\n\n⬇️ *Downloading...*`
                }, { quoted: msg });
            }

            const filename = `spotify_${Date.now()}.mp3`;
            tempFile = await downloadFile(data.downloadUrl, filename);
            const buffer = await fs.readFile(tempFile);
            
            await sendMedia(sock, from, buffer, cleanFilename(data.title) + '.mp3', 
                `🎵 *${data.title}*\n👤 ${data.artist}\n\n> created by wanga`, msg, buttons);

            if (global.spotifySearches && global.spotifySearches[from]) delete global.spotifySearches[from];
            await react('✅');
        } catch (error) {
            bot.logger.error('Spotify download error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Download failed*\n\nTry: ${config.PREFIX}spotifysearch first\n\n> created by wanga`, msg, buttons);
        } finally {
            if (tempFile && await fs.pathExists(tempFile)) await fs.unlink(tempFile).catch(() => {});
        }
    }
});

// 8. SPOTIFY DOCUMENT
commands.push({
    name: 'spotifydldoc',
    description: 'Download Spotify track as document',
    aliases: ['spdldoc', 'sddoc'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `📁 *𝐒𝐏𝐎𝐓𝐈𝐅𝐘 𝐃𝐎𝐂𝐔𝐌𝐄𝐍𝐓*\n\n*Usage:* ${config.PREFIX}spotifydldoc <song name or URL>\n\n> created by wanga`, msg, buttons);
        }

        const query = args.join(' ');
        let tempFile = null;
        
        await react('📁');
        
        try {
            const isUrl = query.includes('spotify.com') || query.includes('open.spotify');
            let response;
            
            if (isUrl) {
                const trackId = extractSpotifyId(query);
                if (!trackId) throw new Error('Invalid Spotify URL');
                response = await axios.get(`https://apis.xwolf.space/api/spotify/download`, {
                    params: { id: trackId },
                    timeout: 30000
                });
            } else {
                response = await axios.get(`https://apis.xwolf.space/api/spotify/download`, {
                    params: { q: query },
                    timeout: 30000
                });
            }

            if (!response.data?.success) throw new Error('Download failed');

            const data = response.data;
            
            if (data.albumArt) {
                await sock.sendMessage(from, {
                    image: { url: data.albumArt },
                    caption: `📁 *${data.title}*\n👤 ${data.artist}\n\n⬇️ *Downloading as document...*`
                }, { quoted: msg });
            }

            const filename = `spotifydoc_${Date.now()}.mp3`;
            tempFile = await downloadFile(data.downloadUrl, filename);
            const buffer = await fs.readFile(tempFile);
            const stats = await fs.stat(tempFile);
            const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
            
            await sock.sendMessage(from, {
                document: buffer,
                fileName: cleanFilename(data.title) + '.mp3',
                mimetype: 'audio/mpeg',
                caption: `📁 *Spotify Document*\n🎵 ${data.title}\n👤 ${data.artist}\n💾 ${fileSizeMB} MB\n\n> created by wanga`
            }, { quoted: msg });
            
            await sendWithButtons(sock, from, `✅ *Downloaded successfully*`, msg, buttons);
            await react('✅');
        } catch (error) {
            bot.logger.error('Spotify doc error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Download failed*\n\n> created by wanga`, msg, buttons);
        } finally {
            if (tempFile && await fs.pathExists(tempFile)) await fs.unlink(tempFile).catch(() => {});
        }
    }
});

// ==================== SOUNDCLOUD DOWNLOADERS ====================

// 9. SOUNDCLOUD SEARCH
commands.push({
    name: 'soundcloudsearch',
    description: 'Search for SoundCloud tracks',
    aliases: ['scsearch'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `🎧 *𝐒𝐎𝐔𝐍𝐃𝐂𝐋𝐎𝐔𝐃 𝐒𝐄𝐀𝐑𝐂𝐇*\n\n*Usage:* ${config.PREFIX}soundcloudsearch <query>\n\n> created by wanga`, msg, buttons);
        }

        const query = args.join(' ');
        await react('🔍');
        
        try {
            const response = await axios.get(`https://api.siputzx.my.id/api/s/soundcloud`, {
                params: { query: query },
                timeout: 15000
            });

            if (!response.data?.status || !response.data.data?.length) throw new Error('No tracks found');

            const tracks = response.data.data.filter(t => t.permalink_url).slice(0, 10);
            
            let listText = `🎧 *𝐒𝐎𝐔𝐍𝐃𝐂𝐋𝐎𝐔𝐃 𝐑𝐄𝐒𝐔𝐋𝐓𝐒*\n\n*Query:* "${query}"\n\n`;
            tracks.forEach((track, i) => {
                listText += `*${i+1}.* ${track.permalink || 'Unknown'}\n`;
                if (track.duration) listText += `   ⏱️ ${formatDuration(track.duration / 1000)}\n`;
                listText += `   🔗 Use: ${config.PREFIX}soundcloud ${i+1}\n\n`;
            });
            listText += `> created by wanga`;
            
            if (!global.soundcloudSearches) global.soundcloudSearches = {};
            global.soundcloudSearches[from] = { tracks: tracks, timestamp: Date.now() };
            
            await sock.sendMessage(from, { text: listText }, { quoted: msg });
            await react('✅');
        } catch (error) {
            bot.logger.error('SoundCloud search error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Search failed*\n\n> created by wanga`, msg, buttons);
        }
    }
});

// 10. SOUNDCLOUD DOWNLOAD
commands.push({
    name: 'soundcloud',
    description: 'Download SoundCloud track',
    aliases: ['sc'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `🎧 *𝐒𝐎𝐔𝐍𝐃𝐂𝐋𝐎𝐔𝐃*\n\n*Usage:* ${config.PREFIX}soundcloud <URL or number>\n\n> created by wanga`, msg, buttons);
        }

        let url = args[0];
        let tempFile = null;
        
        await react('🎧');
        
        try {
            // Check if selection from search
            if (global.soundcloudSearches && global.soundcloudSearches[from]) {
                const selection = parseInt(args[0]);
                if (!isNaN(selection) && selection > 0 && selection <= global.soundcloudSearches[from].tracks.length) {
                    const track = global.soundcloudSearches[from].tracks[selection - 1];
                    url = track.permalink_url;
                    await sock.sendMessage(from, { text: `✅ Selected: *${track.permalink}*\n\n⬇️ *Downloading...*` }, { quoted: msg });
                }
            }

            const response = await axios.get(`https://api.siputzx.my.id/api/s/soundcloud`, {
                params: { url: url },
                timeout: 30000
            });

            if (!response.data?.status) throw new Error('Download failed');

            const data = response.data.data;
            
            if (data.thumbnail || data.artwork_url) {
                await sock.sendMessage(from, {
                    image: { url: data.thumbnail || data.artwork_url },
                    caption: `🎧 *${data.title || 'Track'}*\n👤 ${data.user || 'Unknown'}\n⏱️ ${formatDuration(data.duration)}\n\n⬇️ *Downloading...*`
                }, { quoted: msg });
            }

            const audioUrl = data.url || data.download?.url;
            if (!audioUrl) throw new Error('No audio URL found');

            const filename = `soundcloud_${Date.now()}.mp3`;
            tempFile = await downloadFile(audioUrl, filename);
            const buffer = await fs.readFile(tempFile);
            
            await sendMedia(sock, from, buffer, cleanFilename(data.title || 'soundcloud') + '.mp3', 
                `🎧 *${data.title || 'SoundCloud Track'}*\n👤 ${data.user || 'Unknown'}\n\n> created by wanga`, msg, buttons);

            if (global.soundcloudSearches && global.soundcloudSearches[from]) delete global.soundcloudSearches[from];
            await react('✅');
        } catch (error) {
            bot.logger.error('SoundCloud error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Download failed*\n\n> created by wanga`, msg, buttons);
        } finally {
            if (tempFile && await fs.pathExists(tempFile)) await fs.unlink(tempFile).catch(() => {});
        }
    }
});

// 11. SCDOC - SoundCloud as document
commands.push({
    name: 'scdoc',
    description: 'Download SoundCloud track as document',
    aliases: ['soundclouddoc'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `📁 *𝐒𝐎𝐔𝐍𝐃𝐂𝐋𝐎𝐔𝐃 𝐃𝐎𝐂𝐔𝐌𝐄𝐍𝐓*\n\n*Usage:* ${config.PREFIX}scdoc <URL>\n\n> created by wanga`, msg, buttons);
        }

        const url = args[0];
        let tempFile = null;
        
        await react('📁');
        
        try {
            const response = await axios.get(`https://api.siputzx.my.id/api/s/soundcloud`, {
                params: { url },
                timeout: 30000
            });

            if (!response.data?.status) throw new Error('Download failed');

            const data = response.data.data;
            
            if (data.thumbnail || data.artwork_url) {
                await sock.sendMessage(from, {
                    image: { url: data.thumbnail || data.artwork_url },
                    caption: `📁 *${data.title || 'Track'}*\n👤 ${data.user || 'Unknown'}\n\n⬇️ *Downloading as document...*`
                }, { quoted: msg });
            }

            const audioUrl = data.url || data.download?.url;
            if (!audioUrl) throw new Error('No audio URL found');

            const filename = `scdoc_${Date.now()}.mp3`;
            tempFile = await downloadFile(audioUrl, filename);
            const buffer = await fs.readFile(tempFile);
            const stats = await fs.stat(tempFile);
            const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
            
            await sock.sendMessage(from, {
                document: buffer,
                fileName: cleanFilename(data.title || 'soundcloud') + '.mp3',
                mimetype: 'audio/mpeg',
                caption: `📁 *SoundCloud Document*\n🎧 ${data.title || 'Track'}\n👤 ${data.user || 'Unknown'}\n💾 ${fileSizeMB} MB\n\n> created by wanga`
            }, { quoted: msg });
            
            await sendWithButtons(sock, from, `✅ *Downloaded successfully*`, msg, buttons);
            await react('✅');
        } catch (error) {
            bot.logger.error('SCDoc error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Download failed*\n\n> created by wanga`, msg, buttons);
        } finally {
            if (tempFile && await fs.pathExists(tempFile)) await fs.unlink(tempFile).catch(() => {});
        }
    }
});

// ==================== SOCIAL MEDIA DOWNLOADERS ====================

// 12. TIKTOK DOWNLOAD
commands.push({
    name: 'tiktokdl',
    description: 'Download TikTok video',
    aliases: ['ttdl'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `📱 *𝐓𝐈𝐊𝐓𝐎𝐊 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃*\n\n*Usage:* ${config.PREFIX}tiktokdl <URL>\n\n> created by wanga`, msg, buttons);
        }

        const url = args[0];
        let tempFile = null;
        
        await react('📱');
        
        try {
            const response = await axios.get(`https://api.siputzx.my.id/api/d/tiktok/v2`, {
                params: { url },
                timeout: 30000
            });

            if (!response.data?.status) throw new Error('Download failed');

            const data = response.data.data;
            const authorName = data.author?.nickname || 'Unknown';

            if (data.thumbnail) {
                await sock.sendMessage(from, {
                    image: { url: data.thumbnail },
                    caption: `📱 *TikTok Video*\n📝 ${data.title || 'No caption'}\n👤 ${authorName}\n\n⬇️ *Downloading...*`
                }, { quoted: msg });
            }

            const videoUrls = [data.video, data.download?.url, data.url].filter(Boolean);
            const filename = `tiktok_${Date.now()}.mp4`;
            tempFile = await tryDownload(videoUrls, filename);
            const buffer = await fs.readFile(tempFile);
            
            await sendMedia(sock, from, buffer, `tiktok_${Date.now()}.mp4`, 
                `📱 *TikTok Video*\n📝 ${data.title || 'No caption'}\n👤 ${authorName}\n\n> created by wanga`, msg, buttons, false, true);
            await react('✅');
        } catch (error) {
            bot.logger.error('TikTok error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Download failed*\n\n> created by wanga`, msg, buttons);
        } finally {
            if (tempFile && await fs.pathExists(tempFile)) await fs.unlink(tempFile).catch(() => {});
        }
    }
});

// 13. INSTAGRAM DOWNLOAD
commands.push({
    name: 'instagramdl',
    description: 'Download Instagram post/reel',
    aliases: ['igdl', 'igreelsdl'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `📸 *𝐈𝐍𝐒𝐓𝐀𝐆𝐑𝐀𝐌 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃*\n\n*Usage:* ${config.PREFIX}instagramdl <URL>\n\n> created by wanga`, msg, buttons);
        }

        const url = args[0];
        let tempFile = null;
        
        await react('📸');
        
        try {
            let response;
            try {
                response = await axios.get(`https://api.siputzx.my.id/api/d/instagram`, {
                    params: { url },
                    timeout: 30000
                });
            } catch (e) {
                response = await axios.get(`https://api.siputzx.my.id/api/sssinstagram`, {
                    params: { url },
                    timeout: 30000
                });
            }

            if (!response.data?.status) throw new Error('Download failed');

            const data = response.data.data;
            const mediaUrls = [data.video, data.url, data.download?.url, data.image].filter(Boolean);
            const thumbnail = data.thumbnail || data.thumb || data.image;
            const caption = data.caption || data.title || 'Instagram post';

            if (thumbnail) {
                await sock.sendMessage(from, {
                    image: { url: thumbnail },
                    caption: `📸 *Instagram Post*\n📝 ${caption}\n\n⬇️ *Downloading...*`
                }, { quoted: msg });
            }

            if (!mediaUrls.length) throw new Error('No media URL found');

            const isVideo = mediaUrls[0].includes('.mp4') || mediaUrls[0].includes('.mov');
            const ext = isVideo ? 'mp4' : 'jpg';
            const filename = `instagram_${Date.now()}.${ext}`;
            tempFile = await tryDownload(mediaUrls, filename);
            const buffer = await fs.readFile(tempFile);

            if (isVideo) {
                await sendMedia(sock, from, buffer, `instagram_${Date.now()}.mp4`, 
                    `📸 *Instagram ${caption.includes('reel') ? 'Reel' : 'Post'}*\n\n> created by wanga`, msg, buttons, false, true);
            } else {
                await sock.sendMessage(from, {
                    image: buffer,
                    caption: `📸 *Instagram Post*\n\n> created by wanga`
                }, { quoted: msg });
            }
            await react('✅');
        } catch (error) {
            bot.logger.error('Instagram error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Download failed*\n\n> created by wanga`, msg, buttons);
        } finally {
            if (tempFile && await fs.pathExists(tempFile)) await fs.unlink(tempFile).catch(() => {});
        }
    }
});

// 14. FACEBOOK DOWNLOAD
commands.push({
    name: 'facebookdl',
    description: 'Download Facebook video',
    aliases: ['fbdl'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `📘 *𝐅𝐀𝐂𝐄𝐁𝐎𝐎𝐊 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃*\n\n*Usage:* ${config.PREFIX}facebookdl <URL>\n\n> created by wanga`, msg, buttons);
        }

        const url = args[0];
        let tempFile = null;
        
        await react('📘');
        
        try {
            const response = await axios.get(`https://api.siputzx.my.id/api/d/facebook`, {
                params: { url },
                timeout: 30000
            });

            if (!response.data?.status) throw new Error('Download failed');

            const data = response.data.data;
            
            if (data.thumbnail) {
                await sock.sendMessage(from, {
                    image: { url: data.thumbnail },
                    caption: `📘 *Facebook Video*\n📹 ${data.title || 'Video'}\n\n⬇️ *Downloading...*`
                }, { quoted: msg });
            }

            const downloads = data.downloads || [];
            const videoUrls = downloads.map(d => d.url).filter(Boolean);
            if (data.url) videoUrls.push(data.url);

            if (!videoUrls.length) throw new Error('No video URL found');

            const filename = `facebook_${Date.now()}.mp4`;
            tempFile = await tryDownload(videoUrls, filename);
            const buffer = await fs.readFile(tempFile);
            
            await sendMedia(sock, from, buffer, `facebook_${Date.now()}.mp4`, 
                `📘 *Facebook Video*\n📹 ${data.title || 'Video'}\n\n> created by wanga`, msg, buttons, false, true);
            await react('✅');
        } catch (error) {
            bot.logger.error('Facebook error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Download failed*\n\n> created by wanga`, msg, buttons);
        } finally {
            if (tempFile && await fs.pathExists(tempFile)) await fs.unlink(tempFile).catch(() => {});
        }
    }
});

// 15. TWITTER DOWNLOAD
commands.push({
    name: 'twitterdl',
    description: 'Download Twitter/X video',
    aliases: ['xdl'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `🐦 *𝐓𝐖𝐈𝐓𝐓𝐄𝐑 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃*\n\n*Usage:* ${config.PREFIX}twitterdl <URL>\n\n> created by wanga`, msg, buttons);
        }

        const url = args[0];
        let tempFile = null;
        
        await react('🐦');
        
        try {
            const response = await axios.get(`https://api.siputzx.my.id/api/d/twitter`, {
                params: { url },
                timeout: 30000
            });

            if (!response.data?.status) throw new Error('Download failed');

            const data = response.data.data;
            
            if (data.thumbnail) {
                await sock.sendMessage(from, {
                    image: { url: data.thumbnail },
                    caption: `🐦 *Twitter Video*\n\n⬇️ *Downloading...*`
                }, { quoted: msg });
            }

            const videoUrls = [data.video, data.url, data.download?.url].filter(Boolean);
            if (!videoUrls.length) throw new Error('No video URL found');

            const filename = `twitter_${Date.now()}.mp4`;
            tempFile = await tryDownload(videoUrls, filename);
            const buffer = await fs.readFile(tempFile);
            
            await sendMedia(sock, from, buffer, `twitter_${Date.now()}.mp4`, 
                `🐦 *Twitter Video*\n\n> created by wanga`, msg, buttons, false, true);
            await react('✅');
        } catch (error) {
            bot.logger.error('Twitter error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Download failed*\n\n> created by wanga`, msg, buttons);
        } finally {
            if (tempFile && await fs.pathExists(tempFile)) await fs.unlink(tempFile).catch(() => {});
        }
    }
});

// 16. THREADS DOWNLOAD
commands.push({
    name: 'threadsdl',
    description: 'Download Threads post',
    aliases: ['tdl'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `🧵 *𝐓𝐇𝐑𝐄𝐀𝐃𝐒 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃*\n\n*Usage:* ${config.PREFIX}threadsdl <URL>\n\n> created by wanga`, msg, buttons);
        }

        const url = args[0];
        let tempFile = null;
        
        await react('🧵');
        
        try {
            const response = await axios.get(`https://api.siputzx.my.id/api/d/threads`, {
                params: { url },
                timeout: 30000
            });

            if (!response.data?.status) throw new Error('Download failed');

            const data = response.data.data;
            
            if (data.thumbnail) {
                await sock.sendMessage(from, {
                    image: { url: data.thumbnail },
                    caption: `🧵 *Threads Post*\n\n⬇️ *Downloading...*`
                }, { quoted: msg });
            }

            const mediaUrls = [data.video, data.url, data.download?.url].filter(Boolean);
            if (!mediaUrls.length) throw new Error('No media URL found');

            const filename = `threads_${Date.now()}.mp4`;
            tempFile = await tryDownload(mediaUrls, filename);
            const buffer = await fs.readFile(tempFile);
            
            await sendMedia(sock, from, buffer, `threads_${Date.now()}.mp4`, 
                `🧵 *Threads Post*\n\n> created by wanga`, msg, buttons, false, true);
            await react('✅');
        } catch (error) {
            bot.logger.error('Threads error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Download failed*\n\n> created by wanga`, msg, buttons);
        } finally {
            if (tempFile && await fs.pathExists(tempFile)) await fs.unlink(tempFile).catch(() => {});
        }
    }
});

// 17. DOUYIN DOWNLOAD
commands.push({
    name: 'douyindl',
    description: 'Download Douyin video',
    aliases: ['dydl'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `🎵 *𝐃𝐎𝐔𝐘𝐈𝐍 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃*\n\n*Usage:* ${config.PREFIX}douyindl <URL>\n\n> created by wanga`, msg, buttons);
        }

        const url = args[0];
        let tempFile = null;
        
        await react('🎵');
        
        try {
            const response = await axios.get(`https://api.siputzx.my.id/api/d/douyin`, {
                params: { url },
                timeout: 30000
            });

            if (!response.data?.status) throw new Error('Download failed');

            const data = response.data.data;
            
            if (data.thumbnail) {
                await sock.sendMessage(from, {
                    image: { url: data.thumbnail },
                    caption: `🎵 *Douyin Video*\n📝 ${data.title || 'Video'}\n👤 ${data.author || 'Unknown'}\n\n⬇️ *Downloading...*`
                }, { quoted: msg });
            }

            const videoUrls = [data.video, data.url, data.download?.url].filter(Boolean);
            if (!videoUrls.length) throw new Error('No video URL found');

            const filename = `douyin_${Date.now()}.mp4`;
            tempFile = await tryDownload(videoUrls, filename);
            const buffer = await fs.readFile(tempFile);
            
            await sendMedia(sock, from, buffer, `douyin_${Date.now()}.mp4`, 
                `🎵 *Douyin Video*\n📝 ${data.title || 'Video'}\n👤 ${data.author || 'Unknown'}\n\n> created by wanga`, msg, buttons, false, true);
            await react('✅');
        } catch (error) {
            bot.logger.error('Douyin error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Download failed*\n\n> created by wanga`, msg, buttons);
        } finally {
            if (tempFile && await fs.pathExists(tempFile)) await fs.unlink(tempFile).catch(() => {});
        }
    }
});

// 18. LAHELU DOWNLOAD
commands.push({
    name: 'laheludl',
    description: 'Download Lahelu meme/video',
    aliases: ['lhdl'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `😂 *𝐋𝐀𝐇𝐄𝐋𝐔 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃*\n\n*Usage:* ${config.PREFIX}laheludl <URL>\n\n> created by wanga`, msg, buttons);
        }

        const url = args[0];
        let tempFile = null;
        
        await react('😂');
        
        try {
            const response = await axios.get(`https://api.siputzx.my.id/api/d/lahelu`, {
                params: { url },
                timeout: 30000
            });

            if (!response.data?.status) throw new Error('Download failed');

            const data = response.data.data;
            
            if (data.thumbnail) {
                await sock.sendMessage(from, {
                    image: { url: data.thumbnail },
                    caption: `😂 *Lahelu Post*\n\n⬇️ *Downloading...*`
                }, { quoted: msg });
            }

            const mediaUrls = [data.video, data.url, data.download?.url].filter(Boolean);
            if (!mediaUrls.length) throw new Error('No media URL found');

            const filename = `lahelu_${Date.now()}.mp4`;
            tempFile = await tryDownload(mediaUrls, filename);
            const buffer = await fs.readFile(tempFile);
            
            await sendMedia(sock, from, buffer, `lahelu_${Date.now()}.mp4`, 
                `😂 *Lahelu Video*\n\n> created by wanga`, msg, buttons, false, true);
            await react('✅');
        } catch (error) {
            bot.logger.error('Lahelu error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Download failed*\n\n> created by wanga`, msg, buttons);
        } finally {
            if (tempFile && await fs.pathExists(tempFile)) await fs.unlink(tempFile).catch(() => {});
        }
    }
});

// 19. SNAPCHAT PROFILE
commands.push({
    name: 'snapchatdl',
    description: 'Get Snapchat profile info',
    aliases: ['snapdl'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `👻 *𝐒𝐍𝐀𝐏𝐂𝐇𝐀𝐓 𝐏𝐑𝐎𝐅𝐈𝐋𝐄*\n\n*Usage:* ${config.PREFIX}snapchatdl <username>\n\n> created by wanga`, msg, buttons);
        }

        const username = args[0];
        await react('👻');
        
        try {
            const response = await axios.get(`https://apis.xwolf.space/api/download/snapchat`, {
                params: { url: username },
                timeout: 15000
            });

            if (!response.data?.success) throw new Error('User not found');

            const data = response.data;
            
            const caption = `👻 *Snapchat Profile*\n\n` +
                           `👤 *Username:* ${data.username}\n` +
                           `📛 *Display Name:* ${data.displayName || 'N/A'}\n` +
                           `📸 *Type:* ${data.type || 'profile'}\n\n` +
                           `> created by wanga`;

            await sock.sendMessage(from, {
                image: { url: data.thumbnailUrl },
                caption: caption
            }, { quoted: msg });
            await react('✅');
        } catch (error) {
            bot.logger.error('Snapchat error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *User not found*\n\n> created by wanga`, msg, buttons);
        }
    }
});

// ==================== FILE HOSTING DOWNLOADERS ====================

// 20. GOOGLE DRIVE DOWNLOAD
commands.push({
    name: 'gdrivedl',
    description: 'Download Google Drive file',
    aliases: ['gddl'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `📁 *𝐆𝐎𝐎𝐆𝐋𝐄 𝐃𝐑𝐈𝐕𝐄*\n\n*Usage:* ${config.PREFIX}gdrivedl <URL>\n\n> created by wanga`, msg, buttons);
        }

        const url = args[0];
        let tempFile = null;
        
        await react('📁');
        
        try {
            const response = await axios.get(`https://api.siputzx.my.id/api/d/gdrive`, {
                params: { url },
                timeout: 60000
            });

            if (!response.data?.status) throw new Error('Download failed');

            const data = response.data.data;
            
            await sock.sendMessage(from, {
                text: `📁 *Google Drive File*\n\n📄 *Name:* ${data.name || 'Unknown'}\n\n⬇️ *Downloading...*`
            }, { quoted: msg });

            const downloadUrls = [data.download, data.url].filter(Boolean);
            if (!downloadUrls.length) throw new Error('No download URL found');

            const ext = path.extname(data.name) || '.bin';
            const filename = `gdrive_${Date.now()}${ext}`;
            tempFile = await tryDownload(downloadUrls, filename);
            const buffer = await fs.readFile(tempFile);
            const stats = await fs.stat(tempFile);
            const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);

            await sock.sendMessage(from, {
                document: buffer,
                fileName: data.name || filename,
                mimetype: 'application/octet-stream',
                caption: `📁 *Google Drive File*\n📄 ${data.name || 'File'}\n💾 ${fileSizeMB} MB\n\n> created by wanga`
            }, { quoted: msg });
            
            await sendWithButtons(sock, from, `✅ *Downloaded successfully*`, msg, buttons);
            await react('✅');
        } catch (error) {
            bot.logger.error('GDrive error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Download failed*\n\n> created by wanga`, msg, buttons);
        } finally {
            if (tempFile && await fs.pathExists(tempFile)) await fs.unlink(tempFile).catch(() => {});
        }
    }
});

// 21. GITHUB GIST DOWNLOAD
commands.push({
    name: 'githubdl',
    description: 'Download GitHub gist',
    aliases: ['ghdl', 'repodl'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `🐙 *𝐆𝐈𝐓𝐇𝐔𝐁 𝐆𝐈𝐒𝐓*\n\n*Usage:* ${config.PREFIX}githubdl <URL>\n\n> created by wanga`, msg, buttons);
        }

        const url = args[0];
        
        await react('🐙');
        
        try {
            const response = await axios.get(`https://api.siputzx.my.id/api/d/github`, {
                params: { url },
                timeout: 30000
            });

            if (!response.data?.status) throw new Error('Download failed');

            const data = response.data.data;
            
            let contentText = data.content || JSON.stringify(data, null, 2);
            if (contentText.length > 4000) {
                contentText = contentText.substring(0, 4000) + '...\n\n(Content truncated)';
            }

            const buttonOptions = {
                title: '🐙 GITHUB GIST',
                text: contentText,
                footer: '> created by wanga',
                buttons: [
                    {
                        name: 'cta_url',
                        buttonParamsJson: JSON.stringify({
                            display_text: '🔗 Open Gist',
                            url: url
                        })
                    },
                    {
                        name: 'cta_copy',
                        buttonParamsJson: JSON.stringify({
                            display_text: '📋 Copy Content',
                            copy_code: data.content || ''
                        })
                    },
                    {
                        name: 'cta_url',
                        buttonParamsJson: JSON.stringify({
                            display_text: '📢 Channel',
                            url: CHANNEL_LINK
                        })
                    }
                ]
            };

            if (buttons) {
                await buttons.send(from, buttonOptions, msg);
            } else {
                await sock.sendMessage(from, { text: contentText }, { quoted: msg });
            }
            await react('✅');
        } catch (error) {
            bot.logger.error('GitHub error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Download failed*\n\n> created by wanga`, msg, buttons);
        }
    }
});

// 22. CAPCUT DOWNLOAD
commands.push({
    name: 'capcut',
    description: 'Download CapCut template',
    aliases: ['cc'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `✂️ *𝐂𝐀𝐏𝐂𝐔𝐓*\n\n*Usage:* ${config.PREFIX}capcut <URL>\n\n> created by wanga`, msg, buttons);
        }

        const url = args[0];
        let tempFile = null;
        
        await react('✂️');
        
        try {
            const response = await axios.get(`https://api.siputzx.my.id/api/d/capcut`, {
                params: { url },
                timeout: 30000
            });

            if (!response.data?.status) throw new Error('Download failed');

            const data = response.data.data;
            
            if (data.thumbnail) {
                await sock.sendMessage(from, {
                    image: { url: data.thumbnail },
                    caption: `✂️ *CapCut Template*\n📝 ${data.title || 'Template'}\n\n⬇️ *Downloading...*`
                }, { quoted: msg });
            }

            const downloadUrls = [data.video, data.url, data.download?.url].filter(Boolean);
            if (!downloadUrls.length) throw new Error('No download URL found');

            const filename = `capcut_${Date.now()}.mp4`;
            tempFile = await tryDownload(downloadUrls, filename);
            const buffer = await fs.readFile(tempFile);
            
            await sendMedia(sock, from, buffer, `capcut_${Date.now()}.mp4`, 
                `✂️ *CapCut Template*\n📝 ${data.title || 'Template'}\n\n> created by wanga`, msg, buttons, false, true);
            await react('✅');
        } catch (error) {
            bot.logger.error('CapCut error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Download failed*\n\n> created by wanga`, msg, buttons);
        } finally {
            if (tempFile && await fs.pathExists(tempFile)) await fs.unlink(tempFile).catch(() => {});
        }
    }
});

// ==================== UNIVERSAL DOWNLOADERS ====================

// 23. SAVEFROM - Universal downloader
commands.push({
    name: 'savefrom',
    description: 'Universal downloader (multiple platforms)',
    aliases: ['sf'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `🌐 *𝐔𝐍𝐈𝐕𝐄𝐑𝐒𝐀𝐋 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃𝐄𝐑*\n\n*Usage:* ${config.PREFIX}savefrom <URL>\n\nSupports: YouTube, Instagram, Facebook, TikTok, Twitter, and more!\n\n> created by wanga`, msg, buttons);
        }

        const url = args[0];
        let tempFile = null;
        
        await react('🌐');
        
        try {
            const response = await axios.get(`https://api.siputzx.my.id/api/d/savefrom`, {
                params: { url },
                timeout: 60000
            });

            if (!response.data?.status) throw new Error('Download failed');

            const data = response.data.data;
            
            if (data.thumbnail) {
                await sock.sendMessage(from, {
                    image: { url: data.thumbnail },
                    caption: `🌐 *Universal Download*\n📹 ${data.title || 'Media'}\n\n⬇️ *Downloading...*`
                }, { quoted: msg });
            }

            const downloadUrls = [data.url, data.download?.url, data.video].filter(Boolean);
            if (!downloadUrls.length) throw new Error('No download URL found');

            const ext = path.extname(downloadUrls[0]) || '.mp4';
            const filename = `savefrom_${Date.now()}${ext}`;
            tempFile = await tryDownload(downloadUrls, filename);
            const buffer = await fs.readFile(tempFile);

            const isVideo = downloadUrls[0].includes('.mp4') || downloadUrls[0].includes('.mov') || downloadUrls[0].includes('.webm');
            const isImage = downloadUrls[0].includes('.jpg') || downloadUrls[0].includes('.jpeg') || downloadUrls[0].includes('.png');

            if (isVideo) {
                await sendMedia(sock, from, buffer, filename, 
                    `🌐 *Universal Download*\n\n> created by wanga`, msg, buttons, false, true);
            } else if (isImage) {
                await sock.sendMessage(from, {
                    image: buffer,
                    caption: `🌐 *Universal Download*\n\n> created by wanga`
                }, { quoted: msg });
            } else {
                const stats = await fs.stat(tempFile);
                const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
                await sock.sendMessage(from, {
                    document: buffer,
                    fileName: filename,
                    mimetype: 'application/octet-stream',
                    caption: `🌐 *Universal Download*\n💾 ${fileSizeMB} MB\n\n> created by wanga`
                }, { quoted: msg });
            }
            await react('✅');
        } catch (error) {
            bot.logger.error('SaveFrom error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Download failed*\n\n> created by wanga`, msg, buttons);
        } finally {
            if (tempFile && await fs.pathExists(tempFile)) await fs.unlink(tempFile).catch(() => {});
        }
    }
});

// 24. DOWNLOAD - Alias for savefrom
commands.push({
    name: 'download',
    description: 'Universal downloader (same as .savefrom)',
    aliases: ['dl'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const savefromCmd = commands.find(c => c.name === 'savefrom');
        await savefromCmd.execute({ msg, from, sender, args, bot, sock, react, reply, buttons });
    }
});

// 25. DLFILES - Direct file download
commands.push({
    name: 'dlfiles',
    description: 'Download any file from direct URL',
    aliases: ['file'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        if (!args.length) {
            await react('ℹ️');
            return sendWithButtons(sock, from, 
                `📥 *𝐃𝐋𝐅𝐈𝐋𝐄𝐒*\n\n*Usage:* ${config.PREFIX}dlfiles <direct file URL>\n\n> created by wanga`, msg, buttons);
        }

        const url = args[0];
        let tempFile = null;
        
        await react('📥');
        
        try {
            await sock.sendMessage(from, {
                text: `📥 *Downloading file...*\n\nURL: ${url}`
            }, { quoted: msg });

            const filename = `file_${Date.now()}${path.extname(url) || '.bin'}`;
            tempFile = await downloadFile(url, filename);
            const buffer = await fs.readFile(tempFile);
            const stats = await fs.stat(tempFile);
            const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);

            await sock.sendMessage(from, {
                document: buffer,
                fileName: filename,
                mimetype: 'application/octet-stream',
                caption: `📥 *File Downloaded*\n📄 ${filename}\n💾 ${fileSizeMB} MB\n🔗 ${url}\n\n> created by wanga`
            }, { quoted: msg });
            
            await sendWithButtons(sock, from, `✅ *Downloaded successfully*`, msg, buttons);
            await react('✅');
        } catch (error) {
            bot.logger.error('DLFiles error:', error);
            await react('❌');
            await sendWithButtons(sock, from, `❌ *Download failed: ${error.message}*\n\n> created by wanga`, msg, buttons);
        } finally {
            if (tempFile && await fs.pathExists(tempFile)) await fs.unlink(tempFile).catch(() => {});
        }
    }
});

// ==================== DOWNLOADER HELP ====================

// 26. DOWNLOADER HELP
commands.push({
    name: 'downloaderhelp',
    description: 'Show all downloader commands',
    aliases: ['dlhelp', 'playhelp'],
    async execute({ msg, from, sender, args, bot, sock, react, reply, buttons }) {
        const prefix = config.PREFIX;
        
        const helpText = `🎵 *𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃𝐄𝐑 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 (𝟐𝟔+)*\n\n` +
            
            `*🎬 𝐘𝐎𝐔𝐓𝐔𝐁𝐄 (𝟓)*\n` +
            `• ${prefix}play, ${prefix}play2, ${prefix}play3\n` +
            `• ${prefix}play4, ${prefix}select\n\n` +
            
            `*🎵 𝐒𝐏𝐎𝐓𝐈𝐅𝐘 (𝟑)*\n` +
            `• ${prefix}spotifysearch, ${prefix}spotifydl\n` +
            `• ${prefix}spotifydldoc\n\n` +
            
            `*🎧 𝐒𝐎𝐔𝐍𝐃𝐂𝐋𝐎𝐔𝐃 (𝟑)*\n` +
            `• ${prefix}soundcloudsearch, ${prefix}soundcloud\n` +
            `• ${prefix}scdoc\n\n` +
            
            `*📱 𝐒𝐎𝐂𝐈𝐀𝐋 𝐌𝐄𝐃𝐈𝐀 (𝟖)*\n` +
            `• ${prefix}tiktokdl, ${prefix}instagramdl\n` +
            `• ${prefix}facebookdl, ${prefix}twitterdl\n` +
            `• ${prefix}threadsdl, ${prefix}douyindl\n` +
            `• ${prefix}laheludl, ${prefix}snapchatdl\n\n` +
            
            `*📁 𝐅𝐈𝐋𝐄 𝐇𝐎𝐒𝐓𝐈𝐍𝐆 (𝟐)*\n` +
            `• ${prefix}gdrivedl, ${prefix}githubdl\n\n` +
            
            `*✂️ 𝐂𝐑𝐄𝐀𝐓𝐈𝐕𝐄 (𝟏)*\n` +
            `• ${prefix}capcut\n\n` +
            
            `*🌐 𝐔𝐍𝐈𝐕𝐄𝐑𝐒𝐀𝐋 (𝟑)*\n` +
            `• ${prefix}savefrom, ${prefix}download\n` +
            `• ${prefix}dlfiles\n\n` +
            
            `> created by wanga`;

        await sendWithButtons(sock, from, helpText, msg, buttons);
        await react('✅');
    }
});

module.exports = { commands };
