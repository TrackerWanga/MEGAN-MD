// MEGAN-MD Group Settings Database
// Separate module for per-group settings

const { DataTypes } = require('sequelize');

let GroupSetting = null;
let AntilinkWarning = null;
let initialized = false;
let sequelizeInstance = null;

// Default settings
const DEFAULT_GROUP_SETTINGS = {
    ANTILINK: 'off',
    ANTILINK_WARN_COUNT: '3',
    WELCOME: 'off',
    GOODBYE: 'off',
    WELCOME_MSG: 'Hey @user welcome to our group!',
    GOODBYE_MSG: 'Goodbye @user! 👋'
};

async function getSequelize() {
    const DatabaseManager = require('../lib/database');
    const db = new DatabaseManager();
    await db.initialize();
    return db.sequelize;
}

async function initModels() {
    if (initialized) return;
    
    if (!sequelizeInstance) {
        sequelizeInstance = await getSequelize();
    }
    
    GroupSetting = sequelizeInstance.define('GroupSetting', {
        groupJid: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        key: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        value: {
            type: DataTypes.TEXT,
            allowNull: true,
            defaultValue: 'off'
        }
    }, {
        tableName: 'group_settings',
        timestamps: true,
        indexes: [
            { fields: ['groupJid', 'key'], unique: true }
        ]
    });

    AntilinkWarning = sequelizeInstance.define('AntilinkWarning', {
        groupJid: { type: DataTypes.STRING, allowNull: false },
        userJid: { type: DataTypes.STRING, allowNull: false },
        warnCount: { type: DataTypes.INTEGER, defaultValue: 0 }
    }, {
        tableName: 'antilink_warnings',
        timestamps: true,
        indexes: [
            { fields: ['groupJid', 'userJid'], unique: true }
        ]
    });
    
    await GroupSetting.sync({ alter: true });
    await AntilinkWarning.sync({ alter: true });
    
    initialized = true;
    console.log('✅ Group Settings tables synchronized');
}

async function initGroupSettings() {
    await initModels();
}

async function getGroupSetting(groupJid, key) {
    try {
        await initModels();
        const record = await GroupSetting.findOne({
            where: { groupJid, key }
        });
        if (record) {
            return record.value;
        }
        return DEFAULT_GROUP_SETTINGS[key] || 'off';
    } catch (error) {
        console.error(`Error getting group setting ${key}:`, error.message);
        return DEFAULT_GROUP_SETTINGS[key] || 'off';
    }
}

async function setGroupSetting(groupJid, key, value) {
    try {
        await initModels();
        await GroupSetting.upsert({
            groupJid,
            key,
            value: String(value)
        });
        return true;
    } catch (error) {
        console.error(`Error setting group setting ${key}:`, error.message);
        return false;
    }
}

async function getAntilinkWarnings(groupJid, userJid) {
    try {
        await initModels();
        const record = await AntilinkWarning.findOne({
            where: { groupJid, userJid }
        });
        return record ? record.warnCount : 0;
    } catch (error) {
        return 0;
    }
}

async function addAntilinkWarning(groupJid, userJid) {
    try {
        await initModels();
        const [record, created] = await AntilinkWarning.findOrCreate({
            where: { groupJid, userJid },
            defaults: { groupJid, userJid, warnCount: 1 }
        });
        if (!created) {
            record.warnCount += 1;
            await record.save();
        }
        return record.warnCount;
    } catch (error) {
        console.error('Error adding warning:', error.message);
        return 0;
    }
}

async function resetAntilinkWarnings(groupJid, userJid) {
    try {
        await initModels();
        await AntilinkWarning.destroy({
            where: { groupJid, userJid }
        });
        return true;
    } catch (error) {
        return false;
    }
}

module.exports = {
    initGroupSettings,
    getGroupSetting,
    setGroupSetting,
    getAntilinkWarnings,
    addAntilinkWarning,
    resetAntilinkWarnings,
    DEFAULT_GROUP_SETTINGS
};
